from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import database
from .config import settings
from .middleware.errors import register_handlers
from .routes import auth, budget, destinations, recommendations, trips, users
from .services.ml_service import ml_service

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("tripai")


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.validate()
    ml_service.load_all()  # once, at startup
    app.state.db_error = None
    try:
        database.connect()
    except Exception as exc:  # noqa: BLE001
        app.state.db_error = str(exc)[:200]
        log.error("MongoDB connection failed: %s (auth/trips will return 503 until it is available)", app.state.db_error)
    yield
    database.close()


app = FastAPI(
    title="TripAI API", version="1.0.0", lifespan=lifespan,
    description="Dubai travel planner backed by five content-based recommender models (TF-IDF + NearestNeighbors). "
                "No price predictions are made; prices come only from dataset columns or user input.",
)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
register_handlers(app)
for r in (auth.router, users.router, trips.router, destinations.router, recommendations.router, budget.router):
    app.include_router(r)


@app.get("/api/health", tags=["System"])
def health():
    db = database.db_status()
    ml = ml_service.status()
    ok = db["connected"] and ml["all_available"]
    return {"status": "ok" if ok else "degraded", "database": db, "models": ml}


@app.get("/", include_in_schema=False)
def root():
    return {"name": "TripAI API", "docs": "/docs", "health": "/api/health"}

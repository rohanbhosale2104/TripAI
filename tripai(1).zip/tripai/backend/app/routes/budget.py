from __future__ import annotations

from fastapi import APIRouter

from ..schemas.common import BudgetRequest
from ..services.budget_service import estimate_budget

router = APIRouter(prefix="/api/budget", tags=["Budget"])


@router.post("/estimate", summary="Budget from dataset fares + food data + your own hotel/activity costs")
def estimate(body: BudgetRequest):
    return estimate_budget(body)

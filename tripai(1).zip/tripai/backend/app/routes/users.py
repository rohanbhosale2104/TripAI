from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from ..database import get_db
from ..models.documents import USERS, user_public
from ..schemas.auth import PasswordChange, ProfileUpdate, UserOut
from ..utils.deps import get_current_user
from ..utils.security import hash_password, verify_password

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("/me", response_model=UserOut)
def get_profile(user: dict = Depends(get_current_user)):
    return user_public(user)


@router.put("/me", response_model=UserOut)
def update_profile(body: ProfileUpdate, user: dict = Depends(get_current_user)):
    changes = body.model_dump(exclude_none=True)
    if changes:
        get_db()[USERS].update_one({"_id": user["_id"]}, {"$set": changes})
        user = get_db()[USERS].find_one({"_id": user["_id"]})
    return user_public(user)


@router.put("/me/password")
def change_password(body: PasswordChange, user: dict = Depends(get_current_user)):
    if not verify_password(body.current_password, user["password_hash"]):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Current password is incorrect.")
    get_db()[USERS].update_one({"_id": user["_id"]}, {"$set": {"password_hash": hash_password(body.new_password)}})
    return {"message": "Password updated"}

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response, status

from ..database import get_db
from ..models.documents import TRIPS, now, to_object_id, trip_public
from ..schemas.common import TripRequest
from ..schemas.trips import TripSave, TripUpdate
from ..services.trip_service import generate_plan
from ..utils.deps import get_current_user
from ..utils.pdf import build_trip_pdf

router = APIRouter(prefix="/api/trips", tags=["Trips"])


def _owned(trip_id: str, user: dict) -> dict:
    oid = to_object_id(trip_id)
    doc = get_db()[TRIPS].find_one({"_id": oid, "user_id": user["_id"]}) if oid else None
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Trip not found.")
    return doc


def _default_title(req: TripRequest) -> str:
    return f"{req.travel_type.title()} trip to {req.destination} - {req.start_date:%d %b %Y}"


def _jsonable(req: TripRequest) -> dict:
    return req.model_dump(mode="json")


def _summary(doc: dict) -> dict:
    t = trip_public(doc)
    plan, req = t.pop("plan"), t.pop("request")
    b = plan["budget"]
    return {**t, "origin": req["origin"], "destination": req["destination"], "start_date": req["start_date"],
            "end_date": req["end_date"], "days": plan["summary"]["days"], "travellers": req["travellers"],
            "travel_type": req["travel_type"], "budget_aed": req["budget_aed"], "estimated_total_aed": b["total_estimate"],
            "budget_status": b["status"]}


@router.post("/generate", summary="Generate (not save) a personalised plan")
def generate(req: TripRequest, _: dict = Depends(get_current_user)):
    return generate_plan(req)


@router.post("", status_code=status.HTTP_201_CREATED, summary="Generate and save a trip")
def save_trip(body: TripSave, user: dict = Depends(get_current_user)):
    plan = generate_plan(body.request)  # regenerated server-side: stored plans can't be tampered with
    doc = {"user_id": user["_id"], "title": body.title or _default_title(body.request), "notes": body.notes,
           "request": _jsonable(body.request), "plan": plan, "created_at": now(), "updated_at": now()}
    doc["_id"] = get_db()[TRIPS].insert_one(doc).inserted_id
    return trip_public(doc)


@router.get("", summary="List my trips (summaries)")
def list_trips(user: dict = Depends(get_current_user)):
    cur = get_db()[TRIPS].find({"user_id": user["_id"]}).sort("updated_at", -1).limit(200)
    return {"items": [_summary(d) for d in cur]}


@router.get("/{trip_id}")
def get_trip(trip_id: str, user: dict = Depends(get_current_user)):
    return trip_public(_owned(trip_id, user))


@router.put("/{trip_id}", summary="Edit title/notes, or change the request to regenerate the plan")
def update_trip(trip_id: str, body: TripUpdate, user: dict = Depends(get_current_user)):
    doc = _owned(trip_id, user)
    changes: dict = {"updated_at": now()}
    if body.title is not None:
        changes["title"] = body.title
    if body.notes is not None:
        changes["notes"] = body.notes
    if body.request is not None:
        changes["request"] = _jsonable(body.request)
        changes["plan"] = generate_plan(body.request)
    get_db()[TRIPS].update_one({"_id": doc["_id"]}, {"$set": changes})
    return trip_public(get_db()[TRIPS].find_one({"_id": doc["_id"]}))


@router.delete("/{trip_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_trip(trip_id: str, user: dict = Depends(get_current_user)):
    doc = _owned(trip_id, user)
    get_db()[TRIPS].delete_one({"_id": doc["_id"]})
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/{trip_id}/pdf", summary="Download itinerary as PDF")
def trip_pdf(trip_id: str, user: dict = Depends(get_current_user)):
    doc = _owned(trip_id, user)
    pdf = build_trip_pdf(doc["title"], doc["request"], doc["plan"])
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="tripai-{trip_id}.pdf"'})

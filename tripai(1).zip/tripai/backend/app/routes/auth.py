from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pymongo.errors import DuplicateKeyError

from ..database import get_db
from ..middleware import rate_limit
from ..models.documents import REVOKED, USERS, now, user_public
from ..schemas.auth import LoginRequest, RegisterRequest, TokenResponse, UserOut
from ..utils.deps import get_current_user, get_token_payload
from ..utils.security import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["Authentication"])
_DUMMY_HASH = hash_password("dummy-password-1")  # constant-time-ish login for unknown emails


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register(body: RegisterRequest, request: Request):
    rate_limit.limit(request, max_calls=10)
    email = body.email.lower()
    doc = {"name": body.name, "email": email, "password_hash": hash_password(body.password),
           "home_city": "", "preferences": {}, "created_at": now()}
    try:
        res = get_db()[USERS].insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists.")
    doc["_id"] = res.inserted_id
    token, ttl = create_access_token(str(res.inserted_id))
    return {"access_token": token, "expires_in": ttl, "user": user_public(doc)}


@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest, request: Request):
    email = body.email.lower()
    rate_limit.limit(request, key_extra=email, max_calls=8)
    user = get_db()[USERS].find_one({"email": email})
    ok = verify_password(body.password, user["password_hash"] if user else _DUMMY_HASH)
    if not user or not ok:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password.")
    token, ttl = create_access_token(str(user["_id"]))
    return {"access_token": token, "expires_in": ttl, "user": user_public(user)}


@router.get("/me", response_model=UserOut)
def me(user: dict = Depends(get_current_user)):
    return user_public(user)


@router.post("/logout", status_code=status.HTTP_200_OK)
def logout(payload: dict = Depends(get_token_payload), _: dict = Depends(get_current_user)):
    """Revokes the token server-side until it would have expired anyway."""
    exp = datetime.fromtimestamp(payload["exp"], tz=timezone.utc)
    get_db()[REVOKED].update_one({"_id": payload["jti"]}, {"$set": {"expires_at": exp}}, upsert=True)
    return {"message": "Logged out"}

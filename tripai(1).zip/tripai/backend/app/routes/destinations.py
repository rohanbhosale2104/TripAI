from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from ..services import recommendation_service as rec
from ..services.ml_service import ml_service

router = APIRouter(prefix="/api/destinations", tags=["Destinations"])


@router.get("", summary="Dubai areas (search + filter)")
def list_areas(q: Optional[str] = Query(None, max_length=60), good_for: Optional[str] = Query(None, max_length=20)):
    pool = rec.attraction_pool()
    items = [rec.area_summary(a, pool) for a in rec.load_areas()]
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["name"].lower() or ql in i["description"].lower()
                 or any(ql in k.lower() for k in i["known_for"])]
    if good_for:
        items = [i for i in items if good_for.lower() in [g.lower() for g in i["good_for"]]]
    return {"items": items, "total": len(items)}


@router.get("/attractions", summary="Search visitable attractions (POI model)")
def attractions(q: Optional[str] = Query(None, max_length=80), kind: Optional[str] = Query(None, max_length=60),
                limit: int = Query(30, ge=1, le=100)):
    if q:
        res = rec.recommend_attractions(None, None, None, limit=100, query_override=q)
        items = res["items"]
    else:
        items = rec.attraction_pool()
    if kind:
        items = [i for i in items if kind.lower() in (i["kind"] or "").lower()]
    return {"items": items[:limit], "total": len(items),
            "kinds": sorted({i["kind"] for i in rec.attraction_pool()}),
            "notes": ["Only genuinely visitable places from the POI dataset are listed."]}


@router.get("/{slug}", summary="Area detail: attractions, activities, food, expenses")
def area(slug: str):
    d = rec.area_detail(slug)
    if not d:
        raise HTTPException(404, "Area not found.")
    return d

from __future__ import annotations

from fastapi import APIRouter

from ..schemas.recommend import AttractionReq, DestinationReq, FoodReq, HotelReq, RestaurantReq, TransportReq
from ..services import recommendation_service as rec

router = APIRouter(prefix="/api/recommendations", tags=["Recommendations (ML)"])


@router.post("/destinations", summary="Rank Dubai areas for a travel type (POI model)")
def destinations(b: DestinationReq):
    return rec.recommend_areas(b.travel_type, b.keywords, b.limit)


@router.post("/hotels", summary="Hotel matches (accommodation model, no prices)")
def hotels(b: HotelReq):
    return rec.recommend_hotels(b.travel_type, b.keywords, b.area, b.limit)


@router.post("/attractions", summary="Visitable attractions (POI model, filtered)")
def attractions(b: AttractionReq):
    return rec.recommend_attractions(b.travel_type, b.keywords, b.area, b.limit)


@router.post("/restaurants", summary="Restaurants (restaurant model)")
def restaurants(b: RestaurantReq):
    return rec.recommend_restaurants(b.food_preference, b.cuisine, b.area, b.keywords, b.limit)


@router.post("/food", summary="Dishes with AED prices (food model - synthetic data)")
def food(b: FoodReq):
    return rec.recommend_food(b.food_preference, b.cuisine, b.area, b.keywords, b.max_cost_for_two_aed, b.limit)


@router.post("/transport", summary="Transport modes with AED fares (transportation model)")
def transport(b: TransportReq):
    return rec.recommend_transport(b.transport_preference, b.include_airport, b.limit)

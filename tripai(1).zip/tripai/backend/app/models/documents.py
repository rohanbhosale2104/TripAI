"""MongoDB document helpers (collections: users, trips, revoked_tokens)."""
from __future__ import annotations

from datetime import datetime, timezone

from bson import ObjectId
from bson.errors import InvalidId

USERS, TRIPS, REVOKED = "users", "trips", "revoked_tokens"


def now() -> datetime:
    return datetime.now(timezone.utc)


def to_object_id(value: str) -> ObjectId | None:
    try:
        return ObjectId(value)
    except (InvalidId, TypeError):
        return None


def iso(dt) -> str | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def user_public(doc: dict) -> dict:
    return {
        "id": str(doc["_id"]),
        "name": doc["name"],
        "email": doc["email"],
        "home_city": doc.get("home_city", ""),
        "preferences": doc.get("preferences", {}),
        "created_at": iso(doc.get("created_at")),
    }


def trip_public(doc: dict) -> dict:
    return {
        "id": str(doc["_id"]),
        "title": doc["title"],
        "notes": doc.get("notes", ""),
        "request": doc["request"],
        "plan": doc["plan"],
        "created_at": iso(doc.get("created_at")),
        "updated_at": iso(doc.get("updated_at")),
    }

"""Server-side PDF itinerary (ReportLab core fonts -> non-Latin text such as Arabic is stripped)."""
from __future__ import annotations

import io
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import HRFlowable, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .text import latin_only

INK, ACCENT, SAND = colors.HexColor("#1B2333"), colors.HexColor("#C2552D"), colors.HexColor("#F4ECE0")


def _p(text, style):
    return Paragraph(escape(latin_only(text)), style)


def build_trip_pdf(title: str, trip_request: dict, plan: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm,
                            title=latin_only(title), author="TripAI")
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], textColor=INK, fontSize=22, leading=26, alignment=0)
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], textColor=ACCENT, fontSize=13, spaceBefore=10, spaceAfter=4)
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9.5, leading=13, textColor=INK)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10.5, textColor=colors.HexColor("#5B6475"))
    s = plan["summary"]
    story = [_p(title, h1), _p(f"{s['origin']} to {s['destination']}  |  {s['start_date']} to {s['end_date']}  |  "
                               f"{s['travellers']} traveller(s)  |  {s['travel_type'].title()} trip", small), Spacer(1, 6)]

    for d in plan["days"]:
        story.append(_p(f"Day {d['day']} - {d['weekday']}, {d['date']}", h2))
        rows = []
        for sl in d["slots"]:
            if sl["type"] == "attraction":
                pl = sl["place"]
                cat = latin_only(pl.get("category") or "")
                extra = f" ({cat})" if cat else ""
                txt = f"<b>{escape(sl['period'].title())}:</b> {escape(latin_only(pl['name']) or 'Attraction')}{escape(extra)}"
                if sl.get("leg_from_previous"):
                    lg = sl["leg_from_previous"]
                    txt += f"<br/><font size=8 color='#5B6475'>{lg['straight_line_km']} km from previous stop - {escape(lg['suggested_mode'])}</font>"
            else:
                txt = f"<b>{escape(sl['period'].title())}:</b> {escape(latin_only(sl['title']))}"
            rows.append([Paragraph(txt, body)])
        for m in d["meals"]:
            r = (m.get("restaurant") or {}).get("name")
            idea = m.get("dish_idea")
            txt = f"<b>{escape(m['meal'].title())}:</b> {escape(latin_only(r)) if r else 'Restaurant suggestion unavailable'}"
            if idea:
                txt += (f"<br/><font size=8 color='#5B6475'>Dish idea (synthetic demo data): {escape(idea['recommended_dish'])}, "
                        f"~AED {idea['estimated_cost_for_two_aed']:.0f} for two</font>")
            rows.append([Paragraph(txt, body)])
        t = Table(rows, colWidths=[174 * mm])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), SAND), ("LINEBELOW", (0, 0), (-1, -2), 0.3, colors.white),
                               ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        story += [t]
        c = d["estimated_cost_aed"]
        parts = [f"{k.replace('_', ' ')}: AED {v:,.0f}" for k, v in c.items() if v]
        story.append(_p("Estimated per-day: " + ("; ".join(parts) or "n/a"), small))

    b = plan["budget"]
    story += [PageBreak(), _p("Budget estimate (AED)", h2)]
    data = [["Item", "Estimate", "Confidence"]]
    for l in b["lines"]:
        data.append([latin_only(l["label"]) + (" *" if l["is_lower_bound"] else ""), f"{l['estimate']:,.0f}" if l["estimate"] is not None else "-", l["confidence"]])
    data.append(["TOTAL (priced items)", f"{b['total_estimate']:,.0f}", ""])
    data.append(["Your budget", f"{b['budget_aed']:,.0f}", ""])
    data.append(["Remaining", f"{b['remaining_aed']:,.0f}", ""])
    t = Table(data, colWidths=[110 * mm, 32 * mm, 32 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), INK), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 9),
                           ("ALIGN", (1, 0), (1, -1), "RIGHT"), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#CFC6B8")),
                           ("FONTNAME", (0, -3), (-1, -1), "Helvetica-Bold")]))
    story += [t, Spacer(1, 4), _p(b["message"], body)]
    if b["missing_components"]:
        story.append(_p("Not priced: " + "; ".join(b["missing_components"]), small))
    story += [Spacer(1, 6), HRFlowable(width="100%", color=ACCENT), Spacer(1, 4), _p("Important notes", h2)]
    for n in list(plan.get("data_notes", [])) + b.get("notes", []) + ["* lower bound: metered fares, fuel, deposits etc. are extra."]:
        story.append(_p("- " + n, small))
    story.append(_p("Generated by TripAI. Hotel, ticket and flight prices are never estimated; food figures use synthetic demo data. Verify everything before booking.", small))
    doc.build(story)
    return buf.getvalue()

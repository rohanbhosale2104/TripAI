from __future__ import annotations

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ..database import get_db
from ..models.documents import REVOKED, USERS, to_object_id
from .security import decode_token

bearer = HTTPBearer(auto_error=False, description="Paste the access_token returned by /api/auth/login")


def _unauth(msg="Not authenticated"):
    return HTTPException(status.HTTP_401_UNAUTHORIZED, msg, headers={"WWW-Authenticate": "Bearer"})


def get_token_payload(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    if creds is None:
        raise _unauth()
    try:
        return decode_token(creds.credentials)
    except jwt.ExpiredSignatureError:
        raise _unauth("Session expired. Please log in again.")
    except jwt.PyJWTError:
        raise _unauth("Invalid token")


def get_current_user(payload: dict = Depends(get_token_payload)) -> dict:
    db = get_db()
    if db[REVOKED].find_one({"_id": payload.get("jti")}):
        raise _unauth("Session ended. Please log in again.")
    oid = to_object_id(payload.get("sub", ""))
    user = db[USERS].find_one({"_id": oid}) if oid else None
    if not user:
        raise _unauth("User no longer exists")
    return user

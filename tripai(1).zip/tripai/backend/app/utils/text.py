from __future__ import annotations

import re

_NON_LATIN = re.compile(r"[^\u0000-\u024F\u2010-\u2027]+")  # keep Latin + basic punctuation


def latin_only(text: str) -> str:
    """Strip Arabic/Cyrillic/etc. so core PDF fonts can render the text."""
    cleaned = _NON_LATIN.sub(" ", str(text or ""))
    return re.sub(r"\s+", " ", cleaned).strip(" -|/,")

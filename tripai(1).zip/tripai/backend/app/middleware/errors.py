"""Global exception handling and request logging."""
from __future__ import annotations

import logging
import time

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pymongo.errors import PyMongoError
from starlette.exceptions import HTTPException as StarletteHTTPException

log = logging.getLogger("tripai")


class ModelUnavailableError(Exception):
    """Raised when an ML model failed to load or is unusable."""

    def __init__(self, model_key: str, reason: str):
        self.model_key, self.reason = model_key, reason
        super().__init__(f"Model '{model_key}' unavailable: {reason}")


def _err(status: int, code: str, message: str, details=None) -> JSONResponse:
    body = {"error": {"code": code, "message": message}}
    if details is not None:
        body["error"]["details"] = details
    return JSONResponse(status_code=status, content=body)


def register_handlers(app: FastAPI) -> None:
    @app.exception_handler(ModelUnavailableError)
    async def _model(_: Request, exc: ModelUnavailableError):
        return _err(503, "model_unavailable", str(exc))

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        details = [
            {"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]}
            for e in exc.errors()
        ]
        return _err(422, "validation_error", "Invalid request data.", details)

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException):
        resp = _err(exc.status_code, "http_error", str(exc.detail))
        if exc.headers:
            resp.headers.update(exc.headers)
        return resp

    @app.exception_handler(PyMongoError)
    async def _mongo(_: Request, exc: PyMongoError):
        log.exception("MongoDB error")
        return _err(503, "database_error", "Database is unavailable. Please try again shortly.")

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception):
        log.exception("Unhandled error")
        return _err(500, "internal_error", "Something went wrong on our side.")

    @app.middleware("http")
    async def _timing(request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        ms = (time.perf_counter() - start) * 1000
        response.headers["X-Process-Time-ms"] = f"{ms:.1f}"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        log.info("%s %s -> %s (%.0f ms)", request.method, request.url.path, response.status_code, ms)
        return response

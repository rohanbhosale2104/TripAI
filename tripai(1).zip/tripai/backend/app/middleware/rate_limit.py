"""Tiny in-memory sliding-window limiter for auth endpoints (single-process)."""
from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request

_hits: dict[str, deque] = defaultdict(deque)


def reset() -> None:
    _hits.clear()


def limit(request: Request, key_extra: str = "", max_calls: int = 10, window_s: int = 60) -> None:
    ip = request.client.host if request.client else "unknown"
    key = f"{request.url.path}:{ip}:{key_extra}"
    now = time.monotonic()
    q = _hits[key]
    while q and now - q[0] > window_s:
        q.popleft()
    if len(q) >= max_calls:
        raise HTTPException(status_code=429, detail="Too many attempts. Please wait a minute and try again.")
    q.append(now)

"""
Trip + itinerary generation. Pure functions (dict in -> dict out) so each step can later become a LangGraph
node/tool (see services/agent_tools.py). No paid APIs, no network calls, no invented prices.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from ..schemas.common import BudgetRequest, TripRequest
from ..utils.geo import haversine_km
from . import recommendation_service as rec
from .budget_service import estimate_budget, food_stats

ENGINE = "tripai-nn-v1"
MODE_HINT = {
    "public": "Metro / bus / tram", "metro": "Metro", "taxi": "Taxi", "ride-hailing": "Ride-hailing app (quote in app)",
    "rental-car": "Rental car", "walking": "Walking", "water": "Abra / water taxi (Creek only)", "mixed": "Metro or taxi",
}
import re
_EVENING_ONLY = re.compile(r"dinner|night|sunset|evening", re.I)
MEAL_SETS = {0: [], 1: ["lunch"], 2: ["lunch", "dinner"], 3: ["breakfast", "lunch", "dinner"]}


def _leg(a: dict | None, b: dict | None, pref: str) -> dict | None:
    if not a or not b or a.get("lat") is None or b.get("lat") is None:
        return None
    km = haversine_km(a["lat"], a["lng"], b["lat"], b["lng"])
    mode = "Walk" if km < 1.2 else MODE_HINT.get(pref, "Taxi")
    return {"from": a["name"], "to": b["name"], "straight_line_km": round(km, 1), "suggested_mode": mode,
            "note": "Straight-line distance; road distance and time will be longer."}


def _nearest(cands: list[dict], ref: dict | None, used: set[str], top_n: int = 10, avoid_kind: set | None = None) -> dict | None:
    pool = [c for c in cands if c["name"] not in used]
    if avoid_kind:  # variety: don't stack the same kind of activity in one day if an alternative exists
        alt = [c for c in pool if c.get("kind") not in avoid_kind]
        pool = alt or pool
    pool = pool[:top_n]
    if not pool:
        return None
    if not ref or ref.get("lat") is None:
        return pool[0]
    return min(pool, key=lambda c: haversine_km(ref["lat"], ref["lng"], c["lat"], c["lng"]) if c.get("lat") is not None else 1e9)


def _slot_candidates(req: TripRequest, slot: str, area: str | None) -> list[dict]:
    q = f"{rec.SLOT_QUERIES[slot]} {rec.ATTR_QUERY_BY_TYPE.get(req.travel_type, '')}"
    items = rec.recommend_attractions(req.travel_type, req.keywords(), area, limit=80, query_override=q)["items"]
    if slot != "evening":  # dinner cruises / night tours belong in the evening slot
        items = [i for i in items if not _EVENING_ONLY.search(i["name"])]
    return items


def _budget_request(req: TripRequest) -> BudgetRequest:
    return BudgetRequest(**{k: getattr(req, k) for k in (
        "hotel_per_night_aed", "rooms", "activities_total_aed", "flights_total_aed", "other_costs_aed", "meals_per_day",
        "local_rides_per_day", "taxi_rides_per_day", "include_airport_transfers", "travellers", "budget_aed",
        "food_preference", "transport_preference", "cuisine")}, days=req.days)


def generate_plan(req: TripRequest) -> dict:
    days, pref = req.days, req.transport_preference
    area = req.preferred_area
    notes: list[str] = []

    # ---- candidate pools (all from the POI / restaurant models)
    pools = {s: _slot_candidates(req, s, area) for s in ("morning", "afternoon", "evening")}
    if area and not any(pools.values()):
        notes.append(f"No dataset attractions were found near '{area}'; showing city-wide matches instead.")
        pools = {s: _slot_candidates(req, s, None) for s in ("morning", "afternoon", "evening")}
    everything = {c["name"]: c for p in pools.values() for c in p}
    areas_ranked = rec.recommend_areas(req.travel_type, req.keywords(), limit=6)["items"] or []
    area_cycle = [a["name"] for a in areas_ranked] or [a["name"] for a in rec.load_areas()]

    meals = MEAL_SETS[req.meals_per_day]
    resto = rec.recommend_restaurants(req.food_preference, req.cuisine, area, req.keywords(), limit=60)["items"] if meals else []
    food_ideas = rec.recommend_food(req.food_preference, req.cuisine, None, req.keywords(), None, limit=max(days * 3, 12))["items"] if meals else []

    budget = estimate_budget(_budget_request(req), area)
    stats = budget.get("per_person_per_meal")
    line_cost = lambda cat: sum(l["estimate"] or 0 for l in budget["lines"] if l["category"] == cat)
    local_tr_per_day = round(line_cost("local_transport") / days, 2)
    food_per_day = round(line_cost("food") / days, 2)
    nights = max(days - 1, 0)

    used_places: set[str] = set()
    used_restos: set[str] = set()
    used_dishes: set[str] = set()
    out_days = []
    shortage = False

    for d in range(days):
        date = req.start_date + timedelta(days=d)
        slots, prev, day_kinds = [], None, set()
        for slot in ("morning", "afternoon", "evening"):
            pool_all = [c for c in everything.values() if slot == "evening" or not _EVENING_ONLY.search(c["name"])]
            pick = _nearest(pools[slot], prev, used_places, avoid_kind=day_kinds) or _nearest(pool_all, prev, used_places, top_n=60, avoid_kind=day_kinds)
            if pick:
                used_places.add(pick["name"])
                day_kinds.add(pick.get("kind"))
                slots.append({"period": slot, "type": "attraction", "place": pick, "leg_from_previous": _leg(prev, pick, pref)})
                prev = pick
            else:
                shortage = True
                suggest = area_cycle[(d + len(slots)) % len(area_cycle)]
                a = rec.area_by_name(suggest)
                slots.append({"period": slot, "type": "open_time", "title": f"Open time - explore {suggest}",
                              "description": a["description"] if a else "",
                              "note": "The attraction dataset has no further unvisited places for this slot. Description is editorial text, not model output.",
                              "place": None, "leg_from_previous": None})

        day_meals = []
        refs = {"breakfast": None, "lunch": next((s["place"] for s in slots if s["period"] == "morning" and s["place"]), None),
                "dinner": next((s["place"] for s in reversed(slots) if s["place"]), None)}
        for m in meals:
            r = _nearest(resto, refs.get(m), used_restos, top_n=25) if resto else None
            if r:
                used_restos.add(r["name"])
            idea = next((f for f in food_ideas if f["recommended_dish"] not in used_dishes), None) if m != "breakfast" else None
            if idea:
                used_dishes.add(idea["recommended_dish"])
            day_meals.append({"meal": m, "restaurant": r, "dish_idea": idea,
                              "est_cost_per_person_aed": round(stats["median"], 2) if stats else None})

        tnotes = []
        if d == 0:
            tnotes.append(f"Arrival day from {req.origin}: allow time for airport transfer and hotel check-in.")
        if d == days - 1 and days > 1:
            tnotes.append("Departure day: check-out and airport transfer; keep the evening flexible.")
        tnotes.append(f"Local transport preference: {MODE_HINT.get(pref, pref)}.")
        day_cost = {
            "food": food_per_day, "local_transport": local_tr_per_day,
            "accommodation": round((req.hotel_per_night_aed or 0) * req.room_count(), 2) if (req.hotel_per_night_aed is not None and d < nights) else None,
            "activities": round(req.activities_total_aed / days, 2) if req.activities_total_aed is not None else None,
        }
        out_days.append({
            "day": d + 1, "date": date.isoformat(), "weekday": date.strftime("%A"),
            "title": f"Day {d + 1}", "slots": slots, "meals": day_meals, "travel_notes": tnotes,
            "estimated_cost_aed": day_cost,
            "cost_note": "Food = synthetic dataset estimate; transport = fare-rule estimate; accommodation/activities only if you entered them.",
        })

    if shortage:
        notes.append("The POI dataset has only a limited set of genuine attractions, so some slots are marked 'open time'.")
    notes.append("Opening hours, ticket prices and availability are not in the data - verify before you travel.")

    hotels = rec.recommend_hotels(req.travel_type, req.keywords(), area, limit=6)
    transport = rec.recommend_transport(pref, req.include_airport_transfers, limit=6)
    return {
        "engine": ENGINE, "generated_at": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "origin": req.origin, "destination": req.destination, "start_date": req.start_date.isoformat(),
            "end_date": req.end_date.isoformat(), "days": days, "nights": nights, "travellers": req.travellers,
            "travel_type": req.travel_type, "food_preference": req.food_preference, "transport_preference": pref,
            "budget_aed": req.budget_aed, "preferences": req.preferences,
        },
        "days": out_days, "budget": budget, "hotels": hotels, "transport": transport,
        "food": rec.recommend_food(req.food_preference, req.cuisine, None, req.keywords(), None, limit=8),
        "restaurants": {"items": resto[:10], "model": "restaurant"} if resto else {"items": [], "model": "restaurant"},
        "areas": areas_ranked[:4],
        "data_notes": notes,
        "model_provenance": {"attractions": "poi", "hotels": "accommodation", "restaurants": "restaurant",
                             "dishes_and_food_costs": "food (synthetic)", "transport": "transportation"},
    }

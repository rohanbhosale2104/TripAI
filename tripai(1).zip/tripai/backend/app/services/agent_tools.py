"""
Agent-ready tool registry (for a future LangGraph integration).

Every function in the service layer takes plain JSON-like inputs and returns plain dicts, so each can be wrapped as a
LangGraph/LangChain tool without touching HTTP code. Example for later:

    from langchain_core.tools import StructuredTool
    tools = [StructuredTool.from_function(t["fn"], name=name, description=t["description"]) for name, t in TOOLS.items()]

Suggested agent mapping: Travel Planner -> plan_trip | Destination Research -> recommend_areas, recommend_attractions |
Budget Optimisation -> estimate_budget | Transportation -> recommend_transport | Hotel -> recommend_hotels |
Food -> recommend_food, recommend_restaurants | Itinerary Optimisation -> plan_trip (re-run with new constraints).
"""
from __future__ import annotations

from ..schemas.common import BudgetRequest, TripRequest
from . import recommendation_service as rec
from .budget_service import estimate_budget
from .trip_service import generate_plan

TOOLS = {
    "plan_trip": {"fn": lambda **kw: generate_plan(TripRequest(**kw)), "description": "Generate a full Dubai itinerary + budget."},
    "estimate_budget": {"fn": lambda **kw: estimate_budget(BudgetRequest(**kw)), "description": "Budget estimate from dataset fares and user costs."},
    "recommend_hotels": {"fn": rec.recommend_hotels, "description": "Hotel matches (no prices)."},
    "recommend_attractions": {"fn": rec.recommend_attractions, "description": "Visitable attractions from the POI model."},
    "recommend_restaurants": {"fn": rec.recommend_restaurants, "description": "Restaurant matches by diet preference."},
    "recommend_food": {"fn": rec.recommend_food, "description": "Dishes with AED prices (synthetic dataset)."},
    "recommend_transport": {"fn": rec.recommend_transport, "description": "Transport modes with AED fares."},
    "recommend_areas": {"fn": rec.recommend_areas, "description": "Rank Dubai areas for a travel type."},
}

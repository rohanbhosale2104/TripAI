"""
Centralised ML service.

Your five .pkl files are dicts: {"vectorizer": TfidfVectorizer, "model": NearestNeighbors(cosine),
"data": DataFrame}. They are *content-based recommenders*: a text query is vectorised and the nearest rows of
the model's own DataFrame are returned. There are no price regressors here, so nothing in this module
predicts a price. Prices only ever come from columns that exist in the data (food + transport).

Guarantees
- Models are loaded ONCE at startup (see `ml_service` singleton + FastAPI lifespan).
- Original files are never modified (opened read-only; SHA-256 compared with SHA256SUMS.txt).
- Corrupted rows (column-shifted records from the source scrape) are masked out at load time.
- A model that fails to load is marked unavailable -> callers get HTTP 503, never random output.
"""
from __future__ import annotations

import hashlib
import logging
import pickle
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

from ..config import settings
from ..middleware.errors import ModelUnavailableError

log = logging.getLogger("tripai.ml")

DUBAI_LAT = (24.5, 25.6)
DUBAI_LNG = (54.8, 55.7)
_NUMERIC = r"-?\d+(\.\d+)?"


# --------------------------------------------------------------------------- validity masks
def _tourpedia_mask(df: pd.DataFrame) -> tuple[np.ndarray, dict]:
    """Tour-pedia exports (accommodation / poi / restaurant). ~40-65% of accommodation & poi rows are
    column-shifted (name holds a longitude, `polarity` holds a URL). Those rows are excluded."""
    name = df["name"].astype(str).str.strip()
    numeric_name = name.str.fullmatch(_NUMERIC) | (name == "") | (name.str.lower() == "nan")
    shifted = df["polarity"].astype(str).str.startswith("http")
    wrong_city = df["location"].astype(str) != "Dubai"
    lat = pd.to_numeric(df["lat"], errors="coerce")
    lng = pd.to_numeric(df["lng"], errors="coerce")
    bad_geo = ~(lat.between(*DUBAI_LAT) & lng.between(*DUBAI_LNG))
    bad = numeric_name | shifted | wrong_city | bad_geo
    report = {
        "column_shifted_rows": int(shifted.sum()),
        "numeric_or_empty_name": int(numeric_name.sum()),
        "location_not_dubai": int(wrong_city.sum()),
        "bad_coordinates": int(bad_geo.sum()),
    }
    return (~bad).to_numpy(), report


def _food_mask(df: pd.DataFrame) -> tuple[np.ndarray, dict]:
    ok = df["restaurant_name"].notna() & (df["dish_price_aed"] > 0) & (df["estimated_cost_for_two_aed"] > 0)
    return ok.to_numpy(), {"invalid_rows": int((~ok).sum())}


def _transport_mask(df: pd.DataFrame) -> tuple[np.ndarray, dict]:
    ok = df["transport_id"].notna() & df["transport_name"].notna()
    return ok.to_numpy(), {"invalid_rows": int((~ok).sum())}


@dataclass(frozen=True)
class ModelSpec:
    key: str
    filename: str
    purpose: str
    required_columns: tuple[str, ...]
    mask_fn: Callable[[pd.DataFrame], tuple[np.ndarray, dict]]
    probe_query: str


SPECS: dict[str, ModelSpec] = {
    "accommodation": ModelSpec(
        "accommodation", "dubai_accommodation_model.pkl", "Hotel / accommodation similarity search",
        ("name", "subCategory", "address", "lat", "lng", "location", "polarity", "combined_features"),
        _tourpedia_mask, "hotel",
    ),
    "poi": ModelSpec(
        "poi", "dubai_poi_model.pkl", "Points-of-interest similarity search",
        ("name", "subCategory", "address", "lat", "lng", "location", "polarity", "combined_features"),
        _tourpedia_mask, "landmark",
    ),
    "restaurant": ModelSpec(
        "restaurant", "dubai_restaurant_model.pkl", "Restaurant / cafe similarity search",
        ("name", "subCategory", "address", "lat", "lng", "location", "polarity", "combined_features"),
        _tourpedia_mask, "restaurant",
    ),
    "food": ModelSpec(
        "food", "dubai_food_model.pkl", "Dish + restaurant search with AED prices (synthetic demo data)",
        ("restaurant_name", "cuisine", "area", "food_category", "recommended_dish", "dish_price_aed",
         "estimated_cost_for_two_aed", "rating_demo", "dietary_tags", "data_type", "combined_features"),
        _food_mask, "vegetarian",
    ),
    "transportation": ModelSpec(
        "transportation", "dubai_transportation_model.pkl", "Transport mode search with AED fares",
        ("transport_id", "transport_name", "transport_category", "base_cost", "cost_band_2", "cost_band_3",
         "cost_unit", "currency", "data_confidence", "combined_features"),
        _transport_mask, "taxi",
    ),
}


@dataclass
class ModelBundle:
    spec: ModelSpec
    vectorizer: object
    model: object
    data: pd.DataFrame
    valid: np.ndarray
    exclusion_report: dict
    sklearn_version: str | None
    checksum_ok: bool | None
    lat: np.ndarray | None = None
    lng: np.ndarray | None = None
    extra: dict = field(default_factory=dict)

    @property
    def usable_rows(self) -> int:
        return int(self.valid.sum())


class MLService:
    def __init__(self) -> None:
        self.bundles: dict[str, ModelBundle] = {}
        self.failures: dict[str, str] = {}
        self._cache: dict[tuple, tuple[np.ndarray, np.ndarray]] = {}

    # ----------------------------------------------------------------- loading
    def load_all(self, models_dir: Path | None = None) -> None:
        models_dir = Path(models_dir or settings.models_dir)
        sums = self._read_checksums(models_dir)
        self.bundles.clear(), self.failures.clear(), self._cache.clear()
        for key, spec in SPECS.items():
            try:
                self.bundles[key] = self._load_one(models_dir, spec, sums)
                b = self.bundles[key]
                log.info("Loaded %-14s rows=%d usable=%d", key, len(b.data), b.usable_rows)
            except Exception as exc:  # noqa: BLE001 - we record and surface every failure reason
                self.failures[key] = f"{type(exc).__name__}: {exc}"[:300]
                log.error("Model '%s' failed to load: %s", key, self.failures[key])

    @staticmethod
    def _read_checksums(models_dir: Path) -> dict[str, str]:
        f = models_dir / "SHA256SUMS.txt"
        out: dict[str, str] = {}
        if f.exists():
            for line in f.read_text().splitlines():
                parts = line.split()
                if len(parts) == 2:
                    out[parts[1].lstrip("*")] = parts[0]
        return out

    def _load_one(self, models_dir: Path, spec: ModelSpec, sums: dict[str, str]) -> ModelBundle:
        path = models_dir / spec.filename
        if not path.exists():
            raise FileNotFoundError(f"{spec.filename} not found in {models_dir}")
        raw = path.read_bytes()  # read-only; file is never rewritten
        checksum_ok = (hashlib.sha256(raw).hexdigest() == sums[spec.filename]) if spec.filename in sums else None
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            obj = pickle.loads(raw)  # only load trusted files you created yourself

        if not isinstance(obj, dict) or not {"vectorizer", "model", "data"} <= obj.keys():
            raise ValueError("pickle is not the expected {'vectorizer','model','data'} dict")
        vec, model, data = obj["vectorizer"], obj["model"], obj["data"]
        if not hasattr(vec, "transform") or not hasattr(model, "kneighbors"):
            raise ValueError("vectorizer/model objects do not expose transform()/kneighbors()")
        if not isinstance(data, pd.DataFrame):
            raise ValueError("'data' is not a DataFrame")
        missing = [c for c in spec.required_columns if c not in data.columns]
        if missing:
            raise ValueError(f"data is missing required columns: {missing}")
        fitted = getattr(model, "n_samples_fit_", None)
        if fitted is not None and fitted != len(data):
            raise ValueError(f"model was fitted on {fitted} rows but data has {len(data)}")

        data = data.reset_index(drop=True)
        valid, report = spec.mask_fn(data)
        bundle = ModelBundle(
            spec=spec, vectorizer=vec, model=model, data=data, valid=valid, exclusion_report=report,
            sklearn_version=getattr(model, "__getstate__", lambda: {})().get("_sklearn_version"),
            checksum_ok=checksum_ok,
        )
        if "lat" in data.columns:
            bundle.lat = pd.to_numeric(data["lat"], errors="coerce").to_numpy(dtype=float)
            bundle.lng = pd.to_numeric(data["lng"], errors="coerce").to_numpy(dtype=float)
        # probe: proves transform + kneighbors work with the installed scikit-learn
        self._neighbors(bundle, spec.probe_query)
        return bundle

    # ----------------------------------------------------------------- querying
    def get(self, key: str) -> ModelBundle:
        if key in self.bundles:
            return self.bundles[key]
        raise ModelUnavailableError(key, self.failures.get(key, "model not loaded"))

    def _neighbors(self, b: ModelBundle, query: str) -> tuple[np.ndarray, np.ndarray]:
        ck = (b.spec.key, query)
        if ck in self._cache:
            return self._cache[ck]
        X = b.vectorizer.transform([query])
        dist, idx = b.model.kneighbors(X, n_neighbors=len(b.data))  # rank EVERY row, filter afterwards
        result = (idx[0], 1.0 - dist[0])
        if len(self._cache) > 512:
            self._cache.clear()
        self._cache[ck] = result
        return result

    def search(
        self,
        key: str,
        query: str,
        *,
        top_k: int = 10,
        row_mask: np.ndarray | None = None,
        dedupe_on: str | None = None,
        min_similarity: float = 1e-9,
    ) -> list[tuple[int, float]]:
        """Return [(row_index, cosine_similarity)] best-first. Rows with zero text overlap are dropped
        (similarity 0 means the model found *nothing* relevant - we never pad with unrelated rows)."""
        b = self.get(key)
        query = (query or "").strip()
        if not query:
            return []
        idx, sim = self._neighbors(b, query)
        ok = b.valid[idx]
        if row_mask is not None:
            ok &= row_mask[idx]
        ok &= sim >= min_similarity
        out, seen = [], set()
        for i, s in zip(idx[ok], sim[ok]):
            if dedupe_on:
                v = str(b.data.at[int(i), dedupe_on]).strip().lower()
                if v in seen:
                    continue
                seen.add(v)
            out.append((int(i), float(s)))
            if len(out) >= top_k:
                break
        return out

    # ----------------------------------------------------------------- reporting
    def status(self) -> dict:
        models = {}
        for key, spec in SPECS.items():
            if key in self.bundles:
                b = self.bundles[key]
                models[key] = {
                    "available": True, "file": spec.filename, "purpose": spec.purpose,
                    "total_rows": len(b.data), "usable_rows": b.usable_rows,
                    "excluded_rows": len(b.data) - b.usable_rows, "exclusion_breakdown": b.exclusion_report,
                    "trained_with_sklearn": b.sklearn_version, "file_unmodified": b.checksum_ok,
                }
            else:
                models[key] = {"available": False, "file": spec.filename, "purpose": spec.purpose,
                               "reason": self.failures.get(key, "not loaded")}
        return {"all_available": len(self.bundles) == len(SPECS), "models": models}


ml_service = MLService()

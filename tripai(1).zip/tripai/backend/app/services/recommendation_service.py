"""
Recommendation logic on top of the five NearestNeighbors models.

Each public function: builds a transparent text query from the user's inputs -> asks ml_service for the nearest
rows -> applies explicit, documented filters -> returns plain JSON-serialisable dicts. The `query_used` and
`notes` fields are always returned so the UI can show *how* a result was found.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache

import numpy as np
import pandas as pd

from ..config import settings
from ..utils.geo import haversine_km
from .ml_service import ml_service

SYNTHETIC_LABEL = "Synthetic demo data - not verified. Confirm restaurant, dish and price before relying on it."

# --------------------------------------------------------------------------- areas (editorial)
@lru_cache(maxsize=1)
def load_areas() -> list[dict]:
    return json.loads((settings.data_dir / "dubai_areas.json").read_text(encoding="utf-8"))["areas"]


def nearest_area(lat: float | None, lng: float | None, max_km: float = 8.0) -> dict | None:
    if lat is None or lng is None or np.isnan(lat) or np.isnan(lng):
        return None
    best, best_d = None, 1e9
    for a in load_areas():
        d = haversine_km(lat, lng, a["lat"], a["lng"])
        if d < best_d:
            best, best_d = a, d
    if best is None or best_d > max_km:
        return None
    return {"slug": best["slug"], "name": best["name"], "distance_km": round(best_d, 1)}


def area_by_slug(slug: str) -> dict | None:
    return next((a for a in load_areas() if a["slug"] == slug), None)


def area_by_name(name: str | None) -> dict | None:
    if not name:
        return None
    n = name.strip().lower()
    return next((a for a in load_areas() if a["name"].lower() == n or a["slug"] == n), None)


# --------------------------------------------------------------------------- helpers
def _clean(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    s = str(v).strip()
    return None if s.lower() in {"", "nan", "dubai", "none"} else s


def _maps_url(lat, lng) -> str | None:
    if lat is None or lng is None or np.isnan(lat) or np.isnan(lng):
        return None
    return f"https://www.google.com/maps/search/?api=1&query={lat:.6f},{lng:.6f}"


def _place(b, i: int, sim: float, **extra) -> dict:
    row = b.data.iloc[i]
    lat, lng = (float(b.lat[i]), float(b.lng[i])) if b.lat is not None else (None, None)
    return {
        "name": _clean(row["name"]), "category": _clean(row["subCategory"]), "address": _clean(row["address"]),
        "lat": lat, "lng": lng, "area": nearest_area(lat, lng), "maps_url": _maps_url(lat, lng),
        "similarity": round(sim, 3), **extra,
    }


def _mask_by(b, fn) -> np.ndarray:
    return fn(b.data).to_numpy()


def _words(*parts) -> str:
    return " ".join(p for p in parts if p).strip()


# --------------------------------------------------------------------------- hotels
HOTEL_SUBCATS = {"Hotel", "Resort", "Bed & Breakfast", "Hostel", "Motel"}
HOTEL_QUERY_BY_TYPE = {
    "adventure": "Resort Beach", "family": "Resort Beach Hotel", "couple": "Resort Beach Hotel",
    "solo": "Hostel Hotel", "business": "Hotel Sheikh Zayed", "religious": "Hotel Deira Bur Dubai",
    "friends": "Resort Hotel Beach", "luxury": "Resort Hotel Beach",
}


def recommend_hotels(travel_type: str | None, keywords: str | None, area: str | None, limit: int = 8) -> dict:
    b = ml_service.get("accommodation")
    base = HOTEL_QUERY_BY_TYPE.get((travel_type or "").lower(), "Hotel Resort")
    a = area_by_name(area)
    query = _words(base, keywords, a["name"].split()[0] if a and not keywords else None)
    mask = _mask_by(b, lambda d: d["subCategory"].isin(HOTEL_SUBCATS))
    hits = ml_service.search("accommodation", query, top_k=limit * 4 if a else limit, row_mask=mask, dedupe_on="name")
    items = [_place(b, i, s, price_info="Not in dataset - enter your own nightly rate in the budget estimator.")
             for i, s in hits]
    if a:  # keep only hotels within ~2x the area's radius
        items = [p for p in items if p["lat"] is not None
                 and haversine_km(p["lat"], p["lng"], a["lat"], a["lng"]) <= max(a["radius_km"] * 2, 4)]
    return {
        "query_used": query, "items": items[:limit], "model": "accommodation",
        "notes": ["Hotel prices and availability are not in the dataset and are never invented.",
                  "Results are text-similarity matches on hotel name, type and address."],
    }


# --------------------------------------------------------------------------- attractions
_ATTR_DENY = re.compile(
    r"container|terminal|berth|drydock|security|substation|port of|jebel ali|airlines|visa|office|parking|in car|"
    r"waiting|exit \d|dewa|freezone|headquarters|bldg|consulate|training|marinetech|marine concept|costa|aida|msc|"
    r"queen elizabeth|brillance|radison|mumm|logos hope|moving|travel show|techmobile|mission|italy|london|"
    r"roundabout|\bm/y\b|seamans|airline|flight|ghost|gugu|eman-1|tayyab|khasab|fujairah|savona|travel|"
    r"transport station|floating restaurant|^dubai marina$|^boat$|jumeirah boat", re.I)
_BOAT_OK = re.compile(r"dhow|abra|cruise|wharf|water taxi|ferry|creek|marina|boat tour|cruising|floating", re.I)
_TOUR_OK = re.compile(r"\btours?\b|excursion|safari|marine", re.I)


def attraction_kind(df: pd.DataFrame) -> pd.Series:
    """Label rows that are genuinely visitable sights/experiences; everything else -> NaN.
    The POI pickle is mostly roads, hospitals, parking, airports etc., so this allow-list is essential."""
    name, sub, addr = df["name"].astype(str), df["subCategory"].astype(str), df["address"]
    kind = pd.Series(np.nan, index=df.index, dtype="object")
    deny = name.str.contains(_ATTR_DENY)
    kind[(sub == "Monument / Landmark") & addr.notna() & ~deny] = "Landmark / heritage"
    kind[sub.isin(["Pier", "Boat or Ferry"]) & name.str.contains(_BOAT_OK) & ~deny] = "Boat / waterfront experience"
    kind[(sub == "Tourist Information Center") & name.str.contains(_TOUR_OK) & ~deny
         & ~name.str.contains("Airlines|Travel Show|Visa", case=False)] = "Tour operator (activity provider)"
    return kind


def _attr_state():
    b = ml_service.get("poi")
    if "attr_kind" not in b.extra:
        b.extra["attr_kind"] = attraction_kind(b.data)
    return b, b.extra["attr_kind"]


ATTR_QUERY_BY_TYPE = {
    "adventure": "Dhow Cruise Marina Creek Boat", "family": "Zoo Village Heritage Landmark",
    "couple": "Dhow Cruise Creek Marina", "solo": "Souk Heritage Bastakiya House",
    "business": "Landmark Tours Heritage", "religious": "Mosque Majlis Heritage House",
    "friends": "Dhow Cruise Marina Souk", "luxury": "Dhow Cruise Marina Landmark",
}
SLOT_QUERIES = {
    "morning": "Mosque Souk Heritage House Village Bastakiya Majlis Landmark",
    "afternoon": "Zoo Gallery Stadium Heritage Landmark Tours Tour",
    "evening": "Dhow Cruise Creek Marina Wharf Abra Boat",
}


def recommend_attractions(travel_type: str | None, keywords: str | None, area: str | None,
                          limit: int = 10, query_override: str | None = None) -> dict:
    b, kind = _attr_state()
    base = query_override or ATTR_QUERY_BY_TYPE.get((travel_type or "").lower(), "Landmark Heritage Dhow Souk")
    query = _words(base, keywords)
    mask = kind.notna().to_numpy()
    hits = ml_service.search("poi", query, top_k=200, row_mask=mask, dedupe_on="name")
    a = area_by_name(area)
    items = []
    for i, s in hits:
        p = _place(b, i, s, kind=kind.iat[i],
                   ticket_price="Not in dataset", note="Verify opening hours and entry fees before you go.")
        if a and (p["lat"] is None or haversine_km(p["lat"], p["lng"], a["lat"], a["lng"]) > max(a["radius_km"] * 2, 4)):
            continue
        items.append(p)
        if len(items) >= limit:
            break
    return {
        "query_used": query, "items": items, "model": "poi",
        "pool_size": int(mask.sum()),
        "notes": [f"The POI dataset contains only ~{int(mask.sum())} genuine visitable places "
                  "(most of its rows are roads, hospitals, parking, airports, etc., which are filtered out).",
                  "Ticket prices and opening hours are not in the dataset."],
    }


# --------------------------------------------------------------------------- restaurants (tour-pedia)
NON_MEAL = {"Coffee Shop", "Tea Room", "Juice Bar", "Ice Cream Shop", "Dessert Shop", "Bakery", "Cupcake Shop",
            "Donut Shop", "Frozen Yogurt", "Bagel Shop", "Snack Place", "Hotel", "Winery", "Hookah Bar",
            "Food Truck", "Cafeteria", "Food Court"}
VEG_CATS = ["Vegetarian / Vegan Restaurant"]
VEG_FRIENDLY = {"Vegetarian / Vegan Restaurant", "Indian Restaurant", "Falafel Restaurant", "Salad Place",
                "Mediterranean Restaurant", "Middle Eastern Restaurant", "Italian Restaurant", "Pizza Place",
                "Asian Restaurant", "Thai Restaurant", "Chinese Restaurant", "Restaurant", "Café"}
NONVEG_DEFAULT = {"Steakhouse", "BBQ Joint", "Seafood Restaurant", "Fried Chicken Joint", "Burger Joint",
                  "Middle Eastern Restaurant", "Indian Restaurant", "Turkish Restaurant", "Lebanese Restaurant"}


def recommend_restaurants(food_preference: str, cuisine: str | None, area: str | None,
                          keywords: str | None, limit: int = 8, meals_only: bool = True) -> dict:
    b = ml_service.get("restaurant")
    pref = (food_preference or "both").lower()
    sub = b.data["subCategory"]
    allowed = ~sub.isin(NON_MEAL) if meals_only else pd.Series(True, index=b.data.index)
    notes = ["The restaurant dataset has no menu, price or dietary data - only name, category and location."]
    if pref == "vegetarian":
        allowed &= sub.isin(VEG_FRIENDLY)
        base = "Vegetarian Indian Falafel"
        notes.append("Vegetarian filter = categories commonly vegetarian-friendly (not verified per venue). "
                     "Places explicitly categorised 'Vegetarian / Vegan Restaurant' or with 'Vegetarian' in their "
                     "name are ranked as strongest matches.")
    elif pref == "non-vegetarian":
        allowed &= ~sub.isin(VEG_CATS)
        base = "Steakhouse BBQ Seafood Grill Kebab"
    else:
        base = "Restaurant"
    query = _words(base, cuisine, keywords)
    a = area_by_name(area)
    hits = ml_service.search("restaurant", query, top_k=limit * (6 if a else 1), row_mask=allowed.to_numpy(),
                             dedupe_on="name")
    items = []
    for i, s in hits:
        p = _place(b, i, s, price_info="Not in dataset",
                   diet_verified=bool(pref == "vegetarian" and (sub.iat[i] in VEG_CATS or "vegetarian" in str(b.data.at[i, "name"]).lower())))
        if a and (p["lat"] is None or haversine_km(p["lat"], p["lng"], a["lat"], a["lng"]) > max(a["radius_km"] * 2, 4)):
            continue
        items.append(p)
        if len(items) >= limit:
            break
    return {"query_used": query, "items": items, "model": "restaurant", "notes": notes}


# --------------------------------------------------------------------------- food (synthetic, has prices)
def _food_veg_mask(df: pd.DataFrame, pref: str) -> np.ndarray:
    cat = df["food_category"]
    if pref == "vegetarian":
        # Strict: a 'Both' restaurant's recommended dish may contain meat, so only rows whose dish is vegetarian count.
        return np.array(cat == "Vegetarian", dtype=bool)  # writable copy (pandas 3 is copy-on-write)
    if pref == "non-vegetarian":
        return np.array(cat == "Non-vegetarian", dtype=bool)
    return np.ones(len(df), dtype=bool)


def food_rows(food_preference: str, cuisine: str | None = None, area: str | None = None,
              max_cost_for_two: float | None = None) -> pd.DataFrame:
    """Plain filtered view of the food dataset (used by the budget service for price statistics)."""
    b = ml_service.get("food")
    m = np.array(b.valid) & _food_veg_mask(b.data, (food_preference or "both").lower())
    df = b.data
    if cuisine:
        m &= np.array(df["cuisine"].str.contains(cuisine, case=False, na=False))
    if area:
        m &= np.array(df["area"].str.lower().eq(area.strip().lower()))
    if max_cost_for_two:
        m &= np.array(df["estimated_cost_for_two_aed"] <= max_cost_for_two)
    return df[m]


def recommend_food(food_preference: str, cuisine: str | None, area: str | None, keywords: str | None,
                   max_cost_for_two: float | None, limit: int = 8) -> dict:
    b = ml_service.get("food")
    pref = (food_preference or "both").lower()
    mask = _food_veg_mask(b.data, pref)
    df = b.data
    if cuisine:
        mask &= np.array(df["cuisine"].str.contains(cuisine, case=False, na=False))
    if area:
        mask &= np.array(df["area"].str.lower().eq(area.strip().lower()))
    if max_cost_for_two:
        mask &= np.array(df["estimated_cost_for_two_aed"] <= max_cost_for_two)
    base = {"vegetarian": "Vegetarian", "non-vegetarian": "Non-vegetarian"}.get(pref, "")
    query = _words(base, cuisine, area, keywords) or "restaurant"
    hits = ml_service.search("food", query, top_k=limit, row_mask=mask)
    if not hits and mask.any():  # query matched nothing lexically -> rank filtered rows by rating (deterministic, labelled)
        sub = df[mask].sort_values("rating_demo", ascending=False).head(limit)
        hits = [(int(i), 0.0) for i in sub.index]
        query += " (no text match; ranked by demo rating)"
    items = []
    for i, s in hits:
        r = df.iloc[i]
        items.append({
            "restaurant": r["restaurant_name"], "cuisine": r["cuisine"], "area": r["area"],
            "food_category": r["food_category"], "recommended_dish": r["recommended_dish"],
            "dish_price_aed": float(r["dish_price_aed"]),
            "estimated_cost_for_two_aed": float(r["estimated_cost_for_two_aed"]),
            "rating_demo": float(r["rating_demo"]), "facilities": r["facilities"],
            "dietary_tags": r["dietary_tags"], "similarity": round(s, 3),
            "data_confidence": "synthetic", "disclaimer": SYNTHETIC_LABEL,
        })
    return {"query_used": query, "items": items, "model": "food", "currency": "AED",
            "notes": [SYNTHETIC_LABEL, "Ratings are demo values, not real reviews."]}


# --------------------------------------------------------------------------- transport
TRANSPORT_QUERY_BY_PREF = {
    "public": "Rail Bus Metro Tram Public", "metro": "Metro Rail Public", "taxi": "Taxi Public taxi",
    "ride-hailing": "Ride-hailing Uber Careem", "rental-car": "Rental car Car rental",
    "walking": "Walking Active travel Bike Micromobility", "water": "Water transport Abra",
    "mixed": "Metro Bus Taxi Public", "any": "Public Taxi Rail",
}


def fare_summary(r: pd.Series) -> dict:
    def f(x):
        return None if pd.isna(x) else float(x)
    return {"base": f(r["base_cost"]), "band_2": f(r["cost_band_2"]), "band_3": f(r["cost_band_3"])}


def recommend_transport(preference: str | None, include_airport: bool, limit: int = 6) -> dict:
    b = ml_service.get("transportation")
    pref = (preference or "mixed").lower()
    query = TRANSPORT_QUERY_BY_PREF.get(pref, TRANSPORT_QUERY_BY_PREF["mixed"])
    df = b.data
    mask = np.ones(len(df), dtype=bool)
    if not include_airport:
        mask &= np.array(~df["transport_id"].str.startswith("airport"))
    hits = ml_service.search("transportation", query, top_k=limit, row_mask=mask)
    items = []
    for i, s in hits:
        r = df.iloc[i]
        fare = fare_summary(r)
        items.append({
            "id": r["transport_id"], "name": r["transport_name"], "category": r["transport_category"],
            "ownership": r["ownership_type"], "fare_aed": fare, "fare_unit": r["cost_unit"],
            "fare_rule": r["fare_rule_or_cost_description"], "booking_required": r["booking_required"],
            "accessibility": r["accessibility_features"], "data_confidence": str(r["data_confidence"]).lower(),
            "quote_needed": fare["base"] is None, "verification_notes": r["verification_notes"],
            "similarity": round(s, 3),
        })
    return {"query_used": query, "items": items, "model": "transportation", "currency": "AED",
            "notes": ["Taxi/airport figures are STARTING fares only; the meter adds distance and time.",
                      "Ride-hailing, water-taxi fares are dynamic quotes and are not included in totals."]}


# --------------------------------------------------------------------------- destination areas
def recommend_areas(travel_type: str | None, keywords: str | None, limit: int = 5) -> dict:
    """Rank Dubai areas by how many of the POI model's best attraction matches fall inside them."""
    b, kind = _attr_state()
    base = ATTR_QUERY_BY_TYPE.get((travel_type or "").lower(), "Landmark Heritage Dhow Souk")
    query = _words(base, keywords)
    hits = ml_service.search("poi", query, top_k=500, row_mask=kind.notna().to_numpy(), dedupe_on="name")
    scores: dict[str, dict] = {}
    for i, s in hits:
        a = nearest_area(float(b.lat[i]), float(b.lng[i]), max_km=6.0)
        if not a:
            continue
        e = scores.setdefault(a["slug"], {"score": 0.0, "matches": []})
        e["score"] += s
        e["matches"].append(_clean(b.data.at[i, "name"]))
    ranked = sorted(scores.items(), key=lambda kv: -kv[1]["score"])[:limit]
    items = []
    for slug, e in ranked:
        a = area_by_slug(slug)
        items.append({"slug": slug, "name": a["name"], "description": a["description"],
                      "known_for": a["known_for"], "score": round(e["score"], 3),
                      "matching_attractions": e["matches"][:6]})
    return {"query_used": query, "items": items, "model": "poi",
            "notes": ["Area ranking = summed similarity of the POI model's attraction matches near each area.",
                      "Area descriptions are editorial text, not model output."]}


# --------------------------------------------------------------------------- destination explorer helpers
def attraction_pool() -> list[dict]:
    b, kind = _attr_state()
    idx = np.flatnonzero(kind.notna().to_numpy() & b.valid)
    seen, out = set(), []
    for i in idx:
        p = _place(b, int(i), 0.0, kind=kind.iat[int(i)], ticket_price="Not in dataset")
        key = (p["name"] or "").lower()
        if key and key not in seen:
            seen.add(key)
            out.append(p)
    return out


def area_summary(a: dict, pool: list[dict]) -> dict:
    near = [p for p in pool if p["lat"] is not None and haversine_km(p["lat"], p["lng"], a["lat"], a["lng"]) <= max(a["radius_km"] * 2, 4)]
    fr = ml_service.get("food").data
    n_food = int((fr["area"].str.lower() == a["name"].lower()).sum())
    return {"slug": a["slug"], "name": a["name"], "description": a["description"], "known_for": a["known_for"],
            "good_for": a["good_for"], "lat": a["lat"], "lng": a["lng"], "attraction_count": len(near),
            "food_record_count": n_food, "source": "editorial description + POI/food model counts"}


def area_detail(slug: str) -> dict | None:
    a = area_by_slug(slug)
    if not a:
        return None
    pool = attraction_pool()
    base = area_summary(a, pool)
    attractions = sorted(
        (p for p in pool if p["lat"] is not None and haversine_km(p["lat"], p["lng"], a["lat"], a["lng"]) <= max(a["radius_km"] * 2, 4)),
        key=lambda p: haversine_km(p["lat"], p["lng"], a["lat"], a["lng"]))
    activities: dict[str, int] = {}
    for p in attractions:
        activities[p["kind"]] = activities.get(p["kind"], 0) + 1
    fr = food_rows("both", None, a["name"])
    food = {}
    if not fr.empty:
        pp = fr["estimated_cost_for_two_aed"] / 2
        food = {"records": int(len(fr)), "per_person_per_meal_aed": {"low": float(pp.quantile(.25)), "median": float(pp.median()), "high": float(pp.quantile(.75))},
                "popular_cuisines": fr["cuisine"].value_counts().head(4).index.tolist(),
                "sample_dishes": fr["recommended_dish"].value_counts().head(5).index.tolist(), "data_confidence": "synthetic",
                "disclaimer": SYNTHETIC_LABEL}
    hb = ml_service.get("accommodation")
    ok = hb.valid & np.array(hb.data["subCategory"].isin(HOTEL_SUBCATS))
    hotels = []
    for i in np.flatnonzero(ok):
        d = haversine_km(hb.lat[i], hb.lng[i], a["lat"], a["lng"])
        if d <= max(a["radius_km"] * 1.5, 3):
            hotels.append((d, int(i)))
    hotels = [_place(hb, i, 0.0, distance_km=round(d, 1)) for d, i in sorted(hotels)[:6]]
    metro = ml_service.get("transportation").data
    m = metro[metro["transport_id"] == "metro"].iloc[0]
    return {**base, "attractions": attractions[:20], "activity_types": activities, "food": food, "hotels_nearby": hotels,
            "estimated_expenses": {
                "food": food.get("per_person_per_meal_aed"), "food_note": SYNTHETIC_LABEL if food else "No food records for this area.",
                "public_transport_per_ride_aed": fare_summary(m), "accommodation": "Not in dataset - enter your own rate in the budget estimator",
                "activities": "Ticket prices not in dataset"},
            "notes": ["Attractions are the POI dataset's visitable places within ~2x the area radius.",
                      "Area description is editorial text written for TripAI, not model output."]}

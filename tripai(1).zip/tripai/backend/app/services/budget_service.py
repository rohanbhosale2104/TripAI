"""
Budget estimator. Every number is traceable to either (a) a column in your food / transport pickles or
(b) a value the traveller typed in. Nothing is guessed. Components with no data are listed under
`missing_components` instead of being given a made-up price.
"""
from __future__ import annotations

from math import ceil

import numpy as np

from ..schemas.common import BudgetRequest
from .ml_service import ml_service
from .recommendation_service import SYNTHETIC_LABEL, food_rows

CATEGORY_ORDER = ["accommodation", "food", "local_transport", "airport_transfers", "activities", "flights", "other"]


def _line(category, label, *, estimate, low=None, high=None, source, confidence, note="",
          lower_bound=False, unit_detail=""):
    return {
        "category": category, "label": label,
        "estimate": None if estimate is None else round(float(estimate), 2),
        "low": None if estimate is None else round(float(low if low is not None else estimate), 2),
        "high": None if estimate is None else round(float(high if high is not None else estimate), 2),
        "source": source, "confidence": confidence, "note": note,
        "is_lower_bound": lower_bound, "detail": unit_detail,
    }


def _fare_row(transport_id: str):
    df = ml_service.get("transportation").data
    r = df[df["transport_id"] == transport_id]
    return None if r.empty else r.iloc[0]


def _num(x):
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else float(x)


def food_stats(food_preference: str, cuisine: str | None = None, area: str | None = None) -> dict | None:
    """Per-person, per-meal cost statistics from the (synthetic) food dataset."""
    rows = food_rows(food_preference, cuisine, area)
    if rows.empty and (cuisine or area):
        rows = food_rows(food_preference)  # fall back to preference-only, reported via `basis`
    if rows.empty:
        return None
    pp = rows["estimated_cost_for_two_aed"] / 2.0
    return {"median": float(pp.median()), "p25": float(pp.quantile(0.25)), "p75": float(pp.quantile(0.75)),
            "n": int(len(rows))}


def transport_lines(req: BudgetRequest) -> tuple[list[dict], list[str]]:
    lines, missing = [], []
    pref, days, n = req.transport_preference, req.days, req.travellers
    vehicles = ceil(n / 4)

    def public(rides_pp_day: int, label: str):
        r = _fare_row("metro")
        if r is None or _num(r["base_cost"]) is None:
            missing.append("Public transit fares (not in transport dataset)")
            return
        low, mid, high = _num(r["base_cost"]), _num(r["cost_band_2"]) or _num(r["base_cost"]), _num(r["cost_band_3"]) or _num(r["base_cost"])
        k = rides_pp_day * days * n
        lines.append(_line("local_transport", label, estimate=k * mid, low=k * low, high=k * high,
                           source="transport model: Dubai Metro/Bus fare bands (AED 3 / 5 / 7.5 per journey)",
                           confidence=str(r["data_confidence"]).lower(),
                           unit_detail=f"{rides_pp_day} ride(s) x {days} days x {n} travellers",
                           note="Low = 1-zone fare, estimate = 2-zone fare, high = 3+ zone fare."))

    def taxi(rides_day: int, label: str):
        r = _fare_row("taxi")
        if r is None or _num(r["base_cost"]) is None:
            missing.append("Taxi fares (not in transport dataset)")
            return
        k = rides_day * days * vehicles
        lines.append(_line("local_transport", label, estimate=k * _num(r["base_cost"]), source="transport model: Dubai RTA Taxi starting fare",
                           confidence=str(r["data_confidence"]).lower(), lower_bound=True,
                           unit_detail=f"{rides_day} ride(s) x {days} days x {vehicles} taxi(s)",
                           note="Starting fare only - the meter adds distance and time, so real cost is higher."))

    if pref in ("public", "metro"):
        public(req.local_rides_per_day, "Metro / bus / tram rides")
    elif pref == "taxi":
        taxi(req.taxi_rides_per_day, "Taxi rides (starting fares)")
    elif pref == "mixed":
        public(max(req.local_rides_per_day // 2, 0), "Metro / bus rides (half of daily trips)")
        taxi(max(req.taxi_rides_per_day // 2, 0) or (1 if req.taxi_rides_per_day else 0), "Taxi rides (starting fares)")
    elif pref == "rental-car":
        r = _fare_row("rental_car")
        if r is not None and _num(r["base_cost"]) is not None:
            lines.append(_line("local_transport", "Rental car (illustrative starting budget)",
                               estimate=_num(r["base_cost"]) * days * vehicles, confidence=str(r["data_confidence"]).lower(),
                               source="transport model: Rental car illustrative daily starting budget",
                               lower_bound=True, unit_detail=f"{days} days x {vehicles} car(s)",
                               note="Excludes fuel, insurance, deposit, Salik tolls and parking. Get a real quote."))
    elif pref == "ride-hailing":
        missing.append("Ride-hailing (Uber/Careem) fares are dynamic quotes - not in dataset, not estimated")
    elif pref == "water":
        r = _fare_row("abra")
        if r is not None and _num(r["base_cost"]) is not None:
            k = 2 * days * n
            lines.append(_line("local_transport", "Traditional abra crossings (illustrative)", estimate=k * _num(r["base_cost"]),
                               source="transport model: Traditional Abra illustrative fare", confidence=str(r["data_confidence"]).lower(),
                               lower_bound=True, unit_detail=f"2 crossings x {days} days x {n} travellers",
                               note="Abras only cover Creek crossings; combine with another mode."))
    elif pref == "walking":
        lines.append(_line("local_transport", "Walking", estimate=0, source="transport model: Walking (no fare)",
                           confidence="high", note="Dubai's heat makes long walks hard for much of the year."))

    if req.include_airport_transfers:
        r = _fare_row("airport_taxi") if n <= 4 else _fare_row("airport_van")
        v = vehicles if n <= 4 else ceil(n / 6)
        if r is not None and _num(r["base_cost"]) is not None:
            lines.append(_line("airport_transfers", f"Airport transfers ({r['transport_name']})", estimate=2 * v * _num(r["base_cost"]),
                               source=f"transport model: {r['transport_name']} starting fare", confidence=str(r["data_confidence"]).lower(),
                               lower_bound=True, unit_detail=f"2 transfers x {v} vehicle(s)",
                               note="Starting fare only; the meter adds distance. Metro is an alternative from the airport."))
    return lines, missing


def estimate_budget(req: BudgetRequest, area: str | None = None) -> dict:
    lines: list[dict] = []
    missing: list[str] = []
    nights = max(req.days - 1, 0)

    # accommodation -- user input only
    if req.hotel_per_night_aed is not None:
        rooms = req.room_count()
        lines.append(_line("accommodation", "Accommodation (your rate)", estimate=req.hotel_per_night_aed * nights * rooms,
                           source="user input", confidence="user-provided",
                           unit_detail=f"AED {req.hotel_per_night_aed:g} x {nights} nights x {rooms} room(s)"))
    else:
        missing.append("Accommodation - enter your nightly rate (hotel prices are not in the dataset)")

    # food -- food dataset (synthetic)
    pp = None
    if req.meals_per_day > 0:
        stats = food_stats(req.food_preference, req.cuisine, area)
        if stats:
            pp = stats
            k = req.travellers * req.days * req.meals_per_day
            lines.append(_line("food", "Food & dining", estimate=k * stats["median"], low=k * stats["p25"], high=k * stats["p75"],
                               source=f"food model: median of {stats['n']} '{req.food_preference}' records (cost-for-two / 2)",
                               confidence="synthetic", unit_detail=f"{req.meals_per_day} meals x {req.days} days x {req.travellers} travellers x AED {stats['median']:.0f} per person-meal",
                               note=SYNTHETIC_LABEL))
        else:
            missing.append("Food - no matching rows in the food dataset")

    t_lines, t_missing = transport_lines(req)
    lines += t_lines
    missing += t_missing

    if req.activities_total_aed is not None:
        lines.append(_line("activities", "Activities & sightseeing (your figure)", estimate=req.activities_total_aed,
                           source="user input", confidence="user-provided"))
    else:
        missing.append("Activities & tickets - enter your own figure (ticket prices are not in the dataset)")
    if req.flights_total_aed is not None:
        lines.append(_line("flights", "Flights (your figure)", estimate=req.flights_total_aed, source="user input", confidence="user-provided"))
    else:
        missing.append("Flights from your origin - not in dataset; enter your own figure if you want it included")
    if req.other_costs_aed:
        lines.append(_line("other", "Other costs (your figure)", estimate=req.other_costs_aed, source="user input", confidence="user-provided"))

    priced = [l for l in lines if l["estimate"] is not None]
    total = round(sum(l["estimate"] for l in priced), 2)
    low = round(sum(l["low"] for l in priced), 2)
    high = round(sum(l["high"] for l in priced), 2)
    by_cat: dict[str, float] = {}
    for l in priced:
        by_cat[l["category"]] = round(by_cat.get(l["category"], 0) + l["estimate"], 2)
    breakdown = [{"category": c, "amount": by_cat[c]} for c in CATEGORY_ORDER if c in by_cat]
    has_lb = any(l["is_lower_bound"] for l in priced)
    remaining = round(req.budget_aed - total, 2)

    if total > req.budget_aed:
        status, msg = "over_budget", f"Known costs exceed your budget by AED {abs(remaining):,.0f}."
    elif missing:
        status, msg = "within_budget_incomplete", (f"Known costs use AED {total:,.0f} of AED {req.budget_aed:,.0f}; "
                                                    "some components are not priced yet (see list), so the true total will be higher.")
    else:
        status, msg = "within_budget", f"Estimated costs leave AED {remaining:,.0f} of your budget."
    return {
        "currency": "AED", "days": req.days, "nights": nights, "travellers": req.travellers,
        "lines": lines, "breakdown": breakdown, "total_estimate": total, "total_low": low, "total_high": high,
        "budget_aed": req.budget_aed, "remaining_aed": remaining,
        "percent_used": round(100 * total / req.budget_aed, 1), "status": status, "message": msg,
        "includes_lower_bounds": has_lb, "missing_components": missing,
        "per_person_per_meal": pp,
        "notes": ["All amounts are in AED. TripAI does not convert currencies or fetch live prices.",
                  "Food figures come from synthetic demo data in your food model; transport figures are published fare rules or starting fares.",
                  "Items marked 'lower bound' will cost more in practice (metered fares, fuel, deposits)."],
    }

"""MongoDB access through PyMongo (works with MongoDB Compass on the same URI)."""
from __future__ import annotations

import logging

from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.database import Database
from pymongo.errors import PyMongoError

from .config import settings

log = logging.getLogger("tripai.db")
_client = None
_db: Database | None = None


def connect() -> Database:
    """Create the client + indexes. Raises if MongoDB is unreachable."""
    global _client, _db
    if settings.use_mock_db:
        import mongomock  # dev/test only dependency

        _client = mongomock.MongoClient()
        log.warning("USING IN-MEMORY MOCK DATABASE (dev/test only; data is not persisted)")
    else:
        _client = MongoClient(settings.mongodb_uri, serverSelectionTimeoutMS=4000, tz_aware=True)
        _client.admin.command("ping")  # fail fast
    _db = _client[settings.mongodb_db]
    ensure_indexes(_db)
    return _db


def ensure_indexes(db: Database) -> None:
    db.users.create_index([("email", ASCENDING)], unique=True)
    db.trips.create_index([("user_id", ASCENDING), ("updated_at", DESCENDING)])
    # TTL index: revoked tokens vanish automatically once expired
    db.revoked_tokens.create_index("expires_at", expireAfterSeconds=0)


def set_db(db) -> None:
    """Inject a database (used by tests)."""
    global _db
    _db = db
    ensure_indexes(db)


def get_db() -> Database:
    if _db is None:
        raise RuntimeError("Database not connected")
    return _db


def db_status() -> dict:
    try:
        if _db is None:
            return {"connected": False, "detail": "not connected"}
        _db.command("ping")
        return {"connected": True, "database": settings.mongodb_db, "mock": settings.use_mock_db}
    except PyMongoError as exc:
        return {"connected": False, "detail": str(exc)[:200]}


def close() -> None:
    global _client, _db
    if _client is not None:
        _client.close()
    _client, _db = None, None

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from .common import FoodPref, TransportPref, TravelType


class _Base(BaseModel):
    limit: int = Field(8, ge=1, le=30)
    keywords: Optional[str] = Field(None, max_length=120)


class HotelReq(_Base):
    travel_type: Optional[TravelType] = None
    area: Optional[str] = Field(None, max_length=40)


class AttractionReq(HotelReq):
    pass


class DestinationReq(_Base):
    travel_type: Optional[TravelType] = None
    limit: int = Field(5, ge=1, le=10)


class RestaurantReq(_Base):
    food_preference: FoodPref = "both"
    cuisine: Optional[str] = Field(None, max_length=40)
    area: Optional[str] = Field(None, max_length=40)


class FoodReq(RestaurantReq):
    max_cost_for_two_aed: Optional[float] = Field(None, gt=0, le=5000)


class TransportReq(BaseModel):
    transport_preference: TransportPref = "mixed"
    include_airport: bool = True
    limit: int = Field(6, ge=1, le=14)

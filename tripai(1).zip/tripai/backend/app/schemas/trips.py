from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from .common import TripRequest


class TripSave(BaseModel):
    title: Optional[str] = Field(None, max_length=100)
    notes: str = Field("", max_length=2000)
    request: TripRequest


class TripUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=100)
    notes: Optional[str] = Field(None, max_length=2000)
    request: Optional[TripRequest] = Field(None, description="If supplied, the plan is regenerated from it")

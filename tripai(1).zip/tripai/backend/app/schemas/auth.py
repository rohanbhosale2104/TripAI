from __future__ import annotations

import re
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=60)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=64)

    @field_validator("name")
    @classmethod
    def _name(cls, v):
        return " ".join(v.split())

    @field_validator("password")
    @classmethod
    def _pw(cls, v):
        if not (re.search(r"[A-Za-z]", v) and re.search(r"\d", v)):
            raise ValueError("password must contain at least one letter and one number")
        return v


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=1, max_length=64)


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    home_city: str = ""
    preferences: dict = {}
    created_at: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserOut


class ProfileUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=60)
    home_city: Optional[str] = Field(None, max_length=80)
    preferences: Optional[dict] = None

    @field_validator("preferences")
    @classmethod
    def _prefs(cls, v):
        allowed = {"travel_type": str, "food_preference": str, "transport_preference": str, "travellers": int}
        if v is None:
            return v
        clean = {}
        for k, t in allowed.items():
            if k in v and isinstance(v[k], t):
                clean[k] = v[k]
        return clean


class PasswordChange(BaseModel):
    current_password: str = Field(..., max_length=64)
    new_password: str = Field(..., min_length=8, max_length=64)

    @field_validator("new_password")
    @classmethod
    def _pw(cls, v):
        return RegisterRequest._pw(v)

from __future__ import annotations

from datetime import date
from math import ceil
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

TravelType = Literal["adventure", "family", "solo", "couple", "business", "religious", "friends", "luxury"]
FoodPref = Literal["vegetarian", "non-vegetarian", "both"]
TransportPref = Literal["public", "metro", "taxi", "ride-hailing", "rental-car", "walking", "water", "mixed"]


class CostInputs(BaseModel):
    """Costs only the traveller can know. TripAI never invents hotel, activity or flight prices."""
    hotel_per_night_aed: Optional[float] = Field(None, ge=0, le=100000, description="Your own nightly room rate (AED)")
    rooms: Optional[int] = Field(None, ge=1, le=20, description="Defaults to ceil(travellers / 2)")
    activities_total_aed: Optional[float] = Field(None, ge=0, le=1000000, description="Tickets/tours for the whole group")
    flights_total_aed: Optional[float] = Field(None, ge=0, le=1000000, description="Return flights for the whole group")
    other_costs_aed: Optional[float] = Field(None, ge=0, le=1000000)
    meals_per_day: int = Field(2, ge=0, le=3, description="Restaurant meals eaten out per person per day")
    local_rides_per_day: int = Field(4, ge=0, le=20, description="Public-transport rides per person per day")
    taxi_rides_per_day: int = Field(2, ge=0, le=20, description="Taxi rides per day (per vehicle group)")
    include_airport_transfers: bool = True


class BudgetRequest(CostInputs):
    days: int = Field(..., ge=1, le=30)
    travellers: int = Field(..., ge=1, le=20)
    budget_aed: float = Field(..., gt=0, le=10_000_000)
    food_preference: FoodPref = "both"
    transport_preference: TransportPref = "mixed"
    cuisine: Optional[str] = Field(None, max_length=40)

    @field_validator("cuisine")
    @classmethod
    def _strip(cls, v):
        return v.strip() or None if v else v

    def room_count(self) -> int:
        return self.rooms or ceil(self.travellers / 2)


class TripRequest(CostInputs):
    origin: str = Field(..., min_length=2, max_length=80, description="Starting city (free text)")
    destination: Literal["Dubai"] = "Dubai"
    start_date: date
    end_date: date
    travellers: int = Field(..., ge=1, le=20)
    budget_aed: float = Field(..., gt=0, le=10_000_000)
    travel_type: TravelType = "couple"
    preferences: list[str] = Field(default_factory=list, max_length=10)
    transport_preference: TransportPref = "mixed"
    food_preference: FoodPref = "both"
    preferred_area: Optional[str] = Field(None, max_length=40)
    cuisine: Optional[str] = Field(None, max_length=40)

    @field_validator("origin")
    @classmethod
    def _origin(cls, v):
        v = " ".join(v.split())
        if len(v) < 2:
            raise ValueError("origin must have at least 2 characters")
        return v

    @field_validator("preferences")
    @classmethod
    def _prefs(cls, v):
        return [p.strip()[:40] for p in v if p and p.strip()]

    @model_validator(mode="after")
    def _dates(self):
        if self.end_date < self.start_date:
            raise ValueError("end_date must be on or after start_date")
        if (self.end_date - self.start_date).days + 1 > 14:
            raise ValueError("trips are limited to 14 days")
        return self

    @property
    def days(self) -> int:
        return (self.end_date - self.start_date).days + 1

    def room_count(self) -> int:
        return self.rooms or ceil(self.travellers / 2)

    def keywords(self) -> str:
        return " ".join(self.preferences)

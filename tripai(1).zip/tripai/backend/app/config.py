"""Central configuration. All secrets come from environment variables / .env."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR.parent / ".env")

_INSECURE_DEFAULT = "change-me-generate-a-long-random-string"


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    app_env: str = field(default_factory=lambda: os.getenv("APP_ENV", "development"))
    mongodb_uri: str = field(default_factory=lambda: os.getenv("MONGODB_URI", "mongodb://localhost:27017"))
    mongodb_db: str = field(default_factory=lambda: os.getenv("MONGODB_DB", "tripai"))
    jwt_secret: str = field(default_factory=lambda: os.getenv("JWT_SECRET", _INSECURE_DEFAULT))
    jwt_algorithm: str = field(default_factory=lambda: os.getenv("JWT_ALGORITHM", "HS256"))
    jwt_expire_minutes: int = field(default_factory=lambda: int(os.getenv("JWT_EXPIRE_MINUTES", "720")))
    cors_origins: list[str] = field(
        default_factory=lambda: [
            o.strip()
            for o in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
            if o.strip()
        ]
    )
    use_mock_db: bool = field(default_factory=lambda: _bool("USE_MOCK_DB", False))
    models_dir: Path = BASE_DIR / "ml_models"
    data_dir: Path = BASE_DIR / "data"

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() == "production"

    def validate(self) -> None:
        if self.is_production and self.jwt_secret == _INSECURE_DEFAULT:
            raise RuntimeError("JWT_SECRET must be set to a strong random value in production.")
        if len(self.jwt_secret) < 16:
            raise RuntimeError("JWT_SECRET is too short (min 16 characters).")


settings = Settings()

import os

os.environ["USE_MOCK_DB"] = "true"  # tests use an in-memory MongoDB (mongomock); production uses real MongoDB
os.environ.setdefault("JWT_SECRET", "test-secret-test-secret-test-secret")

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.middleware import rate_limit


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(autouse=True)
def _reset_limiter():
    rate_limit.reset()


@pytest.fixture()
def auth(client):
    import uuid
    email = f"user{uuid.uuid4().hex[:8]}@example.com"
    r = client.post("/api/auth/register", json={"name": "Test User", "email": email, "password": "Passw0rdOK"})
    assert r.status_code == 201, r.text
    tok = r.json()["access_token"]
    return {"email": email, "headers": {"Authorization": f"Bearer {tok}"}, "token": tok}


TRIP = {
    "origin": "Pune", "destination": "Dubai", "start_date": "2026-12-10", "end_date": "2026-12-13", "travellers": 2,
    "budget_aed": 6000, "travel_type": "couple", "preferences": ["heritage"], "transport_preference": "mixed",
    "food_preference": "vegetarian", "hotel_per_night_aed": 450, "activities_total_aed": 500,
}

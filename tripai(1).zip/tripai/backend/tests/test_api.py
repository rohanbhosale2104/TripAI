import copy

from .conftest import TRIP


def test_health(client):
    j = client.get("/api/health").json()
    assert j["status"] == "ok" and j["database"]["connected"] and j["models"]["all_available"]


# ------------------------------------------------------------------ auth
def test_register_login_me_logout(client):
    body = {"name": "Asha Rao", "email": "Asha@Example.com", "password": "Sup3rSecret"}
    r = client.post("/api/auth/register", json=body)
    assert r.status_code == 201 and r.json()["user"]["email"] == "asha@example.com"
    assert "password" not in r.text
    assert client.post("/api/auth/register", json=body).status_code == 409
    r = client.post("/api/auth/login", json={"email": "asha@example.com", "password": "Sup3rSecret"})
    assert r.status_code == 200
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    assert client.get("/api/auth/me", headers=h).json()["name"] == "Asha Rao"
    assert client.post("/api/auth/logout", headers=h).status_code == 200
    assert client.get("/api/auth/me", headers=h).status_code == 401  # token revoked


def test_login_failures_and_validation(client):
    assert client.post("/api/auth/login", json={"email": "nobody@example.com", "password": "x"}).status_code == 401
    assert client.post("/api/auth/register", json={"name": "A", "email": "bad", "password": "short"}).status_code == 422
    assert client.post("/api/auth/register", json={"name": "Okay Name", "email": "n@example.com", "password": "alllettersnodigits"}).status_code == 422
    assert client.get("/api/auth/me").status_code == 401
    assert client.get("/api/auth/me", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_login_rate_limit(client):
    codes = [client.post("/api/auth/login", json={"email": "rl@example.com", "password": "x"}).status_code for _ in range(10)]
    assert 429 in codes


def test_profile_update_and_password_change(client, auth):
    h = auth["headers"]
    r = client.put("/api/users/me", headers=h, json={"name": "New Name", "home_city": "Pune", "preferences": {"food_preference": "vegetarian", "evil": "x"}})
    assert r.status_code == 200 and r.json()["home_city"] == "Pune" and r.json()["preferences"] == {"food_preference": "vegetarian"}
    assert client.put("/api/users/me/password", headers=h, json={"current_password": "wrong", "new_password": "Another1234"}).status_code == 400
    assert client.put("/api/users/me/password", headers=h, json={"current_password": "Passw0rdOK", "new_password": "Another1234"}).status_code == 200
    assert client.post("/api/auth/login", json={"email": auth["email"], "password": "Another1234"}).status_code == 200


# ------------------------------------------------------------------ recommendations / destinations / budget
def test_recommendation_endpoints(client):
    cases = {
        "hotels": {"travel_type": "couple", "limit": 3}, "attractions": {"travel_type": "religious", "limit": 3},
        "restaurants": {"food_preference": "vegetarian", "limit": 3}, "food": {"food_preference": "non-vegetarian", "limit": 3},
        "transport": {"transport_preference": "public", "limit": 3}, "destinations": {"travel_type": "adventure", "limit": 3},
    }
    for name, body in cases.items():
        r = client.post(f"/api/recommendations/{name}", json=body)
        assert r.status_code == 200, (name, r.text)
        j = r.json()
        assert j["items"] and j["query_used"] and j["model"], name
    assert client.post("/api/recommendations/hotels", json={"travel_type": "nonsense"}).status_code == 422


def test_destinations(client):
    j = client.get("/api/destinations").json()
    assert j["total"] == 10
    assert client.get("/api/destinations", params={"q": "souk"}).json()["total"] >= 1
    d = client.get("/api/destinations/deira").json()
    assert d["attractions"] is not None and "estimated_expenses" in d and d["estimated_expenses"]["accommodation"].startswith("Not in dataset")
    assert client.get("/api/destinations/atlantis").status_code == 404
    a = client.get("/api/destinations/attractions", params={"q": "dhow cruise"}).json()
    assert a["items"]


def test_budget_never_invents_prices(client):
    base = {"days": 4, "travellers": 2, "budget_aed": 3000, "food_preference": "both", "transport_preference": "taxi"}
    j = client.post("/api/budget/estimate", json=base).json()
    cats = {l["category"] for l in j["lines"]}
    assert "accommodation" not in cats and "activities" not in cats and "flights" not in cats
    assert any("Accommodation" in m for m in j["missing_components"])
    assert j["status"] == "within_budget_incomplete" and j["includes_lower_bounds"]
    j2 = client.post("/api/budget/estimate", json={**base, "hotel_per_night_aed": 500, "budget_aed": 500}).json()
    assert j2["status"] == "over_budget" and j2["remaining_aed"] < 0
    rh = client.post("/api/budget/estimate", json={**base, "transport_preference": "ride-hailing"}).json()
    assert any("Ride-hailing" in m for m in rh["missing_components"])
    assert client.post("/api/budget/estimate", json={**base, "days": 0}).status_code == 422
    assert client.post("/api/budget/estimate", json={**base, "budget_aed": -5}).status_code == 422


# ------------------------------------------------------------------ trips
def test_trip_validation(client, auth):
    h = auth["headers"]
    bad = copy.deepcopy(TRIP); bad["end_date"] = "2026-12-01"
    assert client.post("/api/trips/generate", headers=h, json=bad).status_code == 422
    bad = copy.deepcopy(TRIP); bad["end_date"] = "2027-02-01"
    assert client.post("/api/trips/generate", headers=h, json=bad).status_code == 422
    bad = copy.deepcopy(TRIP); bad["destination"] = "Paris"
    assert client.post("/api/trips/generate", headers=h, json=bad).status_code == 422
    assert client.post("/api/trips/generate", json=TRIP).status_code == 401


def test_generate_plan_structure(client, auth):
    r = client.post("/api/trips/generate", headers=auth["headers"], json=TRIP)
    assert r.status_code == 200, r.text
    p = r.json()
    assert len(p["days"]) == 4 and p["summary"]["nights"] == 3
    for d in p["days"]:
        assert len(d["slots"]) == 3 and len(d["meals"]) == 2
    assert p["budget"]["lines"] and p["hotels"]["items"] and p["transport"]["items"]
    assert all(i["food_category"] == "Vegetarian" for i in p["food"]["items"])
    names = [s["place"]["name"] for d in p["days"] for s in d["slots"] if s["place"]]
    assert len(names) == len(set(names)), "an attraction was repeated"


def test_trip_crud_and_pdf(client, auth):
    h = auth["headers"]
    r = client.post("/api/trips", headers=h, json={"title": "Winter escape", "request": TRIP})
    assert r.status_code == 201, r.text
    tid = r.json()["id"]
    lst = client.get("/api/trips", headers=h).json()["items"]
    assert len(lst) == 1 and lst[0]["title"] == "Winter escape" and lst[0]["days"] == 4
    assert client.get(f"/api/trips/{tid}", headers=h).json()["plan"]["days"]

    r = client.put(f"/api/trips/{tid}", headers=h, json={"title": "Renamed", "notes": "bring sunscreen"})
    assert r.json()["title"] == "Renamed" and r.json()["notes"] == "bring sunscreen"
    longer = {**TRIP, "end_date": "2026-12-15"}
    r = client.put(f"/api/trips/{tid}", headers=h, json={"request": longer})
    assert len(r.json()["plan"]["days"]) == 6 and r.json()["request"]["end_date"] == "2026-12-15"

    pdf = client.get(f"/api/trips/{tid}/pdf", headers=h)
    assert pdf.status_code == 200 and pdf.headers["content-type"] == "application/pdf" and pdf.content[:5] == b"%PDF-" and len(pdf.content) > 3000

    assert client.delete(f"/api/trips/{tid}", headers=h).status_code == 204
    assert client.get(f"/api/trips/{tid}", headers=h).status_code == 404
    assert client.get("/api/trips/not-an-id", headers=h).status_code == 404


def test_trips_are_private_per_user(client, auth):
    tid = client.post("/api/trips", headers=auth["headers"], json={"request": TRIP}).json()["id"]
    other = client.post("/api/auth/register", json={"name": "Other One", "email": "other1@example.com", "password": "Passw0rd99"}).json()["access_token"]
    oh = {"Authorization": f"Bearer {other}"}
    assert client.get(f"/api/trips/{tid}", headers=oh).status_code == 404
    assert client.delete(f"/api/trips/{tid}", headers=oh).status_code == 404
    assert client.get(f"/api/trips/{tid}/pdf", headers=oh).status_code == 404
    assert client.get("/api/trips", headers=oh).json()["items"] == []


def test_unavailable_model_returns_503_not_fake_data(client):
    from app.services.ml_service import ml_service
    saved = ml_service.bundles.pop("food")
    ml_service.failures["food"] = "simulated failure"
    try:
        r = client.post("/api/recommendations/food", json={"food_preference": "both"})
        assert r.status_code == 503 and r.json()["error"]["code"] == "model_unavailable"
        assert client.get("/api/health").json()["status"] == "degraded"
    finally:
        ml_service.bundles["food"] = saved
        ml_service.failures.pop("food")

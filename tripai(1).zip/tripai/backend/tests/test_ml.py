"""Tests run against the REAL pickle files shipped in app/ml_models."""
import hashlib
import shutil

import pytest

from app.config import settings
from app.middleware.errors import ModelUnavailableError
from app.services import recommendation_service as rec
from app.services.ml_service import MLService, SPECS, ml_service


@pytest.fixture(scope="module", autouse=True)
def loaded():
    ml_service.load_all()


def test_all_five_models_load_and_are_unmodified():
    st = ml_service.status()
    assert st["all_available"], st
    for key, m in st["models"].items():
        assert m["file_unmodified"] is True, f"{key} checksum differs from SHA256SUMS.txt"


def test_corrupted_rows_are_filtered():
    st = ml_service.status()["models"]
    assert st["accommodation"]["excluded_rows"] > 900 and st["accommodation"]["usable_rows"] > 400
    b = ml_service.get("accommodation")
    names = b.data.loc[b.valid, "name"].astype(str)
    assert not names.str.fullmatch(r"-?\d+(\.\d+)?").any(), "numeric (column-shifted) names leaked through"
    hits = ml_service.search("accommodation", "luxury beach hotel", top_k=10)
    assert hits and all(b.valid[i] for i, _ in hits)


def test_zero_overlap_query_returns_nothing_not_random_rows():
    assert ml_service.search("accommodation", "zzzzqqqq xxyyzz", top_k=5) == []


def test_original_pickles_not_modified_on_disk():
    for line in (settings.models_dir / "SHA256SUMS.txt").read_text().splitlines():
        digest, name = line.split()
        assert hashlib.sha256((settings.models_dir / name).read_bytes()).hexdigest() == digest


def test_missing_model_is_reported_not_faked(tmp_path):
    svc = MLService()
    for spec in SPECS.values():
        if spec.key != "food":
            shutil.copy(settings.models_dir / spec.filename, tmp_path / spec.filename)
    svc.load_all(tmp_path)
    assert "food" in svc.failures and "food" not in svc.bundles
    with pytest.raises(ModelUnavailableError):
        svc.get("food")
    assert svc.status()["models"]["food"]["available"] is False


def test_corrupt_pickle_is_rejected(tmp_path):
    for spec in SPECS.values():
        shutil.copy(settings.models_dir / spec.filename, tmp_path / spec.filename)
    import pickle
    (tmp_path / SPECS["poi"].filename).write_bytes(pickle.dumps({"vectorizer": 1}))
    svc = MLService()
    svc.load_all(tmp_path)
    assert "poi" in svc.failures and len(svc.bundles) == 4


def test_attractions_exclude_infrastructure():
    items = rec.recommend_attractions("family", None, None, limit=30)["items"]
    assert items
    bad = {"Parking", "Hospital", "Road", "Airport", "Medical Center", "Government Building"}
    assert not any(i["category"] in bad for i in items)


def test_vegetarian_food_is_strictly_vegetarian():
    items = rec.recommend_food("vegetarian", None, None, None, None, limit=30)["items"]
    assert items and all(i["food_category"] == "Vegetarian" for i in items)
    assert all(i["data_confidence"] == "synthetic" for i in items)


def test_transport_taxi_fares_come_from_dataset():
    items = rec.recommend_transport("taxi", True, 5)["items"]
    taxi = next(i for i in items if i["id"] == "taxi")
    assert taxi["fare_aed"]["base"] == 5.0
    assert any(i["quote_needed"] for i in rec.recommend_transport("ride-hailing", True, 14)["items"])

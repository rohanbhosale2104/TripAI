/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#0B2A33', 700: '#17414D', 500: '#4B6A73', 300: '#8FA6AC' },
        gulf: { DEFAULT: '#0F7C88', 600: '#0C6670', 100: '#D6EEF0', 50: '#EAF6F7' },
        pearl: { DEFAULT: '#F3F6F5', 200: '#E6ECEA' },
        saffron: { DEFAULT: '#E0A02A', 100: '#FBEFD2' },
        dusk: { DEFAULT: '#A83C6B', 100: '#F6DDE8' },
        ok: '#2B8A5B',
        bad: '#C23B2E',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Figtree', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      borderRadius: { pass: '28px' },
      boxShadow: { lift: '0 1px 0 rgba(11,42,51,.04), 0 12px 32px -12px rgba(11,42,51,.22)' },
    },
  },
  plugins: [],
}

<#
 Downloads one lead photo per Dubai area from Wikipedia (images are hosted on Wikimedia Commons).
 Run from the frontend folder:   powershell -ExecutionPolicy Bypass -File scripts\download-area-images.ps1
 Needs internet. Safe to re-run; existing files are kept unless you pass -Force.
 Always check each image's licence on its Wikipedia/Commons page before publishing the site (see CREDITS.txt).
#>
param([switch]$Force)

$ErrorActionPreference = 'Stop'
$outDir = Join-Path $PSScriptRoot '..\public\images\areas'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$headers = @{ 'User-Agent' = 'TripAI-student-project/1.0 (local development)' }   # Wikimedia requires a User-Agent

$areas = [ordered]@{
  'downtown-dubai' = 'Downtown_Dubai'
  'dubai-mall'     = 'The_Dubai_Mall'
  'dubai-marina'   = 'Dubai_Marina'
  'palm-jumeirah'  = 'Palm_Jumeirah'
  'deira'          = 'Deira'
  'bur-dubai'      = 'Bur_Dubai'
  'dubai-creek'    = 'Dubai_Creek'
  'jumeirah'       = 'Jumeirah'
  'business-bay'   = 'Business_Bay'
  'al-barsha'      = 'Al_Barsha'
}

$credits = @("TripAI area photos - lead images of the English Wikipedia articles below.",
             "Images are hosted on Wikimedia Commons; open the article, click the image, and read its licence/author before publishing.", "")
$failed = @()

foreach ($slug in $areas.Keys) {
  $title = $areas[$slug]
  $dest = Join-Path $outDir "$slug.jpg"
  if ((Test-Path $dest) -and -not $Force) { Write-Host "skip  $slug (exists)"; continue }
  try {
    $info = Invoke-RestMethod -Uri "https://en.wikipedia.org/api/rest_v1/page/summary/$title" -Headers $headers
    $url = $null
    if ($info.thumbnail.source) { $url = $info.thumbnail.source -replace '/\d+px-', '/1280px-' }
    elseif ($info.originalimage.source) { $url = $info.originalimage.source }
    if (-not $url) { throw 'article has no lead image' }
    try { Invoke-WebRequest -Uri $url -Headers $headers -OutFile $dest }
    catch { if ($info.originalimage.source) { Invoke-WebRequest -Uri $info.originalimage.source -Headers $headers -OutFile $dest } else { throw } }
    $credits += "$slug.jpg  <-  $($info.content_urls.desktop.page)"
    Write-Host "ok    $slug"
    Start-Sleep -Milliseconds 400
  } catch {
    Write-Host "FAIL  $slug : $($_.Exception.Message)" -ForegroundColor Yellow
    $failed += $slug
  }
}
$credits | Set-Content -Path (Join-Path $outDir 'CREDITS.txt') -Encoding UTF8
if ($failed.Count) { Write-Host "`nNo image for: $($failed -join ', '). Put your own <slug>.jpg in public\images\areas; the gradient is used meanwhile." -ForegroundColor Yellow }
else { Write-Host "`nAll images downloaded." -ForegroundColor Green }

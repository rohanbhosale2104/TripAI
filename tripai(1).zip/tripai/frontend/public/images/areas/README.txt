Place one photo per area here, named exactly <slug>.jpg:
downtown-dubai, dubai-mall, dubai-marina, palm-jumeirah, deira, bur-dubai, dubai-creek, jumeirah, business-bay, al-barsha
Missing files simply fall back to a coloured gradient. Auto-download: scripts\download-area-images.ps1

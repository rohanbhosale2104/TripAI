import { lazy, Suspense } from 'react'
import { Route, Routes } from 'react-router-dom'
import { Spinner } from './components/ui'
import ProtectedRoute from './components/ProtectedRoute'
import AuthLayout from './layouts/AuthLayout'
import MainLayout from './layouts/MainLayout'
const BudgetEstimator = lazy(() => import('./pages/BudgetEstimator'))
const Dashboard = lazy(() => import('./pages/Dashboard'))
const DestinationDetail = lazy(() => import('./pages/DestinationDetail'))
const Destinations = lazy(() => import('./pages/Destinations'))
import Home from './pages/Home'
const Itinerary = lazy(() => import('./pages/Itinerary'))
import Login from './pages/Login'
const MyTrips = lazy(() => import('./pages/MyTrips'))
import NotFound from './pages/NotFound'
const Profile = lazy(() => import('./pages/Profile'))
const Recommendations = lazy(() => import('./pages/Recommendations'))
import Register from './pages/Register'
const TripPlanner = lazy(() => import('./pages/TripPlanner'))

const guard = (el) => <ProtectedRoute>{el}</ProtectedRoute>

export default function App() {
  return (
    <Suspense fallback={<Spinner label="Loading" className="py-32" />}>
    <Routes>
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/destinations" element={<Destinations />} />
        <Route path="/destinations/:slug" element={<DestinationDetail />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/budget" element={<BudgetEstimator />} />
        <Route path="/dashboard" element={guard(<Dashboard />)} />
        <Route path="/plan" element={guard(<TripPlanner />)} />
        <Route path="/itinerary" element={guard(<Itinerary />)} />
        <Route path="/trips" element={guard(<MyTrips />)} />
        <Route path="/trips/:id" element={guard(<Itinerary />)} />
        <Route path="/profile" element={guard(<Profile />)} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
    </Suspense>
  )
}

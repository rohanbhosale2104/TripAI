import { useCallback, useEffect, useRef, useState } from 'react'
import { parseError } from '../services/api'

/** Runs an async fn on mount/deps change; exposes {data, loading, error, reload}. */
export function useAsync(fn, deps = [], { immediate = true } = {}) {
  const [state, setState] = useState({ data: null, loading: immediate, error: null })
  const alive = useRef(true)
  useEffect(() => { alive.current = true; return () => { alive.current = false } }, [])

  const run = useCallback(async (...args) => {
    setState((s) => ({ ...s, loading: true, error: null }))
    try {
      const data = await fn(...args)
      if (alive.current) setState({ data, loading: false, error: null })
      return data
    } catch (e) {
      if (alive.current) setState({ data: null, loading: false, error: parseError(e).message })
      return null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  useEffect(() => { if (immediate) run() }, [run, immediate])
  return { ...state, reload: run }
}

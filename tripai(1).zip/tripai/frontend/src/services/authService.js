import api, { tokenStore } from './api'

export const authService = {
  async register(payload) {
    const { data } = await api.post('/api/auth/register', payload)
    tokenStore.set(data.access_token)
    return data.user
  },
  async login(payload) {
    const { data } = await api.post('/api/auth/login', payload)
    tokenStore.set(data.access_token)
    return data.user
  },
  async me() {
    const { data } = await api.get('/api/auth/me')
    return data
  },
  async logout() {
    try { await api.post('/api/auth/logout') } catch { /* token may already be invalid */ }
    tokenStore.clear()
  },
  async updateProfile(payload) {
    const { data } = await api.put('/api/users/me', payload)
    return data
  },
  async changePassword(payload) {
    const { data } = await api.put('/api/users/me/password', payload)
    return data
  },
}

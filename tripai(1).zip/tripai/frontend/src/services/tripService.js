import api from './api'

export const tripService = {
  generate: async (request) => (await api.post('/api/trips/generate', request)).data,
  save: async (request, title, notes = '') => (await api.post('/api/trips', { request, title: title || null, notes })).data,
  list: async () => (await api.get('/api/trips')).data.items,
  get: async (id) => (await api.get(`/api/trips/${id}`)).data,
  update: async (id, body) => (await api.put(`/api/trips/${id}`, body)).data,
  remove: async (id) => { await api.delete(`/api/trips/${id}`) },
  async downloadPdf(id, filename = 'tripai-itinerary.pdf') {
    const res = await api.get(`/api/trips/${id}/pdf`, { responseType: 'blob' })
    const url = URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }))
    const a = document.createElement('a')
    a.href = url; a.download = filename
    document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 2000)
  },
}

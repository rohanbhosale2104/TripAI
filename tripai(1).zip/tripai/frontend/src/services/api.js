import axios from 'axios'

const TOKEN_KEY = 'tripai_token'
export const tokenStore = {
  get: () => { try { return localStorage.getItem(TOKEN_KEY) } catch { return null } },
  set: (t) => { try { localStorage.setItem(TOKEN_KEY, t) } catch { /* storage blocked */ } },
  clear: () => { try { localStorage.removeItem(TOKEN_KEY) } catch { /* storage blocked */ } },
}

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || '', timeout: 30000 })

api.interceptors.request.use((config) => {
  const t = tokenStore.get()
  if (t) config.headers.Authorization = `Bearer ${t}`
  return config
})

let onUnauthorized = () => {}
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn }

api.interceptors.response.use(
  (r) => r,
  (err) => {
    const url = err.config?.url || ''
    const isAuthCall = url.includes('/api/auth/login') || url.includes('/api/auth/register')
    if (err.response?.status === 401 && !isAuthCall && tokenStore.get()) onUnauthorized()
    return Promise.reject(err)
  },
)

/** Turn any axios/FastAPI error into a readable string (+ per-field messages when available). */
export function parseError(err) {
  if (err?.code === 'ECONNABORTED') return { message: 'The server took too long to respond. Please try again.', fields: {} }
  if (!err?.response) return { message: 'Cannot reach the TripAI server. Check that the backend is running on port 8000.', fields: {} }
  const data = err.response.data
  const e = data?.error
  const fields = {}
  if (Array.isArray(e?.details)) e.details.forEach((d) => { if (d.field) fields[d.field] = d.message })
  let message = e?.message || data?.detail || `Request failed (${err.response.status})`
  if (typeof message !== 'string') message = 'Request failed.'
  if (e?.code === 'validation_error' && e.details?.length) {
    message = e.details.map((d) => (d.field ? `${d.field}: ${d.message}` : d.message)).join(' · ')
  }
  return { message, fields, status: err.response.status }
}

export default api

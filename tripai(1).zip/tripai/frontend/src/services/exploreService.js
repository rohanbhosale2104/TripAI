import api from './api'

export const exploreService = {
  health: async () => (await api.get('/api/health')).data,
  areas: async (params = {}) => (await api.get('/api/destinations', { params })).data,
  area: async (slug) => (await api.get(`/api/destinations/${slug}`)).data,
  attractions: async (params = {}) => (await api.get('/api/destinations/attractions', { params })).data,
  budget: async (body) => (await api.post('/api/budget/estimate', body)).data,
  recommend: async (kind, body) => (await api.post(`/api/recommendations/${kind}`, body)).data,
}

import { Link, Outlet } from 'react-router-dom'
import { Logo } from '../components/Navbar'
import Skyline from '../components/Skyline'

export default function AuthLayout() {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <aside className="relative hidden overflow-hidden bg-gulf-600 p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <Link to="/"><Logo light /></Link>
        <div className="relative z-10 max-w-md">
          <h2 className="text-4xl font-extrabold leading-tight">Your Dubai trip, planned from real place data.</h2>
          <p className="mt-4 text-white/75">Save itineraries, revisit them, and export them as PDF.</p>
        </div>
        <Skyline fill="#04242B" className="absolute inset-x-0 bottom-0 h-72 w-full" />
      </aside>
      <div className="flex items-center justify-center bg-pearl px-4 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <Link to="/" className="mb-8 inline-block lg:hidden"><Logo /></Link>
          <Outlet />
        </div>
      </div>
    </div>
  )
}

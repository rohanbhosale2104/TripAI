import { Backpack, Briefcase, Heart, Landmark, Mountain, Sparkles, Users, UsersRound } from 'lucide-react'

export const TRAVEL_TYPES = [
  { value: 'couple', label: 'Couple', icon: Heart }, { value: 'family', label: 'Family', icon: Users },
  { value: 'solo', label: 'Solo', icon: Backpack }, { value: 'adventure', label: 'Adventure', icon: Mountain },
  { value: 'business', label: 'Business', icon: Briefcase }, { value: 'religious', label: 'Religious', icon: Landmark },
  { value: 'friends', label: 'Friends', icon: UsersRound }, { value: 'luxury', label: 'Luxury', icon: Sparkles },
]
export const FOOD_PREFS = [
  { value: 'vegetarian', label: 'Vegetarian' }, { value: 'non-vegetarian', label: 'Non-vegetarian' }, { value: 'both', label: 'Both' },
]
export const TRANSPORT_PREFS = [
  { value: 'mixed', label: 'Mix of metro & taxi' }, { value: 'public', label: 'Public transport' }, { value: 'taxi', label: 'Taxi' },
  { value: 'rental-car', label: 'Rental car' }, { value: 'ride-hailing', label: 'Ride-hailing' }, { value: 'walking', label: 'Walking' },
  { value: 'water', label: 'Abra / water' },
]
export const PREFERENCE_SUGGESTIONS = ['heritage', 'dhow', 'souk', 'mosque', 'marina', 'creek', 'zoo', 'tour']
export const AREA_GRADIENTS = {
  'downtown-dubai': 'from-[#0B2A33] to-[#17414D]', 'dubai-mall': 'from-[#17414D] to-[#0F7C88]',
  'dubai-marina': 'from-[#0F7C88] to-[#5FB3BA]', 'palm-jumeirah': 'from-[#0C6670] to-[#E0A02A]',
  deira: 'from-[#7A5410] to-[#E0A02A]', 'bur-dubai': 'from-[#A83C6B] to-[#E0A02A]',
  'dubai-creek': 'from-[#17414D] to-[#A83C6B]', jumeirah: 'from-[#5FB3BA] to-[#E0A02A]',
  'business-bay': 'from-[#0B2A33] to-[#0F7C88]', 'al-barsha': 'from-[#4B6A73] to-[#0F7C88]',
}

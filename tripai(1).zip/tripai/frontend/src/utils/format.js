export const aed = (n) => (n == null ? '-' : `AED ${Math.round(n).toLocaleString('en-US')}`)
export const fmtDate = (iso, opts = { day: 'numeric', month: 'short', year: 'numeric' }) =>
  iso ? new Date(`${iso.slice(0, 10)}T00:00:00`).toLocaleDateString('en-GB', opts) : ''
export const titleCase = (s = '') => s.replace(/(^|[\s-])(\w)/g, (m, a, b) => a + b.toUpperCase())
export const todayISO = () => new Date().toISOString().slice(0, 10)
export const addDaysISO = (iso, n) => { const d = new Date(`${iso}T00:00:00`); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10) }
export const num = (v) => (v === '' || v == null ? undefined : Number(v))
export const CATEGORY_LABELS = {
  accommodation: 'Accommodation', food: 'Food', local_transport: 'Local transport',
  airport_transfers: 'Airport transfers', activities: 'Activities', flights: 'Flights', other: 'Other',
}

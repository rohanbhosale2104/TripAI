import { Coffee, Compass, ExternalLink, Footprints, Moon, Sun, Sunrise, Utensils } from 'lucide-react'
import { aed, fmtDate } from '../utils/format'
import { ConfidenceBadge } from './ui'

const ICON = { breakfast: Coffee, morning: Sunrise, lunch: Utensils, afternoon: Sun, evening: Moon, dinner: Utensils }

function Row({ icon: Icon, tone = 'bg-gulf-100 text-gulf-600', title, children }) {
  return (
    <li className="relative pb-6 pl-14 last:pb-0">
      <span className={`absolute left-0 top-0 grid h-10 w-10 place-items-center rounded-full ${tone}`}><Icon size={18} /></span>
      <p className="text-xs font-semibold text-ink-500">{title}</p>
      {children}
    </li>
  )
}

function Leg({ leg }) {
  if (!leg) return null
  return (
    <p className="mb-1 flex items-center gap-1.5 text-xs text-ink-500">
      <Footprints size={12} /> {leg.straight_line_km} km from {leg.from} · {leg.suggested_mode}
    </p>
  )
}

function Slot({ s }) {
  if (s.type === 'open_time') {
    return (
      <Row icon={Compass} tone="bg-ink/5 text-ink-500" title={s.period}>
        <h4 className="font-bold">{s.title}</h4>
        <p className="mt-0.5 max-w-xl text-sm text-ink-500">{s.description}</p>
        <p className="mt-1 text-xs text-ink-500">{s.note}</p>
      </Row>
    )
  }
  const p = s.place
  return (
    <Row icon={ICON[s.period]} title={s.period}>
      <Leg leg={s.leg_from_previous} />
      <h4 className="flex items-center gap-2 font-bold" dir="auto">
        {p.name}
        {p.maps_url && <a href={p.maps_url} target="_blank" rel="noreferrer noopener" aria-label={`Open ${p.name} on a map`} className="text-ink-300 hover:text-gulf"><ExternalLink size={14} /></a>}
      </h4>
      <p className="text-sm text-ink-500">{p.kind}{p.area ? ` · near ${p.area.name}` : ''} · ticket price not in dataset</p>
    </Row>
  )
}

function Meal({ m }) {
  const r = m.restaurant
  const idea = m.dish_idea
  return (
    <Row icon={ICON[m.meal]} tone="bg-saffron-100 text-[#7A5410]" title={m.meal}>
      <h4 className="font-bold" dir="auto">{r ? r.name : 'No restaurant match in dataset'}</h4>
      {r && <p className="text-sm text-ink-500">{r.category}{r.area ? ` · near ${r.area.name}` : ''}</p>}
      {idea && (
        <p className="mt-1 flex flex-wrap items-center gap-x-2 text-sm text-ink-700">
          Dish idea: {idea.recommended_dish}, about {aed(idea.estimated_cost_for_two_aed)} for two <ConfidenceBadge level="synthetic" />
        </p>
      )}
    </Row>
  )
}

export default function Timeline({ days }) {
  return (
    <div className="space-y-8">
      {days.map((d) => {
        const bySlot = Object.fromEntries(d.slots.map((s) => [s.period, s]))
        const bm = Object.fromEntries(d.meals.map((m) => [m.meal, m]))
        const order = [bm.breakfast && ['m', bm.breakfast], ['s', bySlot.morning], bm.lunch && ['m', bm.lunch], ['s', bySlot.afternoon], ['s', bySlot.evening], bm.dinner && ['m', bm.dinner]].filter(Boolean)
        const c = d.estimated_cost_aed
        return (
          <section key={d.day} className="card overflow-hidden" aria-labelledby={`day-${d.day}`}>
            <header className="flex flex-wrap items-center justify-between gap-3 border-b border-ink/10 bg-ink px-5 py-4 text-white">
              <div>
                <h3 id={`day-${d.day}`} className="text-xl font-extrabold">Day {d.day}</h3>
                <p className="text-sm text-white/70">{d.weekday}, {fmtDate(d.date)}</p>
              </div>
              <ul className="flex flex-wrap gap-2 text-xs">
                {[['Food', c.food], ['Transport', c.local_transport], ['Stay', c.accommodation], ['Activities', c.activities]].filter(([, v]) => v).map(([k, v]) => (
                  <li key={k} className="rounded-full bg-white/10 px-2.5 py-1">{k} {aed(v)}</li>
                ))}
              </ul>
            </header>
            <ol className="relative p-5 before:absolute before:bottom-8 before:left-[39px] before:top-8 before:w-px before:bg-ink/15">
              {order.map(([t, x], i) => (t === 's' ? <Slot key={i} s={x} /> : <Meal key={i} m={x} />))}
            </ol>
            <footer className="border-t border-ink/10 bg-pearl/60 px-5 py-3 text-xs text-ink-500">
              {d.travel_notes.map((n) => <p key={n}>{n}</p>)}
              <p className="mt-1">{d.cost_note}</p>
            </footer>
          </section>
        )
      })}
    </div>
  )
}

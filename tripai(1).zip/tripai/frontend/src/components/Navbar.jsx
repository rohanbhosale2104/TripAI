import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { LogOut, Menu, Plane, X, User } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export function Logo({ light = false }) {
  return (
    <span className={`flex items-center gap-2 font-display text-xl font-extrabold tracking-tight ${light ? 'text-white' : 'text-ink'}`}>
      <span className="grid h-8 w-8 place-items-center rounded-lg bg-gulf text-white"><Plane size={17} className="-rotate-45" /></span>
      TripAI
    </span>
  )
}

const link = ({ isActive }) => `rounded-md px-3 py-2 text-sm font-semibold transition-colors ${isActive ? 'bg-gulf-100 text-gulf-600' : 'text-ink-700 hover:text-gulf-600'}`

export default function Navbar() {
  const { isAuthenticated, user, logout } = useAuth()
  const [open, setOpen] = useState(false)
  const nav = useNavigate()
  const items = [
    ...(isAuthenticated ? [['/dashboard', 'Dashboard']] : []),
    ['/destinations', 'Explore Dubai'], ['/recommendations', 'Recommendations'], ['/budget', 'Budget'],
    ...(isAuthenticated ? [['/plan', 'Plan a trip'], ['/trips', 'My trips']] : []),
  ]
  const doLogout = async () => { await logout(); setOpen(false); nav('/') }

  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-pearl/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link to="/" aria-label="TripAI home"><Logo /></Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {items.map(([to, label]) => <NavLink key={to} to={to} className={link}>{label}</NavLink>)}
        </nav>
        <div className="hidden items-center gap-2 lg:flex">
          {isAuthenticated ? (
            <>
              <Link to="/profile" className="btn-ghost"><User size={16} /> {user.name.split(' ')[0]}</Link>
              <button onClick={doLogout} className="btn-ghost" aria-label="Log out"><LogOut size={16} /></button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-ghost">Log in</Link>
              <Link to="/register" className="btn-primary">Create account</Link>
            </>
          )}
        </div>
        <button className="lg:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <div className="border-t border-ink/10 bg-pearl px-4 pb-4 lg:hidden">
          <nav className="flex flex-col py-2" aria-label="Mobile">
            {items.map(([to, label]) => <NavLink key={to} to={to} className={link} onClick={() => setOpen(false)}>{label}</NavLink>)}
          </nav>
          <div className="flex gap-2">
            {isAuthenticated ? (
              <>
                <Link to="/profile" className="btn-ghost flex-1" onClick={() => setOpen(false)}>Profile</Link>
                <button onClick={doLogout} className="btn-dark flex-1">Log out</button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-ghost flex-1" onClick={() => setOpen(false)}>Log in</Link>
                <Link to="/register" className="btn-primary flex-1" onClick={() => setOpen(false)}>Create account</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  )
}

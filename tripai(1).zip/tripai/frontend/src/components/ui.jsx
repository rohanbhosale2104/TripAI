import { AlertCircle, Info, Loader2, SearchX } from 'lucide-react'

export function Spinner({ label = 'Loading', className = '' }) {
  return (
    <div role="status" className={`flex items-center justify-center gap-2 text-ink-500 ${className}`}>
      <Loader2 className="animate-spin" size={20} /> <span className="text-sm">{label}</span>
    </div>
  )
}

export function SkeletonCards({ count = 6, className = 'h-40' }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-hidden>
      {Array.from({ length: count }).map((_, i) => <div key={i} className={`skeleton rounded-xl ${className}`} />)}
    </div>
  )
}

export function ErrorBanner({ message, onRetry }) {
  if (!message) return null
  return (
    <div role="alert" className="flex items-start gap-3 rounded-lg border border-bad/30 bg-bad/5 p-4 text-sm text-bad">
      <AlertCircle size={18} className="mt-0.5 shrink-0" />
      <div className="flex-1">{message}</div>
      {onRetry && <button onClick={onRetry} className="font-semibold underline">Try again</button>}
    </div>
  )
}

export function EmptyState({ title, children, action, icon: Icon = SearchX }) {
  return (
    <div className="rounded-xl border border-dashed border-ink/20 bg-white/60 px-6 py-12 text-center">
      <Icon className="mx-auto mb-3 text-ink-300" size={32} />
      <h3 className="text-lg font-bold">{title}</h3>
      {children && <p className="mx-auto mt-1 max-w-md text-sm text-ink-500">{children}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

export function Notice({ children, tone = 'info' }) {
  const tones = { info: 'border-gulf/25 bg-gulf-50 text-ink-700', warn: 'border-saffron/40 bg-saffron-100 text-ink-700' }
  return (
    <div className={`flex items-start gap-2.5 rounded-lg border p-3 text-sm ${tones[tone]}`}>
      <Info size={16} className="mt-0.5 shrink-0 text-gulf" /> <div>{children}</div>
    </div>
  )
}

const CONF = {
  synthetic: ['Synthetic demo data', 'bg-saffron-100 text-[#7A5410]'],
  low: ['Low confidence', 'bg-saffron-100 text-[#7A5410]'],
  medium: ['Medium confidence', 'bg-gulf-50 text-gulf-600'],
  high: ['Official fare rule', 'bg-ok/10 text-ok'],
  'user-provided': ['Your figure', 'bg-ink/5 text-ink-700'],
}
export function ConfidenceBadge({ level }) {
  const [label, cls] = CONF[level] || [level, 'bg-ink/5 text-ink-700']
  return <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-semibold ${cls}`}>{label}</span>
}

export function Field({ label, hint, error, children, htmlFor }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="label">{label}</label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
      {error && <p className="mt-1 text-xs font-medium text-bad">{error}</p>}
    </div>
  )
}

/** Radio-style chip group (single select). */
export function Segmented({ value, onChange, options, name }) {
  return (
    <div role="radiogroup" aria-label={name} className="flex flex-wrap gap-2">
      {options.map((o) => {
        const v = o.value ?? o
        const active = value === v
        return (
          <button key={v} type="button" role="radio" aria-checked={active} onClick={() => onChange(v)}
            className={`chip ${active ? 'border-gulf bg-gulf text-white' : 'border-ink/15 bg-white text-ink hover:border-gulf'}`}>
            {o.icon && <o.icon size={15} />} {o.label ?? o}
          </button>
        )
      })}
    </div>
  )
}

export function PageHeader({ title, children, actions }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-3xl font-extrabold sm:text-4xl">{title}</h1>
        {children && <p className="mt-2 max-w-2xl text-ink-500">{children}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  )
}

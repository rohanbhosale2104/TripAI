import { ArrowRight, CalendarDays, Users } from 'lucide-react'
import { aed, fmtDate, titleCase } from '../utils/format'

/** Trip summary shown as a boarding pass - the visual motif of the product. */
export default function BoardingPass({ trip, children, className = '' }) {
  const over = trip.budget_status === 'over_budget'
  return (
    <article className={`pass pass-notch overflow-hidden ${className}`} style={{ '--notch-y': '70%' }}>
      <div className="grid sm:grid-cols-[1fr_auto]">
        <div className="p-6 pb-4 sm:pr-8">
          <p className="text-xs font-semibold text-ink-500">{titleCase(trip.travel_type)} trip</p>
          <div className="mt-2 flex items-center gap-3 font-display text-2xl font-extrabold sm:text-3xl">
            <span className="truncate">{trip.origin}</span>
            <ArrowRight className="shrink-0 text-gulf" size={24} />
            <span>{trip.destination}</span>
          </div>
          {trip.title && <h3 className="mt-2 truncate text-sm font-medium text-ink-500">{trip.title}</h3>}
        </div>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-1 px-6 pb-4 text-sm sm:w-64 sm:pt-6">
          <div><dt className="flex items-center gap-1 text-xs text-ink-500"><CalendarDays size={12} /> Depart</dt><dd className="font-semibold">{fmtDate(trip.start_date, { day: 'numeric', month: 'short' })}</dd></div>
          <div><dt className="text-xs text-ink-500">Return</dt><dd className="font-semibold">{fmtDate(trip.end_date, { day: 'numeric', month: 'short' })}</dd></div>
          <div><dt className="flex items-center gap-1 text-xs text-ink-500"><Users size={12} /> Travellers</dt><dd className="font-semibold">{trip.travellers}</dd></div>
          <div><dt className="text-xs text-ink-500">Days</dt><dd className="font-semibold">{trip.days}</dd></div>
        </dl>
      </div>
      <div className="pass-tear mx-6" />
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4">
        <div className="text-sm">
          <span className="text-ink-500">Known costs </span>
          <strong className={over ? 'text-bad' : ''}>{aed(trip.estimated_total_aed)}</strong>
          <span className="text-ink-500"> of {aed(trip.budget_aed)}</span>
        </div>
        <div className="flex flex-wrap gap-2">{children}</div>
      </div>
    </article>
  )
}

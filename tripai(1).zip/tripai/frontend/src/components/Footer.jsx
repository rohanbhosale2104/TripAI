import { Link } from 'react-router-dom'
import { Logo } from './Navbar'

export default function Footer() {
  return (
    <footer className="mt-24 bg-ink text-white/80">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <Logo light />
          <p className="mt-3 max-w-xs text-sm text-white/60">Dubai trip planning from five recommender models. Prices only where the data has them.</p>
        </div>
        <div className="text-sm">
          <h4 className="mb-2 font-bold text-white">Explore</h4>
          <ul className="space-y-1.5">
            <li><Link to="/destinations" className="hover:text-saffron">Dubai areas</Link></li>
            <li><Link to="/recommendations" className="hover:text-saffron">Recommendations</Link></li>
            <li><Link to="/budget" className="hover:text-saffron">Budget estimator</Link></li>
          </ul>
        </div>
        <div className="text-sm text-white/60">
          <h4 className="mb-2 font-bold text-white">About the data</h4>
          <p>Hotel, ticket and flight prices are never estimated. Food figures come from synthetic demo records and are labelled. Verify opening hours, fares and availability before you travel. All amounts are in AED.</p>
        </div>
      </div>
    </footer>
  )
}

/** Decorative Dubai-style skyline (abstract shapes; not any specific building). */
export default function Skyline({ className = '', fill = '#0B2A33' }) {
  return (
    <svg viewBox="0 0 1200 220" preserveAspectRatio="xMidYMax slice" className={className} aria-hidden="true">
      <path fill={fill} opacity=".10" d="M0 220V150h60v-30h40v40h50V90h30v70h60v-50h40v60h70V70h24v90h56v-40h50v50h60V60h18v110h46v-60h60v70h70V100h40v70h50v-30h60v40h40V80h34v100h50v-50h56v60h60V120h50v100z"/>
      <path fill={fill} opacity=".18" d="M0 220v-50h90v-40h30v40h70v-70h26v70h80v-30h50v30h60v-80h14v80h64v-45h40v45h90v-20h60v20h70V90h8v100h22v-50h70v60h56v-30h60v30h60v-60h40v60h54v-25h60v25h50v-35h40v35z"/>
      {/* spire */}
      <path fill={fill} opacity=".95" d="M912 220V84l3-30 3 30v136z M905 220v-110l10-60 10 60v110z" />
    </svg>
  )
}

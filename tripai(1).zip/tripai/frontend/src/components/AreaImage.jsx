import { useState } from 'react'

/** Shows /images/areas/<slug>.jpg if the file exists; otherwise the parent's gradient stays visible. */
export default function AreaImage({ slug, name, className = '' }) {
  const [failed, setFailed] = useState(false)
  if (failed) return null
  return (
    <img
      src={`/images/areas/${slug}.jpg`} alt={`${name}, Dubai`} loading="lazy" decoding="async"
      onError={() => setFailed(true)} className={`absolute inset-0 h-full w-full object-cover ${className}`}
    />
  )
}

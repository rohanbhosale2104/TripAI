import { Link } from 'react-router-dom'
import { Landmark, Utensils } from 'lucide-react'
import AreaImage from './AreaImage'

export default function AreaCard({ area, gradient = 'from-ink to-gulf' }) {
  return (
    <Link to={`/destinations/${area.slug}`} className="group card flex flex-col overflow-hidden transition-shadow hover:shadow-lift">
      <div className={`relative h-44 overflow-hidden bg-gradient-to-br ${gradient} p-4`}>
        <AreaImage slug={area.slug} name={area.name} className="transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent" aria-hidden />
        <h3 className="absolute bottom-3 left-4 text-2xl font-extrabold text-white drop-shadow">{area.name}</h3>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className="text-sm text-ink-700">{area.description}</p>
        <ul className="mt-3 flex flex-wrap gap-1.5">
          {area.known_for.slice(0, 3).map((k) => <li key={k} className="rounded-full bg-pearl px-2 py-0.5 text-xs font-medium text-ink-700">{k}</li>)}
        </ul>
        <p className="mt-auto flex gap-4 pt-4 text-xs text-ink-500">
          <span className="flex items-center gap-1"><Landmark size={13} /> {area.attraction_count} attractions in data</span>
          <span className="flex items-center gap-1"><Utensils size={13} /> {area.food_record_count} food records</span>
        </p>
      </div>
    </Link>
  )
}

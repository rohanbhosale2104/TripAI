import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Spinner } from './ui'

export default function ProtectedRoute({ children }) {
  const { isAuthenticated, booting } = useAuth()
  const loc = useLocation()
  if (booting) return <Spinner label="Checking your session" className="py-32" />
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />
  return children
}

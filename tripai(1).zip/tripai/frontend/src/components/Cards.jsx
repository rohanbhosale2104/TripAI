import { ExternalLink, MapPin, Star, Utensils } from 'lucide-react'
import { aed } from '../utils/format'
import { ConfidenceBadge } from './ui'

export function PlaceCard({ place, note }) {
  return (
    <article className="card flex flex-col p-4">
      <div className="flex items-start justify-between gap-3">
        <h4 className="text-base font-bold leading-snug" dir="auto">{place.name}</h4>
        {place.maps_url && (
          <a href={place.maps_url} target="_blank" rel="noreferrer noopener" aria-label={`Open ${place.name} on a map`} className="shrink-0 text-ink-300 hover:text-gulf"><ExternalLink size={16} /></a>
        )}
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5 text-xs">
        {(place.kind || place.category) && <span className="rounded-full bg-gulf-50 px-2 py-0.5 font-semibold text-gulf-600">{place.kind || place.category}</span>}
        {place.diet_verified && <span className="rounded-full bg-ok/10 px-2 py-0.5 font-semibold text-ok">Vegetarian category</span>}
      </div>
      <p className="mt-3 flex items-start gap-1.5 text-sm text-ink-500">
        <MapPin size={14} className="mt-0.5 shrink-0" />
        <span dir="auto">{[place.address, place.area && `near ${place.area.name}`].filter(Boolean).join(' · ') || 'Location on map'}</span>
      </p>
      <p className="mt-auto pt-3 text-xs text-ink-500">{note || place.price_info || place.ticket_price}</p>
    </article>
  )
}

export function FoodCard({ item }) {
  return (
    <article className="card flex flex-col p-4">
      <div className="flex items-start justify-between gap-2">
        <h4 className="font-bold leading-snug">{item.recommended_dish}</h4>
        <ConfidenceBadge level="synthetic" />
      </div>
      <p className="mt-1 flex items-center gap-1.5 text-sm text-ink-500"><Utensils size={14} /> {item.restaurant} · {item.cuisine}</p>
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
        <span><strong>{aed(item.dish_price_aed)}</strong> dish</span>
        <span><strong>{aed(item.estimated_cost_for_two_aed)}</strong> for two</span>
        <span className="flex items-center gap-1 text-ink-500"><Star size={13} className="fill-saffron text-saffron" />{item.rating_demo} demo</span>
      </div>
      <p className="mt-2 text-xs text-ink-500">{item.area} · {item.food_category} · {item.facilities}</p>
    </article>
  )
}

export function TransportCard({ item }) {
  const f = item.fare_aed
  return (
    <article className="card flex flex-col p-4">
      <div className="flex items-start justify-between gap-2">
        <h4 className="font-bold">{item.name}</h4>
        <ConfidenceBadge level={item.data_confidence} />
      </div>
      <p className="mt-1 text-sm text-ink-500">{item.category} · {item.ownership}</p>
      <p className="mt-3 text-sm">
        {item.quote_needed
          ? <strong>Quote needed</strong>
          : <><strong>{f.band_2 != null ? `${f.base} / ${f.band_2} / ${f.band_3}` : f.base}</strong> AED <span className="text-ink-500">{item.fare_unit}</span></>}
      </p>
      <p className="mt-2 text-xs text-ink-500">{item.fare_rule}{item.booking_required ? ` · Booking: ${item.booking_required}` : ''}</p>
      {item.accessibility && <p className="mt-1 text-xs text-ink-500">{item.accessibility}</p>}
    </article>
  )
}

export function ResultNotes({ data }) {
  if (!data) return null
  return (
    <div className="mt-6 rounded-lg bg-white/70 p-4 text-xs text-ink-500">
      <p><strong className="text-ink-700">How this was matched:</strong> model <code>{data.model}</code> searched for “{data.query_used}”.</p>
      <ul className="mt-1 list-disc space-y-0.5 pl-5">{(data.notes || []).map((n) => <li key={n}>{n}</li>)}</ul>
    </div>
  )
}

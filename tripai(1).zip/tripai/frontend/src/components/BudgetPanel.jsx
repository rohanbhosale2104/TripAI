import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts'
import { AlertTriangle, CheckCircle2 } from 'lucide-react'
import { aed, CATEGORY_LABELS } from '../utils/format'
import { ConfidenceBadge, Notice } from './ui'

const COLORS = ['#0F7C88', '#E0A02A', '#A83C6B', '#17414D', '#5FB3BA', '#8FA6AC', '#C9A66B']

export default function BudgetPanel({ budget: b }) {
  const over = b.status === 'over_budget'
  const pct = Math.min(b.percent_used, 100)
  const data = b.breakdown.map((x) => ({ name: CATEGORY_LABELS[x.category] || x.category, value: x.amount }))
  return (
    <div className="space-y-6">
      <div className={`flex items-start gap-3 rounded-xl border p-4 ${over ? 'border-bad/30 bg-bad/5' : 'border-gulf/25 bg-gulf-50'}`} role="status">
        {over ? <AlertTriangle className="mt-0.5 shrink-0 text-bad" size={20} /> : <CheckCircle2 className="mt-0.5 shrink-0 text-gulf" size={20} />}
        <p className="text-sm font-medium">{b.message}</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
        <div className="card p-5">
          <div className="flex items-baseline justify-between">
            <h3 className="text-lg font-bold">Known costs vs your budget</h3>
            <span className="text-sm text-ink-500">{b.percent_used}%</span>
          </div>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-ink/10" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
            <div className={`h-full rounded-full ${over ? 'bg-bad' : 'bg-gulf'}`} style={{ width: `${pct}%` }} />
          </div>
          <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
            <div><dt className="text-ink-500">Estimate</dt><dd className="text-lg font-bold">{aed(b.total_estimate)}</dd></div>
            <div><dt className="text-ink-500">Range</dt><dd className="font-semibold">{aed(b.total_low)} – {aed(b.total_high)}</dd></div>
            <div><dt className="text-ink-500">{b.remaining_aed < 0 ? 'Over by' : 'Remaining'}</dt><dd className={`text-lg font-bold ${b.remaining_aed < 0 ? 'text-bad' : 'text-ok'}`}>{aed(Math.abs(b.remaining_aed))}</dd></div>
          </dl>
          {data.length > 0 && (
            <div className="mt-4 grid items-center gap-2 sm:grid-cols-2">
              <div className="h-44" aria-hidden>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={data} dataKey="value" innerRadius={42} outerRadius={72} paddingAngle={2} stroke="none">
                      {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v) => aed(v)} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <ul className="space-y-1.5 text-sm">
                {data.map((d, i) => (
                  <li key={d.name} className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-sm" style={{ background: COLORS[i % COLORS.length] }} />{d.name}</span>
                    <strong>{aed(d.value)}</strong>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="card overflow-x-auto p-5">
          <h3 className="mb-3 text-lg font-bold">Where each number comes from</h3>
          <table className="w-full min-w-[420px] text-left text-sm">
            <thead className="text-ink-500"><tr><th className="pb-2 font-semibold">Item</th><th className="pb-2 text-right font-semibold">AED</th><th className="pb-2 pl-3 font-semibold">Basis</th></tr></thead>
            <tbody className="divide-y divide-ink/10">
              {b.lines.map((l) => (
                <tr key={l.label} className="align-top">
                  <td className="py-2.5 pr-2"><div className="font-semibold">{l.label}{l.is_lower_bound && <abbr title="Real cost will be higher" className="ml-1 text-saffron no-underline">*</abbr>}</div><div className="text-xs text-ink-500">{l.detail}</div></td>
                  <td className="py-2.5 text-right font-semibold">{aed(l.estimate)}{l.low !== l.high && <div className="text-xs font-normal text-ink-500">{Math.round(l.low)}–{Math.round(l.high)}</div>}</td>
                  <td className="py-2.5 pl-3"><ConfidenceBadge level={l.confidence} /><div className="mt-1 max-w-[16rem] text-xs text-ink-500">{l.source}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {b.includes_lower_bounds && <p className="mt-3 text-xs text-ink-500"><span className="text-saffron">*</span> Lower bound: metered fares, fuel and deposits are extra.</p>}
        </div>
      </div>

      {b.missing_components.length > 0 && (
        <Notice tone="warn">
          <strong>Not priced (no data, so not guessed):</strong>
          <ul className="mt-1 list-disc pl-5">{b.missing_components.map((m) => <li key={m}>{m}</li>)}</ul>
        </Notice>
      )}
    </div>
  )
}

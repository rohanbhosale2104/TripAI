import { useState } from 'react'
import { Loader2, LogOut } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { ErrorBanner, Field, PageHeader, Segmented } from '../components/ui'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { parseError } from '../services/api'
import { authService } from '../services/authService'
import { fmtDate } from '../utils/format'
import { FOOD_PREFS, TRANSPORT_PREFS, TRAVEL_TYPES } from '../utils/options'

export default function Profile() {
  useDocumentTitle('Profile')
  const { user, setUser, logout } = useAuth()
  const toast = useToast()
  const nav = useNavigate()
  const [p, setP] = useState({ name: user.name, home_city: user.home_city || '', preferences: { travel_type: 'couple', food_preference: 'both', transport_preference: 'mixed', travellers: 2, ...user.preferences } })
  const [pw, setPw] = useState({ current_password: '', new_password: '' })
  const [err, setErr] = useState({ profile: '', pw: '' })
  const [busy, setBusy] = useState('')
  const setPref = (k, v) => setP({ ...p, preferences: { ...p.preferences, [k]: v } })

  const saveProfile = async (e) => {
    e.preventDefault(); setErr((x) => ({ ...x, profile: '' })); setBusy('profile')
    try { setUser(await authService.updateProfile({ name: p.name.trim(), home_city: p.home_city.trim(), preferences: { ...p.preferences, travellers: Number(p.preferences.travellers) || 2 } })); toast.success('Profile saved.') }
    catch (e2) { setErr((x) => ({ ...x, profile: parseError(e2).message })) } finally { setBusy('') }
  }
  const savePw = async (e) => {
    e.preventDefault(); setErr((x) => ({ ...x, pw: '' })); setBusy('pw')
    try { await authService.changePassword(pw); setPw({ current_password: '', new_password: '' }); toast.success('Password updated.') }
    catch (e2) { setErr((x) => ({ ...x, pw: parseError(e2).message })) } finally { setBusy('') }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <PageHeader title="Your profile" actions={<button className="btn-ghost" onClick={async () => { await logout(); nav('/') }}><LogOut size={16} /> Log out</button>}>{user.email} · member since {fmtDate(user.created_at)}</PageHeader>
      <form onSubmit={saveProfile} className="card space-y-5 p-6">
        <h2 className="text-lg font-bold">Details and defaults</h2>
        <ErrorBanner message={err.profile} />
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Name" htmlFor="n"><input id="n" className="input" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} /></Field>
          <Field label="Home city" htmlFor="c" hint="Pre-fills “Starting from” in the planner."><input id="c" className="input" value={p.home_city} onChange={(e) => setP({ ...p, home_city: e.target.value })} /></Field>
        </div>
        <Field label="Usual travel type"><Segmented name="Travel type" value={p.preferences.travel_type} onChange={(v) => setPref('travel_type', v)} options={TRAVEL_TYPES} /></Field>
        <Field label="Food"><Segmented name="Food" value={p.preferences.food_preference} onChange={(v) => setPref('food_preference', v)} options={FOOD_PREFS} /></Field>
        <Field label="Getting around"><Segmented name="Transport" value={p.preferences.transport_preference} onChange={(v) => setPref('transport_preference', v)} options={TRANSPORT_PREFS} /></Field>
        <Field label="Usual group size" htmlFor="g"><input id="g" type="number" min="1" max="20" className="input !w-28" value={p.preferences.travellers} onChange={(e) => setPref('travellers', e.target.value)} /></Field>
        <button className="btn-primary" disabled={busy === 'profile'}>{busy === 'profile' && <Loader2 className="animate-spin" size={16} />} Save profile</button>
      </form>
      <form onSubmit={savePw} className="card mt-6 space-y-5 p-6">
        <h2 className="text-lg font-bold">Change password</h2>
        <ErrorBanner message={err.pw} />
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Current password" htmlFor="cp"><input id="cp" type="password" autoComplete="current-password" className="input" value={pw.current_password} onChange={(e) => setPw({ ...pw, current_password: e.target.value })} /></Field>
          <Field label="New password" htmlFor="np" hint="8+ characters, with a letter and a number."><input id="np" type="password" autoComplete="new-password" className="input" value={pw.new_password} onChange={(e) => setPw({ ...pw, new_password: e.target.value })} /></Field>
        </div>
        <button className="btn-dark" disabled={busy === 'pw' || !pw.current_password || !pw.new_password}>{busy === 'pw' && <Loader2 className="animate-spin" size={16} />} Update password</button>
      </form>
    </div>
  )
}

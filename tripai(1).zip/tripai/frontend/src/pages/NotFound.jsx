import { Link } from 'react-router-dom'
import { EmptyState } from '../components/ui'
export default function NotFound() {
  return <div className="mx-auto max-w-xl px-4 py-24"><EmptyState title="This page doesn’t exist" action={<Link to="/" className="btn-primary">Back to home</Link>}>The link may be old or mistyped.</EmptyState></div>
}

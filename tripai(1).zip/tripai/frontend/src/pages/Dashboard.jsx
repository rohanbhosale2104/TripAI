import { Link } from 'react-router-dom'
import { Calculator, Compass, Map, Plus, Sparkles } from 'lucide-react'
import BoardingPass from '../components/BoardingPass'
import { EmptyState, ErrorBanner, SkeletonCards } from '../components/ui'
import { useAuth } from '../context/AuthContext'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { exploreService } from '../services/exploreService'
import { tripService } from '../services/tripService'
import { fmtDate } from '../utils/format'

export default function Dashboard() {
  useDocumentTitle('Dashboard')
  const { user } = useAuth()
  const trips = useAsync(tripService.list, [])
  const health = useAsync(exploreService.health, [])
  const list = trips.data || []
  const today = new Date().toISOString().slice(0, 10)
  const next = [...list].filter((t) => t.start_date >= today).sort((a, b) => a.start_date.localeCompare(b.start_date))[0]
  const daysTo = next ? Math.ceil((new Date(next.start_date) - new Date(today)) / 86400000) : null
  const online = health.data ? Object.values(health.data.models.models).filter((m) => m.available).length : null

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <h1 className="text-3xl font-extrabold sm:text-4xl">Hello, {user.name.split(' ')[0]}</h1>
      <p className="mt-2 text-ink-500">{next ? `Your next trip leaves ${fmtDate(next.start_date)}.` : 'Where to next? Dubai is ready when you are.'}</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[[list.length, 'Saved trips'], [daysTo != null ? (daysTo === 0 ? 'Today' : `${daysTo} days`) : '-', 'Until next trip'],
          [online != null ? `${online} of 5` : '-', 'Models online']].map(([v, l]) => (
          <div key={l} className="card p-5"><p className="font-display text-3xl font-extrabold">{trips.loading && l !== 'Models online' ? '…' : v}</p><p className="text-sm text-ink-500">{l}</p></div>
        ))}
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[['/plan', Plus, 'Plan a trip', 'Generate a new itinerary'], ['/destinations', Compass, 'Explore Dubai', 'Areas and attractions'],
          ['/recommendations', Sparkles, 'Recommendations', 'Hotels, food, transport'], ['/budget', Calculator, 'Budget estimator', 'Check costs vs budget']].map(([to, Icon, t, d]) => (
          <Link key={to} to={to} className="card group p-5 transition-shadow hover:shadow-lift">
            <span className="grid h-10 w-10 place-items-center rounded-lg bg-gulf-100 text-gulf-600 group-hover:bg-gulf group-hover:text-white"><Icon size={20} /></span>
            <p className="mt-3 font-bold">{t}</p><p className="text-sm text-ink-500">{d}</p>
          </Link>
        ))}
      </div>

      <div className="mt-12 flex items-center justify-between"><h2 className="text-2xl font-extrabold">Recent trips</h2><Link to="/trips" className="text-sm font-semibold text-gulf-600 underline">All trips</Link></div>
      <div className="mt-4">
        <ErrorBanner message={trips.error} onRetry={trips.reload} />
        {trips.loading && <SkeletonCards count={2} className="h-44" />}
        {trips.data && list.length === 0 && <EmptyState icon={Map} title="Nothing saved yet" action={<Link to="/plan" className="btn-primary">Plan your first trip</Link>}>Your saved itineraries will appear here.</EmptyState>}
        <div className="space-y-6">
          {list.slice(0, 2).map((t) => <BoardingPass key={t.id} trip={t}><Link to={`/trips/${t.id}`} className="btn-primary">Open</Link></BoardingPass>)}
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'
import { Link, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom'
import { Download, Loader2, Pencil, Save, Trash2 } from 'lucide-react'
import BoardingPass from '../components/BoardingPass'
import BudgetPanel from '../components/BudgetPanel'
import { FoodCard, PlaceCard, ResultNotes, TransportCard } from '../components/Cards'
import Timeline from '../components/Timeline'
import { EmptyState, ErrorBanner, Notice, Spinner } from '../components/ui'
import { useToast } from '../context/ToastContext'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { parseError } from '../services/api'
import { tripService } from '../services/tripService'

const TABS = [['plan', 'Day by day'], ['budget', 'Budget'], ['stay', 'Stay & transport'], ['eat', 'Food']]

export default function Itinerary() {
  const { id } = useParams()
  const { state } = useLocation()
  const nav = useNavigate()
  const toast = useToast()
  const saved = useAsync(() => tripService.get(id), [id], { immediate: !!id })
  const [tab, setTab] = useState('plan')
  const [title, setTitle] = useState('')
  const [notes, setNotes] = useState(null)
  const [busy, setBusy] = useState('')
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [error, setError] = useState('')

  const trip = id ? saved.data : state?.plan ? { id: null, title: '', notes: '', request: state.request, plan: state.plan } : null
  useDocumentTitle(trip?.title || 'Your itinerary')

  if (!id && !state?.plan) return <Navigate to="/plan" replace />
  if (id && saved.loading) return <Spinner label="Loading your trip" className="py-32" />
  if (id && saved.error) return <div className="mx-auto max-w-3xl px-4 py-16"><ErrorBanner message={saved.error} onRetry={saved.reload} /><div className="mt-6"><Link to="/trips" className="btn-ghost">Back to my trips</Link></div></div>
  if (!trip) return null

  const { plan, request } = trip
  const s = plan.summary
  const passData = { ...s, title: trip.title, estimated_total_aed: plan.budget.total_estimate, budget_status: plan.budget.status }

  const run = async (key, fn) => {
    setBusy(key); setError('')
    try { await fn() } catch (e) { const m = parseError(e).message; setError(m); toast.error(m) } finally { setBusy('') }
  }
  const save = () => run('save', async () => {
    const t = await tripService.save(request, title.trim())
    toast.success('Trip saved.')
    nav(`/trips/${t.id}`, { replace: true })
  })
  const pdf = () => run('pdf', () => tripService.downloadPdf(trip.id, `tripai-dubai-${s.start_date}.pdf`))
  const saveNotes = () => run('notes', async () => { await tripService.update(trip.id, { notes }); toast.success('Notes saved.'); saved.reload() })
  const remove = () => run('del', async () => { await tripService.remove(trip.id); toast.success('Trip deleted.'); nav('/trips', { replace: true }) })

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <BoardingPass trip={passData}>
        {trip.id ? (
          <>
            <button className="btn-primary" onClick={pdf} disabled={busy === 'pdf'}>{busy === 'pdf' ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} PDF</button>
            <button className="btn-ghost" onClick={() => nav('/plan', { state: { editId: trip.id, request } })}><Pencil size={16} /> Edit</button>
            {confirmDelete ? (
              <button className="btn-danger" onClick={remove} disabled={busy === 'del'}>Confirm delete</button>
            ) : <button className="btn-danger" onClick={() => setConfirmDelete(true)} aria-label="Delete trip"><Trash2 size={16} /></button>}
          </>
        ) : (
          <>
            <input className="input !w-52" placeholder="Trip name (optional)" value={title} onChange={(e) => setTitle(e.target.value)} aria-label="Trip name" maxLength={100} />
            <button className="btn-primary" onClick={save} disabled={busy === 'save'}>{busy === 'save' ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Save trip</button>
            <button className="btn-ghost" onClick={() => nav('/plan', { state: { request } })}><Pencil size={16} /> Change inputs</button>
          </>
        )}
      </BoardingPass>
      {!trip.id && <p className="mt-3 text-sm text-ink-500">Save this trip to edit it later and download the PDF.</p>}
      <div className="mt-4"><ErrorBanner message={error} /></div>

      <div className="mt-8 flex gap-1 overflow-x-auto border-b border-ink/10" role="tablist">
        {TABS.map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={`whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-semibold ${tab === k ? 'border-gulf text-gulf-600' : 'border-transparent text-ink-500 hover:text-ink'}`}>{l}</button>
        ))}
      </div>

      <div className="mt-6" role="tabpanel">
        {tab === 'plan' && (
          <>
            <Timeline days={plan.days} />
            {plan.data_notes.length > 0 && <div className="mt-6"><Notice tone="warn"><ul className="list-disc pl-4">{plan.data_notes.map((n) => <li key={n}>{n}</li>)}</ul></Notice></div>}
            {trip.id && (
              <div className="card mt-8 p-5">
                <label htmlFor="notes" className="label">Your notes</label>
                <textarea id="notes" rows={3} maxLength={2000} className="input" value={notes ?? trip.notes} onChange={(e) => setNotes(e.target.value)} placeholder="Bookings, reminders, ideas…" />
                <button className="btn-dark mt-3" onClick={saveNotes} disabled={notes === null || busy === 'notes'}>Save notes</button>
              </div>
            )}
          </>
        )}
        {tab === 'budget' && <BudgetPanel budget={plan.budget} />}
        {tab === 'stay' && (
          <div className="space-y-10">
            <section>
              <h3 className="mb-3 text-xl font-bold">Places to stay</h3>
              {plan.hotels.items.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{plan.hotels.items.map((h) => <PlaceCard key={h.name} place={h} />)}</div> : <EmptyState title="No hotel matches">Try a different area or travel type.</EmptyState>}
              <ResultNotes data={plan.hotels} />
            </section>
            <section>
              <h3 className="mb-3 text-xl font-bold">Getting around</h3>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{plan.transport.items.map((t) => <TransportCard key={t.id} item={t} />)}</div>
              <ResultNotes data={plan.transport} />
            </section>
          </div>
        )}
        {tab === 'eat' && (
          <div className="space-y-10">
            <section>
              <h3 className="mb-3 text-xl font-bold">Restaurants</h3>
              {plan.restaurants.items.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{plan.restaurants.items.map((r) => <PlaceCard key={r.name} place={r} />)}</div> : <EmptyState title="No restaurants listed">Meals per day is set to zero, or nothing matched.</EmptyState>}
            </section>
            <section>
              <h3 className="mb-3 text-xl font-bold">Dishes to try</h3>
              {plan.food.items.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{plan.food.items.map((f, i) => <FoodCard key={i} item={f} />)}</div> : <EmptyState title="No dishes matched" />}
              <ResultNotes data={plan.food} />
            </section>
          </div>
        )}
      </div>
    </div>
  )
}

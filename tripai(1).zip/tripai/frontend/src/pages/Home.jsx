import { Link } from 'react-router-dom'
import { ArrowRight, CalendarRange, FileDown, Scale, ShieldCheck } from 'lucide-react'
import Skyline from '../components/Skyline'
import { ErrorBanner, SkeletonCards } from '../components/ui'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { exploreService } from '../services/exploreService'
import { AREA_GRADIENTS } from '../utils/options'
import { useAuth } from '../context/AuthContext'
import AreaCard from '../components/AreaCard'

const MODEL_LABELS = {
  accommodation: 'Hotels', poi: 'Places', restaurant: 'Restaurants', food: 'Dishes & food costs', transportation: 'Transport fares',
}

export default function Home() {
  useDocumentTitle()
  const { isAuthenticated } = useAuth()
  const health = useAsync(exploreService.health, [])
  const areas = useAsync(() => exploreService.areas(), [])
  const models = health.data?.models?.models

  return (
    <>
      <section className="relative overflow-hidden bg-gulf-50">
        <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-12 px-4 pb-40 pt-16 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:pt-24">
          <div>
            <h1 className="text-5xl font-extrabold leading-[1.02] sm:text-6xl lg:text-7xl">Plan Dubai the way the data sees it.</h1>
            <p className="mt-6 max-w-xl text-lg text-ink-700">
              Tell TripAI where you start, how long you have and what you eat. It builds a day-by-day plan with recommender models over real place data, and checks it against your budget in dirhams.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to={isAuthenticated ? '/plan' : '/register'} className="btn-primary px-6 py-3 text-base">Plan a trip <ArrowRight size={18} /></Link>
              <Link to="/destinations" className="btn-ghost px-6 py-3 text-base">Explore Dubai areas</Link>
            </div>
          </div>

          <div className="pass pass-notch mx-auto w-full max-w-md rotate-[1.5deg]" style={{ '--notch-y': '66%' }}>
            <div className="p-7">
              <p className="text-xs font-semibold text-ink-500">What you get</p>
              <ul className="mt-4 space-y-4">
                {[[CalendarRange, 'A day-wise itinerary', 'Morning, afternoon and evening stops, grouped by distance.'],
                  [Scale, 'Budget vs your limit', 'Fares and food costs from data; hotel and ticket prices are yours to enter.'],
                  [FileDown, 'PDF you can carry', 'Save the trip, edit it later, export it.']].map(([Icon, t, d]) => (
                  <li key={t} className="flex gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-gulf-100 text-gulf-600"><Icon size={18} /></span><div><p className="font-bold">{t}</p><p className="text-sm text-ink-500">{d}</p></div></li>
                ))}
              </ul>
            </div>
            <div className="pass-tear mx-7" />
            <p className="px-7 py-4 text-sm text-ink-500">Destination: <strong className="text-ink">Dubai</strong> · Currency: <strong className="text-ink">AED</strong></p>
          </div>
        </div>
        <Skyline className="absolute inset-x-0 bottom-0 h-56 w-full" />
      </section>

      <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6">
        <h2 className="text-3xl font-extrabold sm:text-4xl">Pick a part of Dubai to start from</h2>
        <p className="mt-2 max-w-2xl text-ink-500">Areas are grouped with the attractions and food records the models know about.</p>
        <div className="mt-8">
          {areas.loading && <SkeletonCards count={6} className="h-44" />}
          <ErrorBanner message={areas.error} onRetry={areas.reload} />
          {areas.data && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {areas.data.items.slice(0, 6).map((a) => <AreaCard key={a.slug} area={a} gradient={AREA_GRADIENTS[a.slug]} />)}
            </div>
          )}
          <div className="mt-6"><Link to="/destinations" className="btn-ghost">See all {areas.data?.total ?? ''} areas</Link></div>
        </div>
      </section>

      <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 rounded-pass bg-ink p-8 text-white sm:p-12 lg:grid-cols-[1fr_1.2fr]">
          <div>
            <ShieldCheck className="text-saffron" size={30} />
            <h2 className="mt-3 text-3xl font-extrabold">Honest about what it knows</h2>
            <p className="mt-3 text-white/70">TripAI never invents hotel rates, ticket prices or flight fares. Where the data has no price, it asks you or tells you it is missing. Food figures come from synthetic demo records and say so.</p>
          </div>
          <div>
            <h3 className="mb-3 text-sm font-semibold text-white/60">Models loaded right now</h3>
            {health.loading && <div className="skeleton h-40 rounded-lg opacity-20" />}
            {health.error && <p className="text-sm text-saffron">Backend not reachable. Start the API to see live model status.</p>}
            {models && (
              <ul className="divide-y divide-white/10">
                {Object.entries(models).map(([k, m]) => (
                  <li key={k} className="flex items-center justify-between py-2.5 text-sm">
                    <span className="font-semibold">{MODEL_LABELS[k] || k}</span>
                    <span className={m.available ? 'text-white/70' : 'text-saffron'}>
                      {m.available ? `${m.usable_rows.toLocaleString()} usable of ${m.total_rows.toLocaleString()} rows` : 'unavailable'}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </section>
    </>
  )
}

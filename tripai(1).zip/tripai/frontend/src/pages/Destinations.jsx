import { useEffect, useState } from 'react'
import { Search } from 'lucide-react'
import AreaCard from '../components/AreaCard'
import { PlaceCard } from '../components/Cards'
import { EmptyState, ErrorBanner, Notice, PageHeader, Segmented, SkeletonCards } from '../components/ui'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { exploreService } from '../services/exploreService'
import { AREA_GRADIENTS } from '../utils/options'

const GOOD_FOR = ['All', 'Family', 'Couple', 'Solo', 'Adventure', 'Business', 'Religious']

function useDebounced(v, ms = 300) {
  const [d, setD] = useState(v)
  useEffect(() => { const t = setTimeout(() => setD(v), ms); return () => clearTimeout(t) }, [v, ms])
  return d
}

export default function Destinations() {
  useDocumentTitle('Explore Dubai')
  const [q, setQ] = useState('')
  const [goodFor, setGoodFor] = useState('All')
  const [aq, setAq] = useState('')
  const [kind, setKind] = useState('')
  const dq = useDebounced(q), daq = useDebounced(aq)
  const areas = useAsync(() => exploreService.areas({ q: dq || undefined, good_for: goodFor === 'All' ? undefined : goodFor }), [dq, goodFor])
  const attr = useAsync(() => exploreService.attractions({ q: daq || undefined, kind: kind || undefined, limit: 30 }), [daq, kind])

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <PageHeader title="Explore Dubai">Ten areas, with attractions and food records the models know about near each one.</PageHeader>

      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center">
        <div className="relative lg:w-96">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-300" />
          <input className="input !pl-9" placeholder="Search areas, e.g. souk, beach" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search areas" />
        </div>
        <Segmented name="Good for" value={goodFor} onChange={setGoodFor} options={GOOD_FOR} />
      </div>

      <ErrorBanner message={areas.error} onRetry={areas.reload} />
      {areas.loading && !areas.data && <SkeletonCards count={6} className="h-56" />}
      {areas.data && areas.data.items.length === 0 && <EmptyState title="No areas match">Try a different word or choose “All”.</EmptyState>}
      {areas.data && <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{areas.data.items.map((a) => <AreaCard key={a.slug} area={a} gradient={AREA_GRADIENTS[a.slug]} />)}</div>}

      <p className="mt-4 text-xs text-ink-500">Area photos are loaded from your own <code>public/images/areas</code> folder. If you used the download script, they come from Wikipedia / Wikimedia Commons; see <code>CREDITS.txt</code> there for sources and licences.</p>

      <section className="mt-20">
        <h2 className="text-3xl font-extrabold">Attractions in the dataset</h2>
        <div className="mt-3 max-w-3xl"><Notice tone="warn">The places dataset is mostly roads, hospitals, parking and airports. Only genuinely visitable heritage sites, waterfront experiences and tour operators are shown here. Ticket prices and opening hours are not in the data.</Notice></div>
        <div className="my-6 flex flex-col gap-4 lg:flex-row lg:items-center">
          <div className="relative lg:w-96">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-300" />
            <input className="input !pl-9" placeholder="Search attractions, e.g. dhow, mosque" value={aq} onChange={(e) => setAq(e.target.value)} aria-label="Search attractions" />
          </div>
          <Segmented name="Kind" value={kind} onChange={setKind} options={[{ value: '', label: 'All kinds' }, ...(attr.data?.kinds || []).map((k) => ({ value: k, label: k }))]} />
        </div>
        <ErrorBanner message={attr.error} onRetry={attr.reload} />
        {attr.loading && !attr.data && <SkeletonCards count={6} />}
        {attr.data && attr.data.items.length === 0 && <EmptyState title="No attractions match">Try a broader keyword.</EmptyState>}
        {attr.data && <><p className="mb-3 text-sm text-ink-500">{attr.data.total} found</p><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{attr.data.items.map((p) => <PlaceCard key={p.name} place={p} />)}</div></>}
      </section>
    </div>
  )
}

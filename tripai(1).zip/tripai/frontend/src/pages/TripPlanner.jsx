import { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Plane, Plus, Sparkles, X } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { parseError } from '../services/api'
import { exploreService } from '../services/exploreService'
import { tripService } from '../services/tripService'
import { ErrorBanner, Field, Notice, PageHeader, Segmented } from '../components/ui'
import { FOOD_PREFS, PREFERENCE_SUGGESTIONS, TRANSPORT_PREFS, TRAVEL_TYPES } from '../utils/options'
import { addDaysISO, num, todayISO } from '../utils/format'

const STEPS = ['Matching attractions to your travel style', 'Choosing restaurants for your diet', 'Pricing fares from the transport data', 'Grouping stops by distance', 'Checking the plan against your budget']

const blank = (user) => ({
  origin: user?.home_city || '', start_date: addDaysISO(todayISO(), 14), end_date: addDaysISO(todayISO(), 18),
  travellers: user?.preferences?.travellers || 2, budget_aed: 6000,
  travel_type: user?.preferences?.travel_type || 'couple', preferences: [], pref_input: '',
  transport_preference: user?.preferences?.transport_preference || 'mixed',
  food_preference: user?.preferences?.food_preference || 'both', preferred_area: '', cuisine: '',
  hotel_per_night_aed: '', rooms: '', activities_total_aed: '', flights_total_aed: '', other_costs_aed: '',
  meals_per_day: 2, local_rides_per_day: 4, taxi_rides_per_day: 2, include_airport_transfers: true,
})

export default function TripPlanner() {
  const { user } = useAuth()
  const toast = useToast()
  const nav = useNavigate()
  const { state } = useLocation()
  const editId = state?.editId
  useDocumentTitle(editId ? 'Edit trip' : 'Plan a trip')
  const areas = useAsync(() => exploreService.areas(), [])

  const [f, setF] = useState(() => (state?.request ? { ...blank(user), ...state.request, preferences: state.request.preferences || [], pref_input: '',
    preferred_area: state.request.preferred_area || '', cuisine: state.request.cuisine || '' } : blank(user)))
  const [busy, setBusy] = useState(false)
  const [step, setStep] = useState(0)
  const [error, setError] = useState('')
  const [problems, setProblems] = useState({})
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }))

  useEffect(() => {
    if (!busy) return
    const t = setInterval(() => setStep((s) => (s + 1) % STEPS.length), 1100)
    return () => clearInterval(t)
  }, [busy])

  const days = useMemo(() => {
    if (!f.start_date || !f.end_date) return 0
    return Math.round((new Date(f.end_date) - new Date(f.start_date)) / 86400000) + 1
  }, [f.start_date, f.end_date])

  const addPref = (p) => {
    const v = p.trim().toLowerCase()
    if (v && !f.preferences.includes(v) && f.preferences.length < 10) set('preferences', [...f.preferences, v])
    set('pref_input', '')
  }

  const buildRequest = () => ({
    origin: f.origin.trim(), destination: 'Dubai', start_date: f.start_date, end_date: f.end_date,
    travellers: Number(f.travellers), budget_aed: Number(f.budget_aed), travel_type: f.travel_type, preferences: f.preferences,
    transport_preference: f.transport_preference, food_preference: f.food_preference,
    preferred_area: f.preferred_area || null, cuisine: f.cuisine.trim() || null,
    hotel_per_night_aed: num(f.hotel_per_night_aed) ?? null, rooms: num(f.rooms) ?? null,
    activities_total_aed: num(f.activities_total_aed) ?? null, flights_total_aed: num(f.flights_total_aed) ?? null,
    other_costs_aed: num(f.other_costs_aed) ?? null, meals_per_day: Number(f.meals_per_day),
    local_rides_per_day: Number(f.local_rides_per_day), taxi_rides_per_day: Number(f.taxi_rides_per_day),
    include_airport_transfers: f.include_airport_transfers,
  })

  const validate = () => {
    const p = {}
    if (f.origin.trim().length < 2) p.origin = 'Enter the city you start from.'
    if (!f.start_date) p.start_date = 'Choose a start date.'
    if (!f.end_date) p.end_date = 'Choose a return date.'
    else if (days < 1) p.end_date = 'Return date must be on or after the start date.'
    else if (days > 14) p.end_date = 'Trips are limited to 14 days.'
    if (!(f.travellers >= 1 && f.travellers <= 20)) p.travellers = 'Between 1 and 20 travellers.'
    if (!(Number(f.budget_aed) > 0)) p.budget_aed = 'Enter a budget above zero.'
    setProblems(p)
    return Object.keys(p).length === 0
  }

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    if (!validate()) return
    const request = buildRequest()
    setBusy(true); setStep(0)
    try {
      if (editId) {
        await tripService.update(editId, { request })
        toast.success('Trip updated and plan regenerated.')
        nav(`/trips/${editId}`)
      } else {
        const plan = await tripService.generate(request)
        nav('/itinerary', { state: { request, plan } })
      }
    } catch (err) {
      const p = parseError(err)
      setError(p.message); setProblems(p.fields)
      setBusy(false)
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <PageHeader title={editId ? 'Edit your trip' : 'Plan a Dubai trip'}>
        {editId ? 'Change anything and TripAI will regenerate the plan.' : 'Costs you enter below are used as given. Anything left blank is shown as not priced, never guessed.'}
      </PageHeader>

      <form onSubmit={submit} className="space-y-8" noValidate>
        <ErrorBanner message={error} />

        <fieldset className="card grid gap-5 p-6 sm:grid-cols-2">
          <legend className="sr-only">Trip basics</legend>
          <Field label="Starting from" htmlFor="origin" error={problems.origin} hint="Any city; used for arrival notes.">
            <input id="origin" className="input" placeholder="e.g. Pune" value={f.origin} onChange={(e) => set('origin', e.target.value)} />
          </Field>
          <Field label="Destination" htmlFor="dest" hint="The models cover Dubai only.">
            <input id="dest" className="input bg-pearl" value="Dubai" readOnly />
          </Field>
          <Field label="Start date" htmlFor="start" error={problems.start_date}>
            <input id="start" type="date" className="input" value={f.start_date} onChange={(e) => set('start_date', e.target.value)} />
          </Field>
          <Field label="Return date" htmlFor="end" error={problems.end_date} hint={days > 0 ? `${days} day${days > 1 ? 's' : ''}, ${Math.max(days - 1, 0)} night${days > 2 ? 's' : ''}` : ''}>
            <input id="end" type="date" min={f.start_date} className="input" value={f.end_date} onChange={(e) => set('end_date', e.target.value)} />
          </Field>
          <Field label="Travellers" htmlFor="trav" error={problems.travellers}>
            <input id="trav" type="number" min="1" max="20" className="input" value={f.travellers} onChange={(e) => set('travellers', e.target.value)} />
          </Field>
          <Field label="Total budget (AED)" htmlFor="budget" error={problems.budget_aed} hint="All amounts in this app are in UAE dirhams.">
            <input id="budget" type="number" min="1" className="input" value={f.budget_aed} onChange={(e) => set('budget_aed', e.target.value)} />
          </Field>
        </fieldset>

        <fieldset className="card space-y-6 p-6">
          <legend className="sr-only">Travel style</legend>
          <Field label="Travel type"><Segmented name="Travel type" value={f.travel_type} onChange={(v) => set('travel_type', v)} options={TRAVEL_TYPES} /></Field>
          <Field label="Food preference"><Segmented name="Food preference" value={f.food_preference} onChange={(v) => set('food_preference', v)} options={FOOD_PREFS} /></Field>
          <Field label="Getting around"><Segmented name="Transport preference" value={f.transport_preference} onChange={(v) => set('transport_preference', v)} options={TRANSPORT_PREFS} /></Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Stay near (optional)" htmlFor="area">
              <select id="area" className="input" value={f.preferred_area} onChange={(e) => set('preferred_area', e.target.value)}>
                <option value="">Anywhere in Dubai</option>
                {(areas.data?.items || []).map((a) => <option key={a.slug} value={a.name}>{a.name}</option>)}
              </select>
            </Field>
            <Field label="Favourite cuisine (optional)" htmlFor="cuisine"><input id="cuisine" className="input" placeholder="e.g. Indian, Lebanese" value={f.cuisine} onChange={(e) => set('cuisine', e.target.value)} /></Field>
          </div>
          <Field label="Interests" hint="Keywords matched against place names and types. Press Enter to add.">
            <div className="flex flex-wrap items-center gap-2">
              {f.preferences.map((p) => (
                <span key={p} className="chip border-gulf bg-gulf-50 text-gulf-600">{p}<button type="button" onClick={() => set('preferences', f.preferences.filter((x) => x !== p))} aria-label={`Remove ${p}`}><X size={14} /></button></span>
              ))}
              <input className="input !w-44" placeholder="Add interest" value={f.pref_input} onChange={(e) => set('pref_input', e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addPref(f.pref_input) } }} aria-label="Add interest" />
              <button type="button" className="btn-ghost !px-3" onClick={() => addPref(f.pref_input)} aria-label="Add interest"><Plus size={16} /></button>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {PREFERENCE_SUGGESTIONS.filter((s) => !f.preferences.includes(s)).map((s) => <button key={s} type="button" onClick={() => addPref(s)} className="rounded-full bg-pearl-200 px-2.5 py-1 text-xs font-medium text-ink-700 hover:bg-gulf-100">+ {s}</button>)}
            </div>
          </Field>
        </fieldset>

        <fieldset className="card p-6">
          <legend className="sr-only">Costs you know</legend>
          <h2 className="text-lg font-bold">Costs only you can enter</h2>
          <p className="mb-4 mt-1 text-sm text-ink-500">Hotel rates, ticket prices and flights are not in the data. Add the ones you know.</p>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Hotel price per night (AED)" htmlFor="hotel"><input id="hotel" type="number" min="0" className="input" value={f.hotel_per_night_aed} onChange={(e) => set('hotel_per_night_aed', e.target.value)} /></Field>
            <Field label="Rooms" htmlFor="rooms" hint="Blank = one room per two travellers"><input id="rooms" type="number" min="1" className="input" value={f.rooms} onChange={(e) => set('rooms', e.target.value)} /></Field>
            <Field label="Activities & tickets, whole trip (AED)" htmlFor="act"><input id="act" type="number" min="0" className="input" value={f.activities_total_aed} onChange={(e) => set('activities_total_aed', e.target.value)} /></Field>
            <Field label="Flights, whole group (AED)" htmlFor="fl"><input id="fl" type="number" min="0" className="input" value={f.flights_total_aed} onChange={(e) => set('flights_total_aed', e.target.value)} /></Field>
          </div>
          <details className="mt-5">
            <summary className="cursor-pointer text-sm font-semibold text-gulf-600">Fine-tune daily habits</summary>
            <div className="mt-4 grid gap-5 sm:grid-cols-3">
              <Field label="Meals out per day" htmlFor="meals">
                <select id="meals" className="input" value={f.meals_per_day} onChange={(e) => set('meals_per_day', e.target.value)}>{[0, 1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select>
              </Field>
              <Field label="Metro/bus rides per person per day" htmlFor="rides"><input id="rides" type="number" min="0" max="20" className="input" value={f.local_rides_per_day} onChange={(e) => set('local_rides_per_day', e.target.value)} /></Field>
              <Field label="Taxi rides per day" htmlFor="taxi"><input id="taxi" type="number" min="0" max="20" className="input" value={f.taxi_rides_per_day} onChange={(e) => set('taxi_rides_per_day', e.target.value)} /></Field>
              <label className="flex items-center gap-2 text-sm font-medium sm:col-span-3"><input type="checkbox" checked={f.include_airport_transfers} onChange={(e) => set('include_airport_transfers', e.target.checked)} className="h-4 w-4 accent-gulf" /> Include airport transfers (taxi starting fares)</label>
            </div>
          </details>
        </fieldset>

        <Notice>The plan is built from a small set of genuine attractions in the dataset, so long trips may include “open time” slots.</Notice>

        <div className="flex flex-wrap items-center gap-3">
          <button className="btn-primary px-6 py-3 text-base" disabled={busy}><Sparkles size={18} /> {editId ? 'Regenerate plan' : 'Generate my plan'}</button>
          {editId && <button type="button" className="btn-ghost px-6 py-3" onClick={() => nav(-1)}>Cancel</button>}
        </div>
      </form>

      {busy && (
        <div className="fixed inset-0 z-[90] grid place-items-center bg-ink/70 p-4 backdrop-blur-sm" role="alert" aria-live="assertive">
          <div className="pass w-full max-w-sm p-8 text-center">
            <svg viewBox="0 0 200 40" className="mx-auto mb-4 h-10 w-48 text-gulf" aria-hidden>
              <path d="M5 30 Q100 -10 195 30" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="6 6" opacity=".35" />
              <path d="M5 30 Q100 -10 195 30" fill="none" stroke="currentColor" strokeWidth="2.5" strokeDasharray="400" style={{ animation: 'plane 2.2s ease-in-out infinite alternate' }} />
            </svg>
            <Plane className="mx-auto -rotate-45 text-saffron" />
            <p className="mt-4 font-display text-lg font-bold">Building your itinerary</p>
            <p className="mt-1 h-5 text-sm text-ink-500">{STEPS[step]}…</p>
          </div>
        </div>
      )}
    </div>
  )
}

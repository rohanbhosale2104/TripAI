import { useState } from 'react'
import { Calculator, Loader2 } from 'lucide-react'
import BudgetPanel from '../components/BudgetPanel'
import { ErrorBanner, Field, PageHeader, Segmented } from '../components/ui'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { parseError } from '../services/api'
import { exploreService } from '../services/exploreService'
import { FOOD_PREFS, TRANSPORT_PREFS } from '../utils/options'
import { num } from '../utils/format'

export default function BudgetEstimator() {
  useDocumentTitle('Budget estimator')
  const [f, setF] = useState({ days: 5, travellers: 2, budget_aed: 6000, food_preference: 'both', transport_preference: 'mixed', cuisine: '',
    hotel_per_night_aed: '', rooms: '', activities_total_aed: '', flights_total_aed: '', other_costs_aed: '', meals_per_day: 2, local_rides_per_day: 4, taxi_rides_per_day: 2, include_airport_transfers: true })
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [fields, setFields] = useState({})
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })

  const submit = async (e) => {
    e.preventDefault(); setError(''); setFields({})
    setBusy(true)
    try {
      setResult(await exploreService.budget({
        days: Number(f.days), travellers: Number(f.travellers), budget_aed: Number(f.budget_aed), food_preference: f.food_preference,
        transport_preference: f.transport_preference, cuisine: f.cuisine.trim() || null,
        hotel_per_night_aed: num(f.hotel_per_night_aed) ?? null, rooms: num(f.rooms) ?? null, activities_total_aed: num(f.activities_total_aed) ?? null,
        flights_total_aed: num(f.flights_total_aed) ?? null, other_costs_aed: num(f.other_costs_aed) ?? null, meals_per_day: Number(f.meals_per_day),
        local_rides_per_day: Number(f.local_rides_per_day), taxi_rides_per_day: Number(f.taxi_rides_per_day), include_airport_transfers: f.include_airport_transfers,
      }))
    } catch (err) { const p = parseError(err); setError(p.message); setFields(p.fields) } finally { setBusy(false) }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <PageHeader title="Budget estimator">Food and transport come from your dataset. Hotel, tickets and flights are added only if you enter them.</PageHeader>
      <form onSubmit={submit} className="card grid gap-5 p-6 sm:grid-cols-2 lg:grid-cols-4" noValidate>
        <Field label="Days" htmlFor="days" error={fields.days}><input id="days" type="number" min="1" max="30" className="input" value={f.days} onChange={set('days')} /></Field>
        <Field label="Travellers" htmlFor="tr" error={fields.travellers}><input id="tr" type="number" min="1" max="20" className="input" value={f.travellers} onChange={set('travellers')} /></Field>
        <Field label="Total budget (AED)" htmlFor="b" error={fields.budget_aed}><input id="b" type="number" min="1" className="input" value={f.budget_aed} onChange={set('budget_aed')} /></Field>
        <Field label="Hotel per night (AED)" htmlFor="h"><input id="h" type="number" min="0" className="input" value={f.hotel_per_night_aed} onChange={set('hotel_per_night_aed')} /></Field>
        <Field label="Activities, whole trip (AED)" htmlFor="a"><input id="a" type="number" min="0" className="input" value={f.activities_total_aed} onChange={set('activities_total_aed')} /></Field>
        <Field label="Flights, whole group (AED)" htmlFor="fl"><input id="fl" type="number" min="0" className="input" value={f.flights_total_aed} onChange={set('flights_total_aed')} /></Field>
        <Field label="Other costs (AED)" htmlFor="o"><input id="o" type="number" min="0" className="input" value={f.other_costs_aed} onChange={set('other_costs_aed')} /></Field>
        <Field label="Meals out per day" htmlFor="m"><select id="m" className="input" value={f.meals_per_day} onChange={set('meals_per_day')}>{[0, 1, 2, 3].map((n) => <option key={n}>{n}</option>)}</select></Field>
        <div className="sm:col-span-2 lg:col-span-4"><Field label="Food"><Segmented name="Food" value={f.food_preference} onChange={(v) => setF({ ...f, food_preference: v })} options={FOOD_PREFS} /></Field></div>
        <div className="sm:col-span-2 lg:col-span-4"><Field label="Getting around"><Segmented name="Transport" value={f.transport_preference} onChange={(v) => setF({ ...f, transport_preference: v })} options={TRANSPORT_PREFS} /></Field></div>
        <label className="flex items-center gap-2 text-sm font-medium sm:col-span-2"><input type="checkbox" className="h-4 w-4 accent-gulf" checked={f.include_airport_transfers} onChange={set('include_airport_transfers')} /> Include airport transfers</label>
        <div className="flex items-end sm:col-span-2 lg:justify-end"><button className="btn-primary px-6 py-3" disabled={busy}>{busy ? <Loader2 className="animate-spin" size={18} /> : <Calculator size={18} />} Estimate budget</button></div>
      </form>
      <div className="mt-6"><ErrorBanner message={error} /></div>
      {result && <div className="mt-8"><BudgetPanel budget={result} />
        <ul className="mt-6 list-disc space-y-1 pl-5 text-xs text-ink-500">{result.notes.map((n) => <li key={n}>{n}</li>)}</ul></div>}
    </div>
  )
}

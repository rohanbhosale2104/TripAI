import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Plus } from 'lucide-react'
import { FoodCard, PlaceCard } from '../components/Cards'
import { ConfidenceBadge, EmptyState, ErrorBanner, Notice, Spinner } from '../components/ui'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { exploreService } from '../services/exploreService'
import { aed } from '../utils/format'
import AreaImage from '../components/AreaImage'
import { AREA_GRADIENTS } from '../utils/options'

export default function DestinationDetail() {
  const { slug } = useParams()
  const { data: a, loading, error, reload } = useAsync(() => exploreService.area(slug), [slug])
  useDocumentTitle(a?.name || 'Area')
  if (loading) return <Spinner label="Loading area" className="py-32" />
  if (error) return <div className="mx-auto max-w-3xl px-4 py-16"><ErrorBanner message={error} onRetry={reload} /><Link to="/destinations" className="btn-ghost mt-6">All areas</Link></div>
  const e = a.estimated_expenses
  return (
    <div>
      <div className={`relative overflow-hidden bg-gradient-to-br ${AREA_GRADIENTS[a.slug] || 'from-ink to-gulf'} text-white`}>
        <AreaImage slug={a.slug} name={a.name} />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/85 via-ink/55 to-ink/20" aria-hidden />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <Link to="/destinations" className="mb-6 inline-flex items-center gap-1.5 text-sm font-semibold text-white/80 hover:text-white"><ArrowLeft size={16} /> All areas</Link>
          <h1 className="text-5xl font-extrabold">{a.name}</h1>
          <p className="mt-3 max-w-2xl text-lg text-white/85">{a.description}</p>
          <ul className="mt-5 flex flex-wrap gap-2">{a.known_for.map((k) => <li key={k} className="rounded-full bg-white/15 px-3 py-1 text-sm">{k}</li>)}</ul>
        </div>
      </div>
      <div className="mx-auto max-w-7xl space-y-14 px-4 py-12 sm:px-6">
        <section className="grid gap-6 lg:grid-cols-3">
          <div className="card p-5"><h2 className="text-lg font-bold">Estimated expenses</h2>
            <dl className="mt-3 space-y-3 text-sm">
              <div><dt className="text-ink-500">Meal per person {e.food && <ConfidenceBadge level="synthetic" />}</dt><dd className="font-semibold">{e.food ? `${aed(e.food.low)} – ${aed(e.food.high)} (median ${aed(e.food.median)})` : 'No food records for this area'}</dd></div>
              <div><dt className="text-ink-500">Metro / bus ride</dt><dd className="font-semibold">{aed(e.public_transport_per_ride_aed.base)} / {aed(e.public_transport_per_ride_aed.band_2)} / {aed(e.public_transport_per_ride_aed.band_3)} by zones</dd></div>
              <div><dt className="text-ink-500">Accommodation</dt><dd>{e.accommodation}</dd></div>
              <div><dt className="text-ink-500">Activities</dt><dd>{e.activities}</dd></div>
            </dl></div>
          <div className="card p-5 lg:col-span-2"><h2 className="text-lg font-bold">Best activities here</h2>
            {Object.keys(a.activity_types).length ? (
              <ul className="mt-3 flex flex-wrap gap-2">{Object.entries(a.activity_types).map(([k, n]) => <li key={k} className="chip border-gulf/30 bg-gulf-50 text-gulf-600">{k} · {n}</li>)}</ul>
            ) : <p className="mt-3 text-sm text-ink-500">No activities in the dataset within this area.</p>}
            {a.food?.popular_cuisines && <p className="mt-4 text-sm text-ink-700">Popular cuisines in the food data: {a.food.popular_cuisines.join(', ')}.</p>}
          </div>
        </section>

        <section><h2 className="mb-4 text-2xl font-extrabold">Attractions nearby</h2>
          {a.attractions.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{a.attractions.map((p) => <PlaceCard key={p.name} place={p} />)}</div> : <EmptyState title="No attractions in the dataset here">Check neighbouring areas.</EmptyState>}
        </section>
        <section><h2 className="mb-4 text-2xl font-extrabold">Hotels nearby</h2>
          {a.hotels_nearby.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{a.hotels_nearby.map((p) => <PlaceCard key={p.name} place={p} note={`${p.distance_km} km from area centre · price not in dataset`} />)}</div> : <EmptyState title="No hotels in the dataset here" />}
        </section>
        {a.food?.sample_dishes && (
          <section><h2 className="mb-4 text-2xl font-extrabold">Dishes in the food data</h2>
            <Notice tone="warn">{a.food.disclaimer}</Notice>
            <ul className="mt-4 flex flex-wrap gap-2">{a.food.sample_dishes.map((d) => <li key={d} className="chip border-ink/15 bg-white">{d}</li>)}</ul>
          </section>
        )}
        <Link to="/plan" className="btn-primary"><Plus size={16} /> Plan a trip around {a.name}</Link>
      </div>
    </div>
  )
}

import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Download, Eye, Map, Plus, Trash2 } from 'lucide-react'
import BoardingPass from '../components/BoardingPass'
import { EmptyState, ErrorBanner, PageHeader, SkeletonCards } from '../components/ui'
import { useToast } from '../context/ToastContext'
import { useAsync } from '../hooks/useAsync'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { parseError } from '../services/api'
import { tripService } from '../services/tripService'

export default function MyTrips() {
  useDocumentTitle('My trips')
  const trips = useAsync(tripService.list, [])
  const toast = useToast()
  const [pending, setPending] = useState(null)
  const [busy, setBusy] = useState('')

  const del = async (t) => {
    setBusy(t.id)
    try { await tripService.remove(t.id); toast.success('Trip deleted.'); setPending(null); trips.reload() }
    catch (e) { toast.error(parseError(e).message) } finally { setBusy('') }
  }
  const pdf = async (t) => {
    setBusy(t.id)
    try { await tripService.downloadPdf(t.id, `tripai-dubai-${t.start_date}.pdf`) } catch (e) { toast.error(parseError(e).message) } finally { setBusy('') }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
      <PageHeader title="My trips" actions={<Link to="/plan" className="btn-primary"><Plus size={16} /> New trip</Link>}>Saved itineraries. Open one to view, edit or export it.</PageHeader>
      <ErrorBanner message={trips.error} onRetry={trips.reload} />
      {trips.loading && <SkeletonCards count={3} className="h-44" />}
      {trips.data && trips.data.length === 0 && (
        <EmptyState icon={Map} title="No saved trips yet" action={<Link to="/plan" className="btn-primary">Plan your first trip</Link>}>Generate a plan and press “Save trip” to keep it here.</EmptyState>
      )}
      <div className="space-y-6">
        {trips.data?.map((t) => (
          <BoardingPass key={t.id} trip={t}>
            <Link to={`/trips/${t.id}`} className="btn-primary"><Eye size={16} /> Open</Link>
            <button className="btn-ghost" onClick={() => pdf(t)} disabled={busy === t.id} aria-label={`Download PDF for ${t.title}`}><Download size={16} /></button>
            {pending === t.id
              ? <><button className="btn-danger" onClick={() => del(t)} disabled={busy === t.id}>Delete trip</button><button className="btn-ghost" onClick={() => setPending(null)}>Keep</button></>
              : <button className="btn-danger" onClick={() => setPending(t.id)} aria-label={`Delete ${t.title}`}><Trash2 size={16} /></button>}
          </BoardingPass>
        ))}
      </div>
    </div>
  )
}

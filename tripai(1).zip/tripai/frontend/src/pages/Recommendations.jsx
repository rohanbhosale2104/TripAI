import { useState } from 'react'
import { Loader2, Search } from 'lucide-react'
import { FoodCard, PlaceCard, ResultNotes, TransportCard } from '../components/Cards'
import { EmptyState, ErrorBanner, Field, PageHeader, Segmented } from '../components/ui'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { parseError } from '../services/api'
import { exploreService } from '../services/exploreService'
import { FOOD_PREFS, TRANSPORT_PREFS, TRAVEL_TYPES } from '../utils/options'
import AreaCard from '../components/AreaCard'
import { AREA_GRADIENTS } from '../utils/options'

const TABS = [['destinations', 'Areas'], ['hotels', 'Hotels'], ['attractions', 'Attractions'], ['restaurants', 'Restaurants'], ['food', 'Dishes'], ['transport', 'Transport']]
const needsType = ['destinations', 'hotels', 'attractions']
const needsFood = ['restaurants', 'food']

export default function Recommendations() {
  useDocumentTitle('Recommendations')
  const [kind, setKind] = useState('destinations')
  const [f, setF] = useState({ travel_type: 'couple', food_preference: 'both', transport_preference: 'mixed', keywords: '', cuisine: '', max_cost: '' })
  const [res, setRes] = useState({})
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const run = async (e) => {
    e?.preventDefault(); setError(''); setBusy(true)
    const body = { limit: 9, keywords: f.keywords.trim() || null }
    if (needsType.includes(kind)) body.travel_type = f.travel_type
    if (needsFood.includes(kind)) { body.food_preference = f.food_preference; body.cuisine = f.cuisine.trim() || null }
    if (kind === 'food' && f.max_cost) body.max_cost_for_two_aed = Number(f.max_cost)
    if (kind === 'transport') { delete body.keywords; body.transport_preference = f.transport_preference; body.include_airport = true }
    try { setRes((r) => ({ ...r, [kind]: undefined })); const data = await exploreService.recommend(kind, body); setRes((r) => ({ ...r, [kind]: data })) }
    catch (err) { setError(parseError(err).message) } finally { setBusy(false) }
  }
  const data = res[kind]

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <PageHeader title="Recommendations">Ask any of the five models directly. Each result shows the query the model was given.</PageHeader>
      <div className="flex gap-1 overflow-x-auto border-b border-ink/10" role="tablist">
        {TABS.map(([k, l]) => <button key={k} role="tab" aria-selected={kind === k} onClick={() => { setKind(k); setError('') }} className={`whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-semibold ${kind === k ? 'border-gulf text-gulf-600' : 'border-transparent text-ink-500 hover:text-ink'}`}>{l}</button>)}
      </div>

      <form onSubmit={run} className="card mt-6 space-y-5 p-6">
        {needsType.includes(kind) && <Field label="Travel type"><Segmented name="Travel type" value={f.travel_type} onChange={(v) => setF({ ...f, travel_type: v })} options={TRAVEL_TYPES} /></Field>}
        {needsFood.includes(kind) && <Field label="Food preference"><Segmented name="Food" value={f.food_preference} onChange={(v) => setF({ ...f, food_preference: v })} options={FOOD_PREFS} /></Field>}
        {kind === 'transport' && <Field label="Preference"><Segmented name="Transport" value={f.transport_preference} onChange={(v) => setF({ ...f, transport_preference: v })} options={TRANSPORT_PREFS} /></Field>}
        <div className="grid gap-5 sm:grid-cols-3">
          {kind !== 'transport' && <Field label="Keywords (optional)" htmlFor="kw"><input id="kw" className="input" placeholder="e.g. beach, heritage" value={f.keywords} onChange={(e) => setF({ ...f, keywords: e.target.value })} /></Field>}
          {needsFood.includes(kind) && <Field label="Cuisine (optional)" htmlFor="cu"><input id="cu" className="input" placeholder="e.g. Indian" value={f.cuisine} onChange={(e) => setF({ ...f, cuisine: e.target.value })} /></Field>}
          {kind === 'food' && <Field label="Max cost for two (AED)" htmlFor="mx"><input id="mx" type="number" min="1" className="input" value={f.max_cost} onChange={(e) => setF({ ...f, max_cost: e.target.value })} /></Field>}
        </div>
        <button className="btn-primary" disabled={busy}>{busy ? <Loader2 className="animate-spin" size={16} /> : <Search size={16} />} Get recommendations</button>
      </form>

      <div className="mt-6"><ErrorBanner message={error} /></div>
      {data && (
        <div className="mt-8" role="region" aria-live="polite">
          {data.items.length === 0 ? <EmptyState title="Nothing matched">Try fewer or different keywords.</EmptyState> : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {kind === 'destinations' && data.items.map((a) => <div key={a.slug}><AreaCard area={{ ...a, known_for: a.known_for, attraction_count: a.matching_attractions.length, food_record_count: 0 }} gradient={AREA_GRADIENTS[a.slug]} />{a.matching_attractions.length > 0 && <p className="mt-2 px-1 text-xs text-ink-500">Matches: {a.matching_attractions.join(', ')}</p>}</div>)}
              {['hotels', 'attractions', 'restaurants'].includes(kind) && data.items.map((p) => <PlaceCard key={p.name} place={p} />)}
              {kind === 'food' && data.items.map((x, i) => <FoodCard key={i} item={x} />)}
              {kind === 'transport' && data.items.map((t) => <TransportCard key={t.id} item={t} />)}
            </div>
          )}
          <ResultNotes data={data} />
        </div>
      )}
    </div>
  )
}

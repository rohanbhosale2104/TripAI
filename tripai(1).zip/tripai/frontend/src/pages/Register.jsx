import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Loader2 } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { parseError } from '../services/api'
import { ErrorBanner, Field } from '../components/ui'
import { useDocumentTitle } from '../hooks/useDocumentTitle'

export default function Register() {
  useDocumentTitle('Create account')
  const { register } = useAuth()
  const nav = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [fields, setFields] = useState({})
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setFields({})
    if (form.password.length < 8 || !/[A-Za-z]/.test(form.password) || !/\d/.test(form.password)) {
      setFields({ password: 'Use at least 8 characters with a letter and a number.' }); return
    }
    setBusy(true)
    try {
      await register({ name: form.name.trim(), email: form.email.trim(), password: form.password })
      nav('/dashboard', { replace: true })
    } catch (err) { const p = parseError(err); setError(Object.keys(p.fields).length ? '' : p.message); setFields(p.fields) } finally { setBusy(false) }
  }

  return (
    <>
      <h1 className="text-3xl font-extrabold">Create your account</h1>
      <p className="mt-2 text-ink-500">Free. Needed to generate and save trips.</p>
      <form onSubmit={submit} className="mt-8 space-y-5" noValidate>
        <ErrorBanner message={error} />
        <Field label="Name" htmlFor="name" error={fields.name}><input id="name" autoComplete="name" required className="input" value={form.name} onChange={set('name')} /></Field>
        <Field label="Email" htmlFor="email" error={fields.email}><input id="email" type="email" autoComplete="email" required className="input" value={form.email} onChange={set('email')} /></Field>
        <Field label="Password" htmlFor="password" hint="At least 8 characters, with a letter and a number." error={fields.password}><input id="password" type="password" autoComplete="new-password" required className="input" value={form.password} onChange={set('password')} /></Field>
        <button className="btn-primary w-full" disabled={busy || !form.name || !form.email || !form.password}>{busy && <Loader2 className="animate-spin" size={16} />} Create account</button>
      </form>
      <p className="mt-6 text-sm text-ink-500">Already registered? <Link to="/login" className="font-semibold text-gulf-600 underline">Log in</Link></p>
    </>
  )
}

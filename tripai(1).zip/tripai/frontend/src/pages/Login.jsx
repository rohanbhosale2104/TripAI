import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Loader2 } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { parseError } from '../services/api'
import { ErrorBanner, Field } from '../components/ui'
import { useDocumentTitle } from '../hooks/useDocumentTitle'

export default function Login() {
  useDocumentTitle('Log in')
  const { login } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setBusy(true)
    try {
      await login({ email: form.email.trim(), password: form.password })
      nav(loc.state?.from || '/dashboard', { replace: true })
    } catch (err) { setError(parseError(err).message) } finally { setBusy(false) }
  }

  return (
    <>
      <h1 className="text-3xl font-extrabold">Welcome back</h1>
      <p className="mt-2 text-ink-500">Log in to see your saved trips.</p>
      <form onSubmit={submit} className="mt-8 space-y-5" noValidate>
        <ErrorBanner message={error} />
        <Field label="Email" htmlFor="email"><input id="email" type="email" autoComplete="email" required className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
        <Field label="Password" htmlFor="password"><input id="password" type="password" autoComplete="current-password" required className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
        <button className="btn-primary w-full" disabled={busy || !form.email || !form.password}>{busy && <Loader2 className="animate-spin" size={16} />} Log in</button>
      </form>
      <p className="mt-6 text-sm text-ink-500">New to TripAI? <Link to="/register" className="font-semibold text-gulf-600 underline">Create an account</Link></p>
    </>
  )
}

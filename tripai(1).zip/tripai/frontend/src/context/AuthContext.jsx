import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { authService } from '../services/authService'
import { setUnauthorizedHandler, tokenStore } from '../services/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [booting, setBooting] = useState(!!tokenStore.get())

  const clear = useCallback(() => { tokenStore.clear(); setUser(null) }, [])

  useEffect(() => {
    setUnauthorizedHandler(clear)
    if (!tokenStore.get()) return
    authService.me().then(setUser).catch(clear).finally(() => setBooting(false))
  }, [clear])

  const value = useMemo(() => ({
    user, booting, isAuthenticated: !!user,
    login: async (p) => { const u = await authService.login(p); setUser(u); return u },
    register: async (p) => { const u = await authService.register(p); setUser(u); return u },
    logout: async () => { await authService.logout(); setUser(null) },
    setUser,
  }), [user, booting, clear])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>')
  return ctx
}

# TripAI - Dubai trip planner

React + Vite + Tailwind frontend, FastAPI backend, MongoDB (PyMongo), and **your five existing pickle models, loaded unmodified**.

## 1. What the models really are
Each `.pkl` is `{"vectorizer": TfidfVectorizer, "model": NearestNeighbors(cosine), "data": DataFrame}`: a **content-based recommender**. There are **no price/cost/demand predictors**, so TripAI never "predicts" prices. Prices come only from dataset columns (food, transport) or from the user.

| Model file | Purpose | Input | Output | TripAI feature | Rows (usable) |
|---|---|---|---|---|---|
| `dubai_accommodation_model.pkl` | Similar hotels | text query | name, type, address, lat/lng | Stay tab, hotel recs | 1,515 (522) |
| `dubai_poi_model.pkl` | Similar places | text query | name, type, address, lat/lng | Attractions, itinerary, Explorer | 7,105 (3,478) |
| `dubai_restaurant_model.pkl` | Similar restaurants | text query | name, cuisine type, location | Restaurants, itinerary meals | 7,342 (4,340) |
| `dubai_food_model.pkl` | Dishes + costs | text query | dish, restaurant, cuisine, area, AED prices, diet | Food recs, food budget | 220 (synthetic) |
| `dubai_transportation_model.pkl` | Transport modes | text query | mode, AED fares, booking info | Transport recs, transport budget | 14 |

Pickles live in `backend/app/ml_models/` with `SHA256SUMS.txt`; the app verifies they are unmodified at startup.

## 2. Folder structure
```
tripai/
  backend/app/ {main,config,database}.py
    routes/ auth users trips destinations recommendations budget
    services/ ml_service recommendation_service budget_service trip_service agent_tools
    schemas/ models/ utils/ (security, pdf, geo, text, deps) middleware/ (errors, rate_limit)
    ml_models/  data/dubai_areas.json
  backend/tests/ (22 tests)   backend/requirements.txt   backend/.env.example
  frontend/src/ components pages services context hooks layouts utils
  render.yaml  PROGRESS.md
```
`routes/predictions.py` from the brief was replaced by `routes/budget.py` because there are no prediction models.

## 3. Run on Windows (PowerShell + VS Code)
Prerequisites: **Python 3.11 or 3.12**, **Node 18+**, and MongoDB (local Community Server *or* free Atlas M0).

```powershell
# --- Backend (terminal 1) ---
cd tripai\backend
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1          # if blocked: Set-ExecutionPolicy -Scope Process Bypass
pip install -r requirements.txt
Copy-Item .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(48))"   # paste into JWT_SECRET in .env
uvicorn app.main:app --reload --port 8000
# Swagger: http://127.0.0.1:8000/docs   Health: http://127.0.0.1:8000/api/health

# --- Frontend (terminal 2) ---
cd tripai\frontend
npm install
npm run dev                            # http://localhost:5173  (proxies /api to port 8000)
```
**MongoDB:** local default `mongodb://localhost:27017` (open it in MongoDB Compass with the same URI; database `tripai`). For Atlas, put the `mongodb+srv://...` URI in `MONGODB_URI`. No MongoDB yet? Set `USE_MOCK_DB=true` in `.env` for a throwaway in-memory database (dev only; `pip install mongomock`).

**Tests:** `pip install -r requirements-dev.txt; pytest` (uses your real pickles; an in-memory MongoDB).

## 4. API
Public: `POST /api/recommendations/{destinations|hotels|attractions|restaurants|food|transport}`, `POST /api/budget/estimate`, `GET /api/destinations`, `GET /api/destinations/{slug}`, `GET /api/destinations/attractions`, `GET /api/health`.
Auth (Bearer JWT): `POST /api/auth/register|login|logout`, `GET /api/auth/me`, `GET|PUT /api/users/me`, `PUT /api/users/me/password`, `POST /api/trips/generate`, `POST|GET /api/trips`, `GET|PUT|DELETE /api/trips/{id}`, `GET /api/trips/{id}/pdf`.
Errors are `{"error": {"code", "message", "details?"}}`; unavailable models return **503**, never fake data.

## 5. Database (MongoDB `tripai`)
- `users`: `_id, name, email (unique), password_hash (bcrypt), home_city, preferences, created_at`
- `trips`: `_id, user_id, title, notes, request (the form), plan (generated server-side), created_at, updated_at`
- `revoked_tokens`: `_id (jti), expires_at` (TTL index; powers real logout)

## 6. Known limitations (please read)
1. **Dubai only**: the data is Dubai only.
2. **Corrupted source rows**: ~65% of accommodation, ~51% of POI and ~41% of restaurant rows are column-shifted and are filtered out at load (originals untouched).
3. **POI data is mostly not tourism** (roads, hospitals, parking). Only 28 genuinely visitable places survive filtering, so long trips show "open time" slots.
4. **Food data is synthetic** (your file says so) and is labelled in the UI. Vegetarian filter is strict (dish must be vegetarian).
5. **No hotel, ticket, flight or live prices**; you enter them. Taxi/airport figures are starting fares (marked as lower bounds); ride-hailing is a quote, not priced.
6. Restaurant model has no diet data; the vegetarian restaurant filter uses category heuristics (stated in the UI).
7. All amounts are AED; no currency conversion.
8. A few hotel rows may be outside Dubai city (source labelling).
9. Not verified in the build sandbox: a real MongoDB server and a real-browser click-through.

## 7. Deployment (free tiers)
- **DB:** MongoDB Atlas M0. **API:** Render (`render.yaml`), set `MONGODB_URI`, `CORS_ORIGINS`. **Frontend:** Vercel/Netlify, build `npm run build`, set `VITE_API_URL=https://<your-api>`; SPA rewrites are included (`vercel.json`, `_redirects`).
- Production refuses to start with a weak/default `JWT_SECRET`.
- Security notes: bcrypt hashes, JWT with server-side revocation, login rate limiting (in-memory, single process), CORS allow-list, security headers. The JWT is kept in `localStorage` (simple, but exposed to XSS); move to httpOnly cookies for a hardened release. Only load pickles you created yourself.

## 8. Future LangGraph integration
`services/agent_tools.py` exposes every service as a plain-dict tool (`plan_trip`, `estimate_budget`, `recommend_*`) with a suggested mapping to Planner / Research / Budget / Transport / Hotel / Food / Itinerary agents. No paid API is required today.
